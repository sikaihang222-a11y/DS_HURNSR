package NegHightUtilitySeq;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import USpanPlusOptimal.Pattern;
import USpanPlusOptimal.USpanPlus;

public class NegHightUtilitySeq {
	/**
	 * 获得负高效用序列
	 * Feb 29，2024    NegHightUtilitySeq-->USpanPlus
	 * @param HightUtilitySeqList
	 * @param threshold
	 * @return
	 *
	 */
	public List<Pattern> NegHightUtilitySeq(List<Pattern> HightUtilitySeqList, List<Pattern> SeqList) {
		USpanPlus up = new USpanPlus();
		// 解码高效用序列集合
/*		up.DecodingThePatternItemIds((ArrayList<Pattern>) SeqList);*/
		// 存储 高效用序列及其效用值
		Map<ArrayList<ArrayList<Integer>>, Double> AllHightUtilitySeqMap = new HashMap<ArrayList<ArrayList<Integer>>, Double>();
		for (int i = 0; i < HightUtilitySeqList.size(); i++) {
			AllHightUtilitySeqMap.put(HightUtilitySeqList.get(i).getItemsets(),
					HightUtilitySeqList.get(i).getUtility());
		}
		Pattern patternUtil = new Pattern();
		List<Pattern> Negpatternlist = new ArrayList<Pattern>();
		// 遍历高效序列进行负高效序列求解
		for (int i = 0; i < HightUtilitySeqList.size(); i++) {
			patternUtil = HightUtilitySeqList.get(i);
			// 当高效应序列项集的个数大于1.，才进行取非
			if (patternUtil.getItemsets().size() > 1) {

				// -----------------1-neg item-------------------
				for (int j = 0; j < patternUtil.getItemsets().size(); j++) {
					patternUtil.setNeg(patternUtil.getItemsets().get(j));
					Pattern p = new Pattern(patternUtil);
					patternUtil.getPosFromSeq(p);// 取负序列集合中的正序列
					if (AllHightUtilitySeqMap.containsKey(p.getItemsets())) {
						Pattern p1 = new Pattern(patternUtil);
						p1.setUtility(AllHightUtilitySeqMap.get(p.getItemsets()));
						Negpatternlist.add(p1);
					}
					patternUtil.setNeg(patternUtil.getItemsets().get(j));
				}

				// -----------------2-neg item-------------------
				for (int j = 0; j < patternUtil.getItemsets().size(); j++) {
					for (int j2 = j + 2; j2 < patternUtil.getItemsets().size(); j2++) {
						patternUtil.setNeg(patternUtil.getItemsets().get(j));
						patternUtil.setNeg(patternUtil.getItemsets().get(j2));
						Pattern p = new Pattern(patternUtil);
						patternUtil.getPosFromSeq(p);// 取负序列集合中的正序列
						if (AllHightUtilitySeqMap.containsKey(p.getItemsets())) {
							Pattern p1 = new Pattern(patternUtil);
							p1.setUtility(AllHightUtilitySeqMap.get(p.getItemsets()));
							Negpatternlist.add(p1);
						}
						patternUtil.setNeg(patternUtil.getItemsets().get(j));
						patternUtil.setNeg(patternUtil.getItemsets().get(j2));

					}

				}

				// -----------------3-neg item-------------------
				for (int j = 0; j < patternUtil.getItemsets().size(); j++) {
					for (int j2 = j + 2; j2 < patternUtil.getItemsets().size(); j2++) {
						for (int j3 = j2 + 2; j3 < patternUtil.getItemsets().size(); j3++) {
							patternUtil.setNeg(patternUtil.getItemsets().get(j));
							patternUtil.setNeg(patternUtil.getItemsets().get(j2));
							patternUtil.setNeg(patternUtil.getItemsets().get(j3));
							Pattern p = new Pattern(patternUtil);
							patternUtil.getPosFromSeq(p);// 去负序列集合中的正序列
							if (AllHightUtilitySeqMap.containsKey(p.getItemsets())) {
								Pattern p1 = new Pattern(patternUtil);
								p1.setUtility(AllHightUtilitySeqMap.get(p.getItemsets()));
								Negpatternlist.add(p1);
							}
							patternUtil.setNeg(patternUtil.getItemsets().get(j));
							patternUtil.setNeg(patternUtil.getItemsets().get(j2));
							patternUtil.setNeg(patternUtil.getItemsets().get(j3));
						}

					}

				}

				// -----------------4-neg item-------------------
				for (int j = 0; j < patternUtil.getItemsets().size(); j++) {
					for (int j2 = j + 2; j2 < patternUtil.getItemsets().size(); j2++) {
						for (int j3 = j2 + 2; j3 < patternUtil.getItemsets().size(); j3++) {
							for (int j4 = j3 + 2; j4 < patternUtil.getItemsets().size(); j4++) {
								patternUtil.setNeg(patternUtil.getItemsets().get(j));
								patternUtil.setNeg(patternUtil.getItemsets().get(j2));
								patternUtil.setNeg(patternUtil.getItemsets().get(j3));
								patternUtil.setNeg(patternUtil.getItemsets().get(j4));
								Pattern p = new Pattern(patternUtil);
								patternUtil.getPosFromSeq(p);// 去负序列集合中的正序列
								if (AllHightUtilitySeqMap.containsKey(p.getItemsets())) {
									Pattern p1 = new Pattern(patternUtil);
									p1.setUtility(AllHightUtilitySeqMap.get(p.getItemsets()));
									Negpatternlist.add(p1);
								}
								patternUtil.setNeg(patternUtil.getItemsets().get(j));
								patternUtil.setNeg(patternUtil.getItemsets().get(j2));
								patternUtil.setNeg(patternUtil.getItemsets().get(j3));
								patternUtil.setNeg(patternUtil.getItemsets().get(j4));
							}

						}

					}

				}

				// -----------------5-neg item-------------------
				for (int j = 0; j < patternUtil.getItemsets().size(); j++) {
					for (int j2 = j + 2; j2 < patternUtil.getItemsets().size(); j2++) {
						for (int j3 = j2 + 2; j3 < patternUtil.getItemsets().size(); j3++) {
							for (int j4 = j3 + 2; j4 < patternUtil.getItemsets().size(); j4++) {
								for (int j5 = j4 + 2; j5 < patternUtil.getItemsets().size(); j5++) {
									patternUtil.setNeg(patternUtil.getItemsets().get(j));
									patternUtil.setNeg(patternUtil.getItemsets().get(j2));
									patternUtil.setNeg(patternUtil.getItemsets().get(j3));
									patternUtil.setNeg(patternUtil.getItemsets().get(j4));
									patternUtil.setNeg(patternUtil.getItemsets().get(j5));
									Pattern p = new Pattern(patternUtil);
									patternUtil.getPosFromSeq(p);// 去负序列集合中的正序列
									if (AllHightUtilitySeqMap.containsKey(p.getItemsets())) {
										Pattern p1 = new Pattern(patternUtil);
										p1.setUtility(AllHightUtilitySeqMap.get(p.getItemsets()));
										Negpatternlist.add(p1);
									}
									patternUtil.setNeg(patternUtil.getItemsets().get(j));
									patternUtil.setNeg(patternUtil.getItemsets().get(j2));
									patternUtil.setNeg(patternUtil.getItemsets().get(j3));
									patternUtil.setNeg(patternUtil.getItemsets().get(j4));
									patternUtil.setNeg(patternUtil.getItemsets().get(j5));
								}

							}

						}

					}

				}

			}

		}
		return Negpatternlist;
	}
}
