package test;


public class e {  
    public static void main(String[] args) {  
       String str ="123145178";
       System.out.println(str.lastIndexOf("1"));
          
    }  
}  