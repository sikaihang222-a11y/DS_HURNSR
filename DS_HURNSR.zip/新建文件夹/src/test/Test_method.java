package test;

import java.util.ArrayList;
import java.util.List;

import util.Itemset;

public class Test_method {
	public  List<List<Integer>> getPosFromSeqList(Itemset a) {
		Itemset b = new Itemset(a);
		List<List<Integer>> Itemset =new ArrayList<List<Integer>>();
		Itemset = b.getItemSetIndex();
		for (int i = 0; i < Itemset.size(); i++) {
			for (int j = 0; j < Itemset.get(i).size(); j++) {
				if(Itemset.get(i).get(j)<0){
					Itemset.get(i).remove(j);
				}
			}
			if(Itemset.get(i).isEmpty()){
				Itemset.remove(i);
			}
		}
		return Itemset;
	}
public static void main(String[] args) {
	List<List<Integer>> items = new ArrayList<List<Integer>>();
	List<Integer> item1 = new ArrayList<Integer>();
	List<Integer> item2 = new ArrayList<Integer>();
	List<Integer> item3= new ArrayList<Integer>();
	item1.add(1);
	item2.add(-3);
	item3.add(1);
	items.add(item1);
	items.add(item2);
	items.add(item3);
	Itemset item = new Itemset();
	item.setItemSetIndex(items);
	Test_method T = new Test_method();
	System.out.println(T.getPosFromSeqList(item));
}
}
