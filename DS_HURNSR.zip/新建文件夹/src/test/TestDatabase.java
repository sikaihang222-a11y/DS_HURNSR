package test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import util.StrCount;
import util.WriteString;

public class TestDatabase {
	public static void main(String[] args) throws IOException {
		FileReader fr = new FileReader("E:/FIFA.txt");
		BufferedReader bf = new BufferedReader(fr);
		WriteString ws = new WriteString();
		String str;
		// 按行读取字符串
		int i = 1;
		while ((str = bf.readLine()) != null) {
			ws.writeString(i, str, "E:/FIFA_Seq.txt");
			i++;
		}
		bf.close();
		fr.close();
		System.out.println("序列转换完成！！！");
	}
}
