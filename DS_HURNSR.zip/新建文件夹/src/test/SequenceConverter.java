package test;

import java.io.*;
import java.util.*;

public class SequenceConverter {

    public static void main(String[] args) {


        String inputFile = "E:\\Desktop\\USpan+Optimal2\\dateset\\realDataset\\BIKE";
        String outputFile = "BIKE.txt";

        List<String> convertedData = convertSequences(inputFile);

        writeToFile(outputFile, convertedData);

        // 统计并输出数字重复次数和不同数字的个数
        Map<Integer, Integer> frequencyMap = countFrequencies(convertedData);
        printTopFrequencies(frequencyMap, 10);
        printUniqueCount(frequencyMap);
    }

    public static List<String> convertSequences(String inputFile) {
        List<String> result = new ArrayList<>();
        int sequenceId = 0;
        Random random = new Random();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                sequenceId++;
                int itemsetId = 0;
                String[] items = line.split(" ");
                for (String item : items) {
                    if (item.equals("-1")) {
                        itemsetId++;
                    } else if (item.equals("-2")) {
                        break;
                    } else {
                        if (itemsetId < 8) {
                            // 生成0到100的随机整数效用值
                            int utility = random.nextInt(101);
                            result.add(sequenceId + " " + itemsetId + " " + item + " " + utility);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }

    public static void writeToFile(String outputFile, List<String> data) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
            for (String line : data) {
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Map<Integer, Integer> countFrequencies(List<String> data) {
        Map<Integer, Integer> frequencyMap = new HashMap<>();
        for (String line : data) {
            String[] parts = line.split(" ");
            int number = Integer.parseInt(parts[2]);
            frequencyMap.put(number, frequencyMap.getOrDefault(number, 0) + 1);
        }
        return frequencyMap;
    }

    public static void printTopFrequencies(Map<Integer, Integer> frequencyMap, int topN) {
        System.out.println("Top " + topN + " most frequent numbers:");
        frequencyMap.entrySet().stream()
                .sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue()))
                .limit(topN)
                .forEach(entry -> System.out.println("Number: " + entry.getKey() + ", Count: " + entry.getValue()));
    }

    public static void printUniqueCount(Map<Integer, Integer> frequencyMap) {
        System.out.println("Total unique numbers: " + frequencyMap.size());
    }
}
