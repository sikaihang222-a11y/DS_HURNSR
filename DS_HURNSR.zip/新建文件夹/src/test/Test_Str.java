package test;

public class Test_Str {
public static void main(String[] args) {
	Test_Str t = new Test_Str();
	String str = "10.57098289	18.35712925	5.607206472	2.459685328	15.4410098	19.77782703	5.187156266	12.96794732	22.65857943	29.41371054	35.02773221	35.37712286	43.32823904	33.8360362	43.24911718";
	int count = t.CountTab(str);
	for (int i = 0; i <=count; i++) {
		String newstr = str.substring(0, str.indexOf("."));
		str = str.substring(str.indexOf("	") + 1);
		String str1 = newstr.trim();
		System.out.println(str1);
	}
}
public int CountTab(String str){
	int count=0;//用于数总次数；
	int index,index1=0;
	int n=1;//用于每次显示次数
	String key ="	";
	if(str.contains(key))
	{
		while((index=str.indexOf(key))!=-1)
		{   
			str=str.substring(index + key.length());//在数到一个后，马上找到新的字符串进行搜索
			index1=(index+index1+key.length());//这里比较巧妙的加上上一次的索引和key的长度以显示在整个父字符串中的位置
			count++;
		}
	}
	return count;
}
}
