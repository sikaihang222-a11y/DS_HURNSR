package test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import util.ReadFileToList;
import util.WriteDataBase;
/**
 * 将序列文件添加效用，生成数据集
 * @author Administrator
 *
 */
public class Test_Seq_Data {

	public static void main(String[] args) throws IOException{
		ReadFileToList rL = new ReadFileToList();
		//存储序列的文件（不含有效用值）
		FileReader fr = new FileReader("C8_T4_S6_I4_DB10k_N1k.data");
		BufferedReader bf = new BufferedReader(fr);
		String str;
		//存储效用的文件
		String utilityfilename ="data/utility1k.txt";
		List<String> utilityList = new ArrayList<String>();
		//读取效用文件
		utilityList = rL.ReadFileToList(utilityfilename);
		String filename ="seq_data.txt";
		Random rand = new Random();
		WriteDataBase wDB =new WriteDataBase();
		Map<Integer,Integer> item = new HashMap<Integer,Integer>();
		for (int i = 0; i < utilityList.size(); i++) {
			//将项和效用存储到Map中
			item.put(i, Integer.valueOf(utilityList.get(i)));
		}
		// 按行读取字符串
		while ((str = bf.readLine())  != null) {
			//随机生成次数
			int r = rand.nextInt(10)+1;
			//去除字符串中首尾的空格
			String str1= str.trim();
			//将中间的空格替换为tab
			String str2= str1.replace("      ", "	");
			//去掉字符串中间未被替换为tab的空格
			String str3= str2.replaceAll(" ", "");
			//获取序列中文件中的项
			String itemstr = str3.substring(str3.lastIndexOf("	")+1);
			//将字符串转为int
			Integer itemint = Integer.parseInt(itemstr);
			Integer utility = item.get(itemint) * r;
			String str4 =str3+"	"+utility;
			//写文件
			wDB.writedatabase(str4, filename);
		}
		bf.close();
		fr.close();
	}
}
