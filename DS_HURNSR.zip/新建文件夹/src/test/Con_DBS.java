package test;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Con_DBS {

    public static class StructuredElement {

        int rowNumber;
        int subArrayNumber;
        int element;
        double randomValue;

        public StructuredElement(int rowNumber, int subArrayNumber, int element, double randomValue) {
            this.rowNumber = rowNumber;
            this.subArrayNumber = subArrayNumber;
            this.element = element;
            this.randomValue = randomValue;
        }

        @Override
        public String toString() {
            return rowNumber + " " + subArrayNumber + " " + element + " " + randomValue;
        }
    }

    public static List<StructuredElement> readAndStructureTextSequence(String filePath) {
        List<StructuredElement> structuredElements = new ArrayList<>();
        Random random = new Random();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            int rowNumber = 1;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\s+");
                int totalLength = Integer.parseInt(parts[0]);
                int index = 1;

                for (int i = 1; i <= totalLength; i++) {
                    int itemsetLength = Integer.parseInt(parts[index]);
                    index++;
                    for (int j = 1; j <= itemsetLength; j++) {
                        int element = Integer.parseInt(parts[index]);
                        index++;
                        double randomValue = 0;
                        while (randomValue == 0) {
                            randomValue = Math.round(random.nextDouble() * 100.0 * 10.0) / 10.0; // 生成范围在0到100之间的随机数, 保留一位小数
                        }
                        structuredElements.add(new StructuredElement(rowNumber, i, element, randomValue));
                    }
                }
                rowNumber++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return structuredElements;
    }

    public static void saveStructuredElementsToFile(List<StructuredElement> elements, String outputFilePath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFilePath))) {
            for (StructuredElement element : elements) {
                bw.write(element.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String filePath = "E:\\Desktop\\USpan+Optimal2\\dateset\\dataFactor\\C6T2S4I3DB10KN50.data";  // filein
        String outputFilePath = "C6T2S4I3DB10KN50.txt";  // fileoutput
        List<StructuredElement> structuredElements = readAndStructureTextSequence(filePath);

        for (StructuredElement element : structuredElements) {
            System.out.println(element);
        }
        saveStructuredElementsToFile(structuredElements, outputFilePath);
    }
}
