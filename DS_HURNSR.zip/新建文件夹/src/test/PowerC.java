package test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class PowerC {

    public static void main(String[] args) {
        String inputFilePath = "E:\\Desktop\\USpan+Optimal2\\dateset\\realDataset\\POWERC.txt"; // 输入文件路径
        String outputFilePath = "POWERC.txt"; // 输出文件路径
        Random random = new Random(); // 用于生成随机效用值

        try (BufferedReader br = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter bw = new BufferedWriter(new FileWriter(outputFilePath))) {

            String line;
            int lineNumber = 1;
            int maxLines = 500000; // 处理前500000行

            while ((line = br.readLine()) != null && lineNumber <= maxLines) {
                String[] numbers = line.split(" ");
                int bracketNumber = 1;

                // 定义括号的开始和结束索引
                int[][] brackets = {{0, 1}, {2, 3}, {4, 6}};

                for (int[] bracket : brackets) {
                    for (int i = bracket[0]; i <= bracket[1]; i++) {
                        if (i < numbers.length) {
                            int utility = (int) (random.nextGaussian() * 15 + 50); // 生成正态分布的随机效用值
                            if (utility < 0) {
                                utility = 0;
                            } else if (utility > 100) {
                                utility = 100;
                            }
                            String result = lineNumber + " " + bracketNumber + " " + numbers[i] + " " + utility;
                            bw.write(result);
                            bw.newLine();
                        }
                    }
                    bracketNumber++;
                }

                lineNumber++;
            }

            System.out.println("转换完成！输出文件路径：" + outputFilePath);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
