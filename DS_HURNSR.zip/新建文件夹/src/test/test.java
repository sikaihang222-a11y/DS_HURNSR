package test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import util.StrCount;

public class test {
	public static void main(String[] args) throws IOException {
		String seqLine = " 1[45] -1 2[7] -1 3[54] -1 4[10] -1 5[20] -1 6[24] -1 7[60] -1 8[16] -1 9[30] -1 10[6] -1 11[9] -1 12[5] -1 13[60] -1 14[12] -1 15[64] -1 16[18] -1 17[6] -1 18[20] -1 19[18] -1 20[28] -1 21[16] -1 22[24] -1 23[20] -1 24[20] -1 5[2] -1 25[16] -1 16[2] -1 26[12] -1 27[36] -1 28[8] -1 29[48] -1 30[15] -1 31[16] -1 32[6] -1 33[5] -1 34[36] -1 35[50] -1 33[1] -1 36[10] -1 37[6] -1 38[7] -1 10[4] -1 39[4] -1 -2  SUtility:876";
		String seq = seqLine.replace(" ", "");
		seq = seq.substring(0, seq.indexOf("-2"));
		int itemset = 1;
		StrCount sc = new StrCount();
		File fout = new File("E:/token.txt");
		FileOutputStream fos = new FileOutputStream(fout,true);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		for (int i = 0; i <= sc.countStr(seqLine, "-1"); i++) {
			if (seq.length() != 0) {
				System.out.print(1 + "	");
				System.out.print(itemset + "	");
				System.out.print(seq.substring(0, seq.indexOf("[")) + "	");
				System.out.println(seq.substring(seq.indexOf('[') + 1, seq.indexOf(']')));
				String newseq = 1 + "	" + itemset + "	" + seq.substring(0, seq.indexOf("[")) + "	"
						+ seq.substring(seq.indexOf('[') + 1, seq.indexOf(']'));
				seq = seq.substring(seq.indexOf("-1") + 2);// 删除已经输出的子串
				itemset++;
				bw.write(newseq);
				bw.newLine();
			}
		}
		bw.close();
	}
}
