package test;

import java.util.List;

import USpanPlusOptimal.Pattern;
import util.Itemset;
import util.Post;

public class Test_fond {

	public void findLuvUtility(List<Pattern> seqList, List<List<Integer>> XX, List<List<Integer>> ZZ) {
		Itemset itemX = new Itemset();
		itemX.setItemSetIndex(XX);
		Itemset itemXe = new Itemset(itemX);
		//pattern1.setItemsets(XX);
		//pattern2.setItemsets(ZZ);
		Itemset itemZ = new Itemset();
		itemZ.setItemSetIndex(ZZ);
		Itemset itemZe = new Itemset(itemZ);
		Post post = new Post();
		List<List<Integer>> X = post.getPosFromSeqList(itemXe.getItemSetIndex());// 取正
		List<List<Integer>> Z = post.getPosFromSeqList(itemZe.getItemSetIndex());
		//System.out.println("查找Z*******");
		for (int i = 0; i < seqList.size(); i++) {
			Pattern pattern = new Pattern(seqList.get(i));
			//System.out.println("*******序列的下标"+i+"**********");
			if (pattern.getItemsets().toString().equals(Z.toString())) {
				System.out.println("找到Z： "+ Z.toString());
				break;
			}
		}
	}
}
