package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.ndktools.javamd5.Mademd5;

import java.io.Serializable;

public class  TestList{
public static void main(String[] args) {
	
//	private static boolean checkDiffrent1(List<String> list, List<String> list1) {
//        long st = System.nanoTime();
//        System.out.println("消耗时间为：" + (System.nanoTime() - st));
//        return !list.retainAll(list1);
//    }   单层for循环
	
	
	
	
//	
//	String str ="11*11*34*23*123*";
//	//String str1 = "11*11*34*23*";
//	List<Integer> list =new ArrayList<Integer>();
//	for (int i = 0; i < str.length(); i++) {
//		String s=str.charAt(i)+"";
//		if(s.equals("*")){
//			list.add(i);
//		}
//	}
//	//String ss = str.substring(0,list.get((list.size()-1)-1) +1);
//	//String ss = str.substring(list.get(list.size()-2)+1);
//	String ss = str.substring(0,list.get(list.size()-1-4)+1);
//	System.out.println(ss);
	
	
	
	
	ArrayList<ArrayList<Integer>> list1 = new ArrayList<ArrayList<Integer>>();
	ArrayList<ArrayList<Integer>> list2 = new ArrayList<ArrayList<Integer>>();
	ArrayList<Integer> list11= new ArrayList<Integer>();
	ArrayList<Integer> list12= new ArrayList<Integer>();
	ArrayList<Integer> list21= new ArrayList<Integer>();
	ArrayList<Integer> list22= new ArrayList<Integer>();
	list11.add(1);
	list11.add(2);
	list11.add(3);
	list12.add(4);
	list12.add(5);
	list12.add(6);
	list21.add(1);
	list21.add(2);
	list21.add(3);
	list22.add(4);
	list22.add(5);
	list22.add(6);
	list1.add(list11);
	list1.add(list12);
	list2.add(list21);
	list2.add(list22);
	
//	if(list1.size()==list2.size()){
//	for (int i = 0; i < list1.size(); i++) {
//	boolean flag =	list1.get(i).retainAll(list2.get(i));
//	System.out.println(flag);
//	}
// }
	Integer flag = 0;
	for (int i = 0; i < list1.size(); i++) {
		for (int j = 0; j < list1.get(i).size(); j++) {
			if(list1.get(i).get(j)!=list2.get(i).get(j)){
				return;
			}
		}
	}
	System.out.println(flag);
	Mademd5 md5 = new Mademd5();
	String s =list1.toString();
	String s1 =list2.toString();
	//boolean flag =s.equals(s1);
	System.out.println(flag);
	
}
}
