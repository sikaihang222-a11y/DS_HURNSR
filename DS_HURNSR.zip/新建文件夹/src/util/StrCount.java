package util;
/**
 * 
 *统计字符串出现的次数
 *
 */
public class StrCount {
	/**
	 * 统计字符串出现的次数
	 * @param str
	 * @param key
	 * @return
	 */
	public int countStr(String str, String key){
		int count=0;//用于数总次数；
		int index,index1=0;
		int n=1;//用于每次显示次数
		if(str.contains(key))
		{
			while((index=str.indexOf(key))!=-1)
			{   
				str=str.substring(index + key.length());//在数到一个后，马上找到新的字符串进行搜索
				index1=(index+index1+key.length());//这里比较巧妙的加上上一次的索引和key的长度以显示在整个父字符串中的位置
				count++;
			}
		}
		return count;
	}
}
