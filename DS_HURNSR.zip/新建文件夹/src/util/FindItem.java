package util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import USpanPlusOptimal.Pattern;

/**
 * 查找Item
 * 
 * @author Administrator
 *
 */
public class FindItem {
	/**
	 * 查找LUV的效用值
	 * 
	 * @param seqList
	 * @param X
	 * @param Z
	 * @return
	 */
	public Double findLuvUtility(List<Pattern> seqList, List<List<Integer>> XX, List<List<Integer>> ZZ) {
		Double sumutility = 0.0;
		Double Xutility = 0.0;
		Pattern pattern;
		Pattern pattern1;
		Itemset itemX = new Itemset();
		itemX.setItemSetIndex(XX);
		Itemset itemXe = new Itemset(itemX);
		Itemset itemZ = new Itemset();
		itemZ.setItemSetIndex(ZZ);
		Itemset itemZe = new Itemset(itemZ);
		Post post = new Post();
		List<List<Integer>> X = post.getPosFromSeqList1(itemXe.getItemSetIndex());// 取正
		List<List<Integer>> Z = post.getPosFromSeqList1(itemZe.getItemSetIndex());
		preItemIndex pII = new preItemIndex();
		ArrayList<String> Sid = new ArrayList<String>();
		ArrayList<String> Tid = new ArrayList<String>();
		boolean flag = false;
		int Xlength = 0;
		int Zlength = 0;
		// 求X和Z的项的个数
		for (int i = 0; i < X.size(); i++) {
			Xlength = Xlength + X.get(i).size();
		}
		for (int i = 0; i < Z.size(); i++) {
			Zlength = Zlength + Z.get(i).size();
		}
		for (int i = 0; i < seqList.size(); i++) {
			pattern = new Pattern(seqList.get(i));
			if (pattern.getItemsets().toString().equals(Z.toString())) {
				flag = true;
				ArrayList<ArrayList<Double>> Sequtility = pattern.getSequtility();
				ArrayList<ArrayList<String>> SeqIndex = pattern.getSeqIndex();
				ArrayList<Integer> utilityIndex = new ArrayList<Integer>();
				for (int j = 0; j < Sequtility.size(); j++) {
					// 存储集合中最大效用的下标
					utilityIndex.add(Sequtility.get(j).indexOf(Collections.max(Sequtility.get(j))));
				}
				for (int j = 0; j < SeqIndex.size(); j++) {
					Tid.add(SeqIndex.get(j).get(utilityIndex.get(j)));
				}
				// 应该存储的是删除后件项集号的项集号
				Tid = pII.findpreItemIndex(Zlength - Xlength, Tid);
				// 通过Sid确定前件X序列的位置，根据Tid中的项集号确定下标，根据下标获取X的效用值。
				Sid = pattern.getSid();
			}
			if (flag) {
				for (int j = 0; j < seqList.size(); j++) {
					pattern1 = new Pattern(seqList.get(j));
					if (pattern1.getItemsets().toString().equals(X.toString())) {// 当他俩相等的时候
						ArrayList<String> sid = pattern1.getSid();
						ArrayList<ArrayList<Double>> Sequtility = pattern1.getSequtility();
						ArrayList<ArrayList<String>> SeqIndex = pattern1.getSeqIndex();
						for (int k = 0; k < Sequtility.size(); k++) {
							Xutility= Xutility+Collections.max(Sequtility.get(k));
						}
						for (int j1 = 0; j1 < Sid.size(); j1++) {
							int a = sid.indexOf(Sid.get(j1));
							String tid = Tid.get(j1);
							ArrayList<String> indexs = SeqIndex.get(a);
							ArrayList<Double> utilitys = Sequtility.get(a);
							int b = indexs.indexOf(tid);
							sumutility = sumutility + utilitys.get(b);
						}
						break;
					}
				}
				break;
			}
		}
		return sumutility / Xutility;
	}
}
