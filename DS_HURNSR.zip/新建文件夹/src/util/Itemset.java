package util;

import java.util.ArrayList;
import java.util.List;

public class Itemset {
	private List<List<Integer>> ItemSetIndex;//存储连接项所在项集的编号

	public List<List<Integer>> getItemSetIndex() {
		return ItemSetIndex;
	}

	public void setItemSetIndex(List<List<Integer>> itemSetIndex) {
		ItemSetIndex = itemSetIndex;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	public Itemset() {}
	
	public Itemset(Itemset itemset) {
		super();
		this.ItemSetIndex = new ArrayList<List<Integer>>();
		for (int i = 0; i < itemset.getItemSetIndex().size(); i++) // 外层循环：一个序列中从第一个项集读取到最后一个项集
		{
			ArrayList<Integer> temp = new ArrayList<Integer>(); // 新建一个临时List集合，存放模式
			for (int j = 0; j < itemset.getItemSetIndex().get(i).size(); j++) // 内层循环：一个项集中从第一个项读到最后一个项
			{
				temp.add(itemset.getItemSetIndex().get(i).get(j)); // 将项挨个添加到temp中
			}
			this.ItemSetIndex.add(temp); // 将一个完整的项集添加到itemsets中
		}
	}
	
	
	
	
	
	
}
