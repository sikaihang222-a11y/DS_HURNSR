package util;

import java.util.List;

public class Post {
	// 求负序列对应的正序列
		public List<List<Integer>> getPosFromSeqList(List<List<Integer>> Itemsets) {
			List<List<Integer>> Itemset =Itemsets;
			for (int i = 0; i < Itemset.size(); i++) {
				for (int j = 0; j < Itemset.get(i).size(); j++) {
					if(Itemset.get(i).get(j)<0){
						Itemset.get(i).remove(j);
					}
				}
				if(Itemset.get(i).isEmpty()){
					Itemset.remove(i);
				}
			}
			return Itemset;
		}
		public List<List<Integer>> getPosFromSeqList1(List<List<Integer>> Itemsets) {
			List<List<Integer>> Itemset =Itemsets;
			boolean flag=false;
			for (int i = 0; i < Itemset.size(); i++) {
				for (int j = 0; j < Itemset.get(i).size(); j++) {
					if(Itemset.get(i).get(j)<0){
						flag =true;
					}
				}
				if(flag){
					Itemset.remove(i);
					flag=false;
				}
			}
			return Itemset;
		}
}
