package util;

import java.util.ArrayList;

/**
 * 存储项集序列
 * @author Administrator
 *
 */
public class ItemObject {
    private String itemid;//编码后的连接项id
    private ArrayList<String> seqid;//存储序列号
    private ArrayList<ArrayList<String>> ItemSetIndex;//存储连接项所在项集的编号
    private ArrayList<ArrayList<Double>> ItemSetUtility;//存储连接项所在项集的效用
    private ArrayList<ArrayList<String>> ItemLength;//当前添加项的长度。用于确定项集号的位数
    private ArrayList<ArrayList<ArrayList<String>>> newItemLength;//当前添加项的长度。用于确定项集号的位数

    public ArrayList<ArrayList<ArrayList<String>>> getNewItemLength() {
        return newItemLength;
    }
    public void setNewItemLength(ArrayList<ArrayList<ArrayList<String>>> newItemLength) {
        this.newItemLength = newItemLength;
    }
    private Double Sumutility;//总效用
    public String getItemid() {
        return itemid;
    }
    public void setItemid(String itemid) {
        this.itemid = itemid;
    }
    public ArrayList<String> getSeqid() {
        return seqid;
    }
    public void setSeqid(ArrayList<String> seqid) {
        this.seqid = seqid;
    }
    public ArrayList<ArrayList<String>> getItemSetIndex() {
        return ItemSetIndex;
    }
    public void setItemSetIndex(ArrayList<ArrayList<String>> itemSetIndex) {
        ItemSetIndex = itemSetIndex;
    }
    public ArrayList<ArrayList<Double>> getItemSetUtility() {
        return ItemSetUtility;
    }
    public void setItemSetUtility(ArrayList<ArrayList<Double>> itemSetUtility) {
        ItemSetUtility = itemSetUtility;
    }
    public ArrayList<ArrayList<String>> getItemLength() {
        return ItemLength;
    }
    public void setItemLength(ArrayList<ArrayList<String>> itemLength) {
        ItemLength = itemLength;
    }
    public Double getSumutility() {
        return Sumutility;
    }
    public void setSumutility(Double sumutility) {
        Sumutility = sumutility;
    }

}
