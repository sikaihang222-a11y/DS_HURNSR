package util;

import java.util.ArrayList;
import java.util.List;

public class preItemIndex {
    /*--
    是处理一个包含字符串的 ArrayList，对于其中的每个字符串，找到其从开头到倒数第 i+1 个 * 字符的子字符串，
    并将这些子字符串存储在一个新的 ArrayList 中返回。
    i:后件首项 ，tid：最大效用对应的序列索引
     */
    public ArrayList<String> findpreItemIndex(int i, ArrayList<String> tid){
        ArrayList<String> preTid = new ArrayList<String>();
        for (int j = 0; j < tid.size(); j++) {
            String str = tid.get(j);//str = "0*2*"
            List<Integer> list =new ArrayList<Integer>();
            for (int i1 = 0; i1 < str.length(); i1++) {
                String s=str.charAt(i1)+"";
                if(s.equals("*")){
                    list.add(i1);
                }
            }
            //String ss = str.substring(0,list.get((list.size()-i)-1) +1);
            String ss = str.substring(0,list.get(list.size()-1-i)+1);//即截取 str 的前 2 个字符 → "0*"
            preTid.add(ss);
        }
        return preTid;
    }
}
