package util;

import java.util.ArrayList;
import java.util.List;

import USpanPlusOptimal.Pattern;

public class Compare {
    public boolean compareList(Pattern pattern, List<List<Integer>> ZZ) {
        ArrayList<ArrayList<Integer>> SeqIndex = pattern.getItemsets();
        if (SeqIndex.size() == ZZ.size()) {
            for (int i = 0; i < SeqIndex.size(); i++) {
                if (SeqIndex.get(i).size() == ZZ.get(i).size()) {
                    // if (SeqIndex.get(i).containsAll(ZZ.get(i)) &&
                    // ZZ.get(i).containsAll(SeqIndex.get(i))) {
                    // return true;
                    // }
                    for (int j = 0; j < SeqIndex.get(i).size(); j++) {
                        if (SeqIndex.get(i).get(j) != ZZ.get(i).get(j)) {
                            return false;
                        }
                    }
                } else {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}
