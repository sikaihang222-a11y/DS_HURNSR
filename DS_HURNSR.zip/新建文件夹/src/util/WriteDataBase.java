package util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class WriteDataBase {
	public void writedatabase(String content, String filename) throws IOException {
		File fout = new File(filename);
		FileOutputStream fos = new FileOutputStream(fout, true);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write(content);
		bw.newLine();
		bw.close();
	}
}
