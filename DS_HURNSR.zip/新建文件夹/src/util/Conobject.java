package util;

import java.util.List;

/**
 * 高效序列生成中间变量对象
 * @author Administrator
 *
 */
public class Conobject {
	private int seqid;//当前项所出现在的序列
	private List<String> ItemsetIndex;//当前项所对应的项的集合；
	private int ItemId;//当前项所对应的项的集合；
	private List<Double> utility;//当前项所对应的项的效用的集合和 Itemid一一对应
	private double sumutility;//当前序列总的效用值
	private List<String> seq;//存储生成的序列
	private String countSeq;
	
	
	
	public String getCountaeq() {
		return countSeq;
	}
	public void setCountaeq(String countaeq) {
		this.countSeq = countaeq;
	}
	public List<String> getSeq() {
		return seq;
	}
	public void setSeq(List<String> seq) {
		this.seq = seq;
	}
	public List<String> getItemsetIndex() {
		return ItemsetIndex;
	}
	public void setItemsetIndex(List<String> itemsetIndex) {
		ItemsetIndex = itemsetIndex;
	}
	public double getSumutility() {
		return sumutility;
	}
	public void setSumutility(double sumutility) {
		this.sumutility = sumutility;
	}
	public int getSeqid() {
		return seqid;
	}
	public void setSeqid(int seqid) {
		this.seqid = seqid;
	}
	public int getItemId() {
		return ItemId;
	}
	public void setItemId(int itemId) {
		ItemId = itemId;
	}
	public List<Double> getUtility() {
		return utility;
	}
	public void setUtility(List<Double> utility) {
		this.utility = utility;
	}
	
	
}
