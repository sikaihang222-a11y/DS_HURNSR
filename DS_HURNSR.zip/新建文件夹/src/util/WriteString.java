package util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * 写入字符串
 * 
 * @author Administrator
 *
 */
public class WriteString {
	/**
	 * 写入字符串
	 * 
	 * @param sid
	 * @param content
	 * @param filename
	 */
	public void writeString(int sid, String content, String filename) throws IOException {
		String seq = content.replace(" ", "");
		seq = seq.substring(0, seq.indexOf("-2"));
		int itemset = 1;
		StrCount sc = new StrCount();
		File fout = new File(filename);
		FileOutputStream fos = new FileOutputStream(fout,true);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		for (int i = 0; i <= sc.countStr(content, "-1"); i++) {
			if (seq.length() != 0) {
				String newseq = sid + "	" + itemset + "	" + seq.substring(0, seq.indexOf("[")) + "	"
						+ seq.substring(seq.indexOf('[') + 1, seq.indexOf(']'));
				seq = seq.substring(seq.indexOf("-1") + 2);// 删除已经输出的子串
				itemset++;
				bw.write(newseq);
				bw.newLine();
			}
		}
		bw.close();
	}
}
