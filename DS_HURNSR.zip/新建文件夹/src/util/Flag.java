package util;
/**
 * 连接返回状态对象
 * @author Administrator
 *
 */
public class Flag {
    private boolean flag;

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

}
