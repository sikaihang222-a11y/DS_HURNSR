package util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadFileToList {
	public List<String> ReadFileToList(String filename)throws IOException{
		List<String> datalist = new ArrayList<String>();
		FileReader fr;
		BufferedReader bf =null;
		String str;
			fr = new FileReader(filename);
			bf = new BufferedReader(fr);
			while ((str = bf.readLine())  != null) {
				int count = CountTab(str);
				for (int i = 0; i <=count; i++) {
					//取整数部分
					String newstr = str.substring(0, str.indexOf("."));
					str = str.substring(str.indexOf("	") + 1);
					String str1 = newstr.trim();
					datalist.add(str1);
					System.out.print(str1+" ");
				}
				System.out.println();
			}
			bf.close();
			fr.close();
		return datalist;
	}
	public static int CountTab(String str){
		int count=0;//用于数总次数；
		int index,index1=0;
		int n=1;//用于每次显示次数
		String key ="	";
		if(str.contains(key))
		{
			while((index=str.indexOf(key))!=-1)
			{   
				str=str.substring(index + key.length());//在数到一个后，马上找到新的字符串进行搜索
				index1=(index+index1+key.length());//这里比较巧妙的加上上一次的索引和key的长度以显示在整个父字符串中的位置
				count++;
			}
		}
		return count;
	}
}
