package Rule;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import USpanPlusOptimal.Pattern;
/**
 * Feb 29,2024
 * GeneRule关于规则的不必理会
 */
public class GeneRule {	
	// 前件X
	private List<List<Integer>> ante;
	// 后件Y
	private List<List<Integer>> conse;
	// 效用增长率
	private double UIR;
	//public static double UThreshold;

	public List<List<Integer>> getAnte() {
		return ante;
	}

	public void setAnte(List<List<Integer>> ante) {
		this.ante = ante;
	}

	public List<List<Integer>> getConse() {
		return conse;
	}

	public void setConse(List<List<Integer>> conse) {
		this.conse = conse;
	}

	public double getUIR() {
		return UIR;
	}

	public void setUIR(double uIR) {
		UIR = uIR;
	}

	public GeneRule(List<List<Integer>> ante, List<List<Integer>> conse, double uIR) {
		super();
		this.ante = ante;
		this.conse = conse;
		UIR = uIR;
	}

	public GeneRule() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param NegHightUtilitySeqList
	 * @param UIR
	 * @return
	 */
	public List<GeneRule> geneRule(List<Pattern> NegHightUtilitySeqList, double uir) {
		// 存储负高效序列及其效用值
		Map<ArrayList<ArrayList<Integer>>, Double> AllNegHightUtilitySeqMap = new HashMap<ArrayList<ArrayList<Integer>>, Double>();

		for (int i = 0; i < NegHightUtilitySeqList.size(); i++) {
			AllNegHightUtilitySeqMap.put(NegHightUtilitySeqList.get(i).getItemsets(),
					NegHightUtilitySeqList.get(i).getUtility());
		}
		//存储规则集合
		List<GeneRule> RuleList= new ArrayList<GeneRule>();
        //遍历每一条高效用序列，生成规则
		for (ArrayList<ArrayList<Integer>> negtemp : AllNegHightUtilitySeqMap.keySet()) {
			//负序列size大于2时才生成规则
			if (negtemp.size() > 2) {
				
				for (int i = 0; i < negtemp.size() - 1; i++) {
					//前件X
					List<List<Integer>> X = new ArrayList<List<Integer>>();
					//后件Y
					List<List<Integer>> Y = new ArrayList<List<Integer>>();
					//创建对象
					GeneRule geRule = new GeneRule();
					X.addAll(negtemp.subList(0, i + 1));
					Y.addAll(negtemp.subList(i + 1, negtemp.size()));
					if (AllNegHightUtilitySeqMap.containsKey(X)
							&& (Y.size() > 1 || Y.size() == 1 && Y.get(0).get(0) > 0)) {
						UIR = AllNegHightUtilitySeqMap.get(negtemp)/AllNegHightUtilitySeqMap.get(X);
						if (UIR>1) {
							geRule.setAnte(X);
							geRule.setConse(Y);
							geRule.setUIR(UIR);
							RuleList.add(geRule);
						}

					}
					
				}

			}

		}

		return RuleList;

	}

}
