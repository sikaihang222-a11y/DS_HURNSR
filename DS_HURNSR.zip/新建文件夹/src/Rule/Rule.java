package Rule;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import USpanPlusOptimal.Pattern;
import util.FindItem;
import util.WriteString;

/**
 * Feb 29,2024
 * 不必理会
 * Uconf生成规则
 * 
 * @author Administrator
 *
 */
public class Rule {
	// 前件X
	private List<List<Integer>> ante;
	// 后件Y
	private List<List<Integer>> conse;
	// 效用置信度
	private Double uconf;

	public List<List<Integer>> getAnte() {
		return ante;
	}

	public void setAnte(List<List<Integer>> ante) {
		this.ante = ante;
	}

	public List<List<Integer>> getConse() {
		return conse;
	}

	public void setConse(List<List<Integer>> conse) {
		this.conse = conse;
	}

	public Double getUconf() {
		return uconf;
	}

	public void setUconf(Double uconf) {
		this.uconf = uconf;
	}

	/**
	 * Uconf 生成规则
	 * 
	 * @param NegHightUtilitySeqList
	 * @param SeqList
	 * @param uconf
	 * @return
	 */
	public List<Rule> geneRule(List<Pattern> NegHightUtilitySeqList, List<Pattern> SeqList, double ucon) {
		Map<ArrayList<ArrayList<Integer>>, Double> AllNegHightUtilitySeqMap = new HashMap<ArrayList<ArrayList<Integer>>, Double>();
		for (int i = 0; i < NegHightUtilitySeqList.size(); i++) {
			AllNegHightUtilitySeqMap.put(NegHightUtilitySeqList.get(i).getItemsets(),
					NegHightUtilitySeqList.get(i).getUtility());
		}
		// 存储规则集合
		List<Rule> RuleList = new ArrayList<Rule>();
		FindItem fm = new FindItem();
		// 遍历每一条高效用序列，生成规则
		for (ArrayList<ArrayList<Integer>> negtemp : AllNegHightUtilitySeqMap.keySet()) {
			// 负序列size大于2时才生成规则
			if (negtemp.size() > 2) {
				for (int i = 0; i < negtemp.size() - 1; i++) {
					// 前件X
					List<List<Integer>> X = new ArrayList<List<Integer>>();
					// 后件Y
					List<List<Integer>> Y = new ArrayList<List<Integer>>();
					// X&Y
					List<List<Integer>> Z = new ArrayList<List<Integer>>();
					X.addAll(negtemp.subList(0, i + 1));
					Y.addAll(negtemp.subList(i + 1, negtemp.size()));
					Z.addAll(X);
					Z.addAll(Y);
					if ((X.size() > 1 || X.size() == 1 && X.get(0).get(0) > 0)
							&& (Y.size() > 1 || Y.size() == 1 && Y.get(0).get(0) > 0)) {
						Double uconf = fm.findLuvUtility(SeqList, X, Z);
						if (uconf > ucon) {
							// 创建对象
							Rule rule = new Rule();
							rule.setAnte(X);
							rule.setConse(Y);
							rule.setUconf(uconf);
							//System.out.println(uconf);
							RuleList.add(rule);
						}
						Z.clear();
						System.out.println("Uconf生成规则: " + X + "------" + Y + " uconf: " + uconf);

					}
				}

			}

		}

		return RuleList;
	}

}
