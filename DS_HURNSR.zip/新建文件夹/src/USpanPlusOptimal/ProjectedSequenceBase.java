package USpanPlusOptimal;

import java.util.*;

public class ProjectedSequenceBase
{
	private double seqbaseUtility;
	private int numerOfItems;

	private double[] utiTable;
	private int[] concItems;
	private int[] readyForConc;
	private int[] countFlag;
	private Pattern candidate;

	public final double getSeqbaseUtility()
	{
		return seqbaseUtility;
	}
	public final void setSeqbaseUtility(double value)
	{
		seqbaseUtility = value;
	}
	public final int getNumerOfItems()
	{
		return numerOfItems;
	}
	public final void setNumerOfItems(int value)
	{
		numerOfItems = value;
	}
	public final double[] getUtiTable()
	{
		return utiTable;
	}
	public final void setUtiTable(double[] value)
	{
		utiTable = value;
	}
	public final int[] getConcItems()
	{
		return concItems;
	}
	public final void setConcItems(int[] value)
	{
		concItems = value;
	}
	public final int[] getReadyForConc()
	{
		return readyForConc;
	}
	public final void setReadyForConc(int[] value)
	{
		readyForConc = value;
	}
	public final int[] getCountFlag()
	{
		return countFlag;
	}
	public final void setCountFlag(int[] value)
	{
		countFlag = value;
	}
	public final Pattern getCandidate()
	{
		return candidate;
	}
	public final void setCandidate(Pattern value)
	{
		candidate = value;
	}
	public final int getNumberOfSequences()
	{
		return numberOfSequences;
	}
	public final void setNumberOfSequences(int value)
	{
		numberOfSequences = value;
	}

	public ArrayList<Sequence> Seqbase;

	private int[] SeqIDs;
	private int numberOfSequences;

	private Item[][] ItemPointers;
	private double[][] CanUtilities;
	private int[] NumberOfPts;
	private int ProjItem;

	private double[] LeftMostUtilities;
	public double LeftUti;

	private double[] MaxUtilities;

	private double candidateUtility;
	public final double getCandidateUtility()
	{
		return candidateUtility;
	}
	public final void setCandidateUtility(double value)
	{
		candidateUtility = value;
	}

	private int[] blackList;

	private ArrayList<Integer> sConcItems_USpan;
	public final ArrayList<Integer> getSConcItems_USpan()
	{
		return sConcItems_USpan;
	}
	public final void setSConcItems_USpan(ArrayList<Integer> value)
	{
		sConcItems_USpan = value;
	}
	private ArrayList<Integer> iConcItems_USpan;
	public final ArrayList<Integer> getIConcItems_USpan()
	{
		return iConcItems_USpan;
	}
	public final void setIConcItems_USpan(ArrayList<Integer> value)
	{
		iConcItems_USpan = value;
	}

	public ProjectedSequenceBase(ArrayList<Sequence> Seqbase, double SeqbaseUtility)
	{
		this.candidate = new Pattern();
		//this.Projectedsequencebase = new List<ProjectedSequence>();
		//this.spromisingitems = new Dictionary<int, double>();
		//this.ipromisingitems = new Dictionary<int, double>();

		this.Seqbase = Seqbase;
		this.seqbaseUtility = SeqbaseUtility;

		this.SeqIDs = null;
		this.MaxUtilities = null;
		this.numberOfSequences = 0;
		this.ItemPointers = null;
		this.CanUtilities = null;
		this.NumberOfPts = null;
		this.ProjItem = -1; // -1 means NOT_INITIALIATED

		this.LeftUti = 0;

		this.candidateUtility = 0;

		this.utiTable = new double[USpanPlus.NumberOfDistinctItems];
		this.concItems = new int[USpanPlus.NumberOfDistinctItems];
		this.readyForConc = new int[USpanPlus.NumberOfDistinctItems];
		this.countFlag = new int[USpanPlus.NumberOfDistinctItems];

		this.blackList = new int[USpanPlus.NumberOfDistinctItems];

		//this.sConcList = new Dictionary<int, double>();
		//this.iConcList = new Dictionary<int, double>();

		//this.sConcListOriginal = new Dictionary<int, double>();
		//this.iConcListOriginal = new Dictionary<int, double>();
	}

	public ProjectedSequenceBase(ProjectedSequenceBase projbase)
	{
		this.candidate = new Pattern();
		//this.Projectedsequencebase = new List<ProjectedSequence>();
		//this.spromisingitems = new Dictionary<int, double>();
		//this.ipromisingitems = new Dictionary<int, double>();

		this.Seqbase = projbase.Seqbase;
		this.seqbaseUtility = getSeqbaseUtility();


		this.SeqIDs = null;
		this.MaxUtilities = null;
		this.numberOfSequences = 0;
		this.ItemPointers = null;
		this.CanUtilities = null;
		this.NumberOfPts = null;
		this.ProjItem = -1; // -1 means NOT_INITIALIATED

		this.LeftUti = 0;

		this.candidateUtility = 0;

		this.utiTable = new double[USpanPlus.NumberOfDistinctItems];
		this.concItems = new int[USpanPlus.NumberOfDistinctItems];
		this.readyForConc = new int[USpanPlus.NumberOfDistinctItems];
		this.countFlag = new int[USpanPlus.NumberOfDistinctItems];


		this.blackList = (int[])projbase.blackList.clone();

		//this.copySConcList(projbase.sConcList);
		//this.sConcList = new Dictionary<int, double>(projbase.sConcList);
		//this.iConcList = new Dictionary<int, double>(projbase.iConcList);

		//this.sConcListOriginal = new Dictionary<int, double>(projbase.sConcList);
		//this.iConcListOriginal = new Dictionary<int, double>(projbase.iConcList);
		//this.setSconcList();
	}

	public final void ProjectedSequenceBaseInit()
	{
		//this->NumberOfItems = new int[1];
		//this->NumberOfItems[0] = 1;
		this.numberOfSequences = this.Seqbase.size();
		this.SeqIDs = new int[this.numberOfSequences];
		this.MaxUtilities = new double[this.numberOfSequences];
		this.ItemPointers = new Item[this.numberOfSequences][];
		this.CanUtilities = new double[this.numberOfSequences][];
		this.NumberOfPts = new int[this.numberOfSequences];
		this.LeftUti = this.seqbaseUtility;

		this.candidateUtility = 0;
		for (int i = 0;i < this.Seqbase.size();i++)
		{
			this.SeqIDs[i] = i;
			this.MaxUtilities[i] = 0;
			this.ItemPointers[i] = null;
			this.CanUtilities[i] = null;
			this.NumberOfPts[i] = 0;
		}

		//this.scanSWU();
		//this.scanItems();
		//this.setSconcList();
	}

	public final void Clear()
	{
		System.out.println("进入clear");
		/*
		Array.Clear(this.countFlag, 0, this.countFlag.length);
		Array.Clear(this.utiTable, 0, this.utiTable.length);
		Array.Clear(this.readyForConc, 0, this.readyForConc.length);
		Array.Clear(this.concItems, 0, this.concItems.length);
		*/
		this.countFlag = new int[this.countFlag.length];
		this.utiTable =  new double[this.utiTable.length];
		this.readyForConc = new int[this.readyForConc.length];
		this.concItems = new int[this.concItems.length];
		
		this.numerOfItems = 0;
		
	}

	public final void iScan()
	{
		int index, bound, sid, isidx;
		this.numerOfItems = 0;

		this.Clear();
		for (int i = 0; i < this.numberOfSequences; i++)
		{
			sid = this.SeqIDs[i];
			double seqbound = this.Seqbase.get(sid).getSequenceUtility();
			if (this.NumberOfPts[i] > 0)
			{
				//seqbound += this.CanUtilities[i][0] + this.ItemPointers[i][0].RestUtility;


				int projpos = this.ItemPointers[i][0].getItemsetIndex();
				int ptst = this.Seqbase.get(sid).getItemsetsILSpointers()[projpos];
				for (int j = ptst; j < this.Seqbase.get(sid).getTotalItems(); j++)
				{
					int itm;
					itm = this.Seqbase.get(sid).getItemScanningList()[j];
					if (this.blackList[itm] == 0)
					{
						//seqbound -= this.Seqbase[sid].ItemCumulativeUtilities[projpos][j - ptst];
						seqbound += this.Seqbase.get(sid).getItemCumulativeUtilities()[projpos][j - ptst];
					}
				}

				for (int j = this.ItemPointers[i][0].getItemIndex(); j < this.Seqbase.get(sid).getItemsets().get(projpos).size(); j++)
				{
					seqbound += this.Seqbase.get(sid).getItemsets().get(projpos).get(j).utility;
				}

				seqbound += this.CanUtilities[i][0];
			}

			this.countFlag = new int[this.countFlag.length];//Array.Clear(this.countFlag, 0, this.countFlag.length);
			for (int j = 0; j < this.NumberOfPts[i]; j++)
			{
				index = this.ItemPointers[i][j].getItemIndex();
				isidx = this.ItemPointers[i][j].getItemsetIndex();
				bound = this.Seqbase.get(sid).getItemsets().get(isidx).size();
				for (int k = index + 1; k < bound; k++)
				{
					int itm;
					itm = this.Seqbase.get(sid).getItemsets().get(isidx).get(k).itemId;
					if (this.getUtiTable()[itm] == 0)
					{
						this.getConcItems()[this.getNumerOfItems()] = itm;
						this.setNumerOfItems(this.getNumerOfItems() + 1);
					}
					if (this.getCountFlag()[itm] == 0)
					{
						this.getUtiTable()[itm] += seqbound;
						this.getCountFlag()[itm] = 1;
					}
				}
			}
		}

		//Added in 11.Dec.2012, the heritance method
		//this.iConcList = new Dictionary<int, double>();

		int numberofcans = this.getNumerOfItems();
		this.setNumerOfItems(0);
		for (int i = 0; i < numberofcans; i++)
		{
			int itm = this.getConcItems()[i];
			if (this.getUtiTable()[itm] >= USpanPlus.threshold)
			{
				this.getReadyForConc()[this.getNumerOfItems()] = itm;
			this.setNumerOfItems(this.getNumerOfItems() + 1);
				//this.iConcList.Add(itm, this.utiTable[itm]);
			}
		}
	}

	//public void sScan()
	//{
	//    int sid, projpos, ptst;
	//    for (int i = 0; i < this.numberOfSequences; i++)
	//    {
	//        sid = this.SeqIDs[i];
	//        double seqbound = 0;
	//        seqbound = this.Seqbase[sid].SequenceUtility;


	//        if (this.ItemPointers[i] == null)
	//        {
	//            ptst = 0;
	//        }
	//        else
	//        {
	//            projpos = this.ItemPointers[i][0].ItemsetIndex;
	//            ptst = this.Seqbase[sid].ItemsetsILSpointers[projpos];
	//        }

	//        Array.Clear(this.countFlag, 0, this.countFlag.Length);
	//        for (int j = ptst; j < Seqbase[sid].TotalItems; j++)
	//        {
	//            int itm;
	//            itm = this.Seqbase[sid].ItemScanningList[j];
	//            if (this.UtiTable[itm] == 0)
	//            {
	//                this.ConcItems[this.NumerOfItems] = itm;
	//                this.NumerOfItems++;
	//            }
	//            if (this.CountFlag[itm] == 0)
	//            {
	//                this.UtiTable[itm] += seqbound;
	//                this.CountFlag[itm] = 1;
	//            }
	//        }
	//    }

	//    int numberofcans = this.NumerOfItems;
	//    this.NumerOfItems = 0;
	//    for (int i = 0; i < numberofcans; i++)
	//    {
	//        int itm = this.ConcItems[i];
	//        if (this.UtiTable[itm] >= USpanPlus.threshold)
	//        {
	//            this.ReadyForConc[this.NumerOfItems++] = itm;
	//        }
	//    }
	//}

	public final void sScanning()
	{
		int sid, projpos, ptst;

		//Added in 7.Dec.2012
		//It is used to record the minimum utility of the items.
		double[] utiList = new double[USpanPlus.NumberOfDistinctItems];



		this.Clear();
		for (int i = 0; i < this.numberOfSequences; i++)
		{
			sid = this.SeqIDs[i];
			double seqbound = 0;

			//Added in 7.Dec.2012
			//This variable is the pivot utility. 
			double pivotuti = 0;

			if (this.ItemPointers[i] == null)
			{
				projpos = 0;
				ptst = 0;

				for (int j = 0; j < this.Seqbase.get(sid).getTotalItems(); j++)
				{
					int itm;
					itm = this.Seqbase.get(sid).getItemScanningList()[j];
					if (this.blackList[itm] == 0)
					{
						//seqbound -= this.Seqbase[sid].ItemCumulativeUtilities[projpos][j - ptst];
						seqbound += this.Seqbase.get(sid).getItemCumuUtis()[j];
					}
				}
			}
			else
			{
				projpos = this.ItemPointers[i][0].getItemsetIndex();
				ptst = this.Seqbase.get(sid).getItemsetsILSpointers()[projpos];

				//This variable is for the top-k use only.
				//It records of the pivot utility in the current sequence.
				pivotuti = this.CanUtilities[i][0];

				for (int j = ptst; j < this.Seqbase.get(sid).getTotalItems(); j++)
				{
					int itm;
					itm = this.Seqbase.get(sid).getItemScanningList()[j];
					if (this.blackList[itm] == 0)
					{
						//seqbound -= this.Seqbase[sid].ItemCumulativeUtilities[projpos][j - ptst];
						seqbound += this.Seqbase.get(sid).getItemCumulativeUtilities()[projpos][j - ptst];
					}
				}

				for (int j = this.ItemPointers[i][0].getItemIndex(); j < this.Seqbase.get(sid).getItemsets().get(projpos).size(); j++)
				{
					seqbound += this.Seqbase.get(sid).getItemsets().get(projpos).get(j).utility;
				}

				seqbound += pivotuti;
			}


			this.countFlag = new int[this.countFlag.length];//Array.Clear(this.countFlag, 0, this.countFlag.length);
			for (int j = ptst; j < Seqbase.get(sid).getTotalItems(); j++)
			{
				int itm;
				itm = this.Seqbase.get(sid).getItemScanningList()[j];
				if (this.blackList[itm] == 0)
				{
					if (this.getUtiTable()[itm] == 0)
					{
						this.getConcItems()[this.getNumerOfItems()] = itm;
						this.setNumerOfItems(this.getNumerOfItems() + 1);
					}
					if (this.getCountFlag()[itm] == 0)
					{
						//Comment the following statement in 15.Dec.2012
						//this.UtiTable[itm] += this.Seqbase[sid].SequenceUtility;

						//itemUtiContribution[itm] += this.Seqbase[sid].ItemCumulativeUtilities[projpos][j - ptst];

						//The utility table of the itm is the left utility
						this.getUtiTable()[itm] += seqbound;
						this.getCountFlag()[itm] = 1;
					}
				}
			}
		}

		boolean isinbl = true;
		//List<int> blist = new List<int>();
		for (int i = 0; i < this.numerOfItems; i++)
		{
			int itm = this.getConcItems()[i];
			if (this.getUtiTable()[itm] < USpanPlus.threshold)
			{
				isinbl = false;
				this.blackList[itm] = 1;
				//blist.Add(itm);
			}
		}

		if (isinbl)
		{
			int numberofcans = this.getNumerOfItems();
			this.setNumerOfItems(0);
			for (int i = 0; i < numberofcans; i++)
			{
				int itm = this.getConcItems()[i];
				if (this.getUtiTable()[itm] >= USpanPlus.threshold)
				{
					this.getReadyForConc()[this.getNumerOfItems()] = itm;
				this.setNumerOfItems(this.getNumerOfItems() + 1);
				}
			}
		}
		else
		{
			//Console.WriteLine("Here!");
			this.sScanning();
		}
	}

	public final void iScanning()
	{
		int index, bound, sid, isidx;
		this.numerOfItems = 0;

		this.Clear();
		for (int i = 0; i < this.numberOfSequences; i++)
		{
			sid = this.SeqIDs[i];
			double seqbound = this.Seqbase.get(sid).getSequenceUtility();
			//double seqbound = this.CanUtilities[i][0] + this.ItemPointers[i][0].RestUtility;

			this.countFlag = new int[this.countFlag.length];//Array.Clear(this.countFlag, 0, this.countFlag.length);
			for (int j = 0; j < this.NumberOfPts[i]; j++)
			{
				index = this.ItemPointers[i][j].getItemIndex();
				isidx = this.ItemPointers[i][j].getItemsetIndex();
				bound = this.Seqbase.get(sid).getItemsets().get(isidx).size();

				if (j == 0)
				{
					seqbound = this.CanUtilities[i][0] + this.ItemPointers[i][0].getRestSequenceUtility();
				}

				for (int k = index + 1; k < bound; k++)
				{
					int itm;
					itm = this.Seqbase.get(sid).getItemsets().get(isidx).get(k).itemId;

					if (j > 0 && this.blackList[itm] == 1)
					{
						continue;
					}

					//double seqbound = this.CanUtilities[i][j] + this.Seqbase[sid].Itemsets[isidx][k].RestUtility;

					if (this.getUtiTable()[itm] == 0)
					{
						this.getConcItems()[this.getNumerOfItems()] = itm;
						this.setNumerOfItems(this.getNumerOfItems() + 1);
					}
					if (this.getCountFlag()[itm] == 0)
					{
						this.getUtiTable()[itm] += seqbound;
						this.getCountFlag()[itm] = 1;
					}
				}
			}
		}

		//Added in 11.Dec.2012, the heritance method
		//this.iConcList = new Dictionary<int, double>();

		//bool isinbl = true;
		////List<int> blist = new List<int>();
		//for (int i = 0; i < this.numerOfItems; i++)
		//{
		//    int itm = this.ConcItems[i];
		//    if (this.UtiTable[itm] < USpanPlus.klist.MininumThres)
		//    {
		//        isinbl = false;
		//        this.blackList[itm] = 1;
		//        //blist.Add(itm);
		//    }
		//}

		//if (isinbl)
		//{
			int numberofcans = this.getNumerOfItems();
			this.setNumerOfItems(0);
			for (int i = 0; i < numberofcans; i++)
			{
				int itm = this.getConcItems()[i];
				if (this.getUtiTable()[itm] >= USpanPlus.threshold)
				{
					this.getReadyForConc()[this.getNumerOfItems()] = itm;
				this.setNumerOfItems(this.getNumerOfItems() + 1);
				}
			}
		//}
		//else
		//{
		//    //Console.WriteLine("Here!");
		//    this.iScanning();
		//}
	}

	public final void subscan(int sid, int refID, ArrayList<Item> sconcList, ArrayList<Item> iconcList)
	{
		int startitemsetpos = 0, startitempos = -1;
		Sequence seqref;
		boolean iconcflag = true, sconcflag = false;

		seqref = this.Seqbase.get(sid);

		int StartItemPos = 0, StartItemsetPos = -1;

		int Projectitem = -1;
		if (this.ItemPointers[refID] != null && !(this.ItemPointers[refID].length == 0 && this.CanUtilities[refID].length == 0))
		{
			Projectitem = this.ItemPointers[refID][0].getItemId();

			startitemsetpos = this.ItemPointers[refID][0].getItemsetIndex();
			startitempos = -1;
			for (int i = 0; i < seqref.getItemsets().get(startitemsetpos).size(); i++)
			{
				if (Projectitem == seqref.getItemsets().get(startitemsetpos).get(i).itemId)
				{
					startitempos = i;
				}
			}
		}

		if (startitemsetpos < seqref.getItemsets().size() && startitempos < seqref.getItemsets().get(startitemsetpos).size())
		{
			if (startitempos + 1 < (int)seqref.getItemsets().get(startitemsetpos).size())
			{
				StartItemPos = startitempos + 1;
				StartItemsetPos = startitemsetpos;
			}
			else
			{
				StartItemPos = 0;
				StartItemsetPos = startitemsetpos + 1;
			}
		}
		else
		{
			System.out.println("The startitemsetpos or startitempos is out of bound!");
		}

		if (StartItemPos == 0)
		{
			iconcflag = false;
			sconcflag = true;
		}
		else
		{
			iconcflag = true;
			sconcflag = false;
		}

		for (int i = StartItemsetPos; i < seqref.getItemsets().size(); i++)
		{
			for (int j = StartItemPos; j < seqref.getItemsets().get(i).size(); j++)
			{
				//				append("Now scan:" + seqref->Sequence[i][j].debugprintadd(0));
				if (sconcflag)
				{
					sconcList.add(seqref.getItemsets().get(i).get(j));
				}

				if (!iconcflag && seqref.getItemsets().get(i).get(j).itemId == Projectitem)
				{
					iconcflag = true;
					continue;
				}

				if (iconcflag)
				{
					iconcList.add(seqref.getItemsets().get(i).get(j));
				}
			}
			StartItemPos = 0;
			sconcflag = true;
			iconcflag = false;
		}
	}

	public final void scan()
	{
		HashMap<Integer, Double> spromisingitems = new HashMap<Integer,Double>();
		HashMap<Integer, Double> ipromisingitems = new HashMap<Integer,Double>();

		for (int i = 0; i < this.numberOfSequences; i++)
		{
			int sid = this.SeqIDs[i];
			//psref = this.Projectedsequencebase[i];
			//psref.scan();
			ArrayList<Item> sconcList = new ArrayList<Item>();
			ArrayList<Item> iconcList = new ArrayList<Item>();
			ArrayList<Item> tempRef_sconcList = new ArrayList<Item>(sconcList);
			ArrayList<Item> tempRef_iconcList = new ArrayList<Item>(iconcList);
			this.subscan(sid, i, tempRef_sconcList, tempRef_iconcList);
		iconcList = tempRef_iconcList;
		sconcList = tempRef_sconcList;

			double sequenceutility = this.Seqbase.get(sid).getSequenceUtility();

			ArrayList<Integer> temp = new ArrayList<Integer>();


			for (int j = 0; j < iconcList.size(); j++)
			{
				Item it = iconcList.get(j);
				if (!temp.contains(it.getItemId()))
				{
					if (!ipromisingitems.containsKey(it.getItemId()))
					{
						ipromisingitems.put(it.getItemId(), sequenceutility);
					}
					else
					{
						double sumutility = ipromisingitems.get(it.getItemId());
						sumutility += sequenceutility;
						ipromisingitems.put(it.getItemId(), sumutility);
					}
				}
				temp.add(it.getItemId());
			}

			temp.clear();

			for (int j = 0; j < sconcList.size(); j++)
			{
				Item it = sconcList.get(j);
				if (!temp.contains(it.getItemId()))
				{
					if (!spromisingitems.containsKey(it.getItemId()))
					{
						spromisingitems.put(it.getItemId(), sequenceutility);
					}
					else
					{
						double sumutility = spromisingitems.get(it.getItemId());
						sumutility += sequenceutility;
						spromisingitems.put(it.getItemId(), sumutility);
					}
				}
				temp.add(it.getItemId());
			}
		}

		this.sConcItems_USpan = new ArrayList<Integer>();
		this.iConcItems_USpan = new ArrayList<Integer>();

		ArrayList<Integer> keytoremove = new ArrayList<Integer>();
		for (Map.Entry<Integer, Double> pair : spromisingitems.entrySet())
		{
			{
			//if (pair.Value >= USpanPlus.threshold)
				this.sConcItems_USpan.add(pair.getKey());
			}
		}

		for (Map.Entry<Integer, Double> pair : ipromisingitems.entrySet())
		{
			{
			//if (pair.Value >= USpanPlus.threshold)
				this.iConcItems_USpan.add(pair.getKey());
			}
		}
	}


	public final void Original_iScan()
	{
		int index, bound, sid, isidx;
		this.numerOfItems = 0;
		double[] utiList = new double[USpanPlus.NumberOfDistinctItems];

		this.Clear();
		for (int i = 0; i < this.numberOfSequences; i++)
		{
			//Added in 7.Dec.2012
			//This variable is the pivot utility. 
			double pivotuti = 0, estimateuti = 0;


			sid = this.SeqIDs[i];
			double seqbound = 0;
			if (this.NumberOfPts[i] > 0)
			{
				seqbound += this.CanUtilities[i][0] + this.ItemPointers[i][0].getRestSequenceUtility();
			}

			this.countFlag = new int[this.countFlag.length];//Array.Clear(this.countFlag, 0, this.countFlag.length);
			for (int j = 0; j < this.NumberOfPts[i]; j++)
			{
				index = this.ItemPointers[i][j].getItemIndex();
				isidx = this.ItemPointers[i][j].getItemsetIndex();
				bound = this.Seqbase.get(sid).getItemsets().get(isidx).size();

				pivotuti = this.CanUtilities[i][j];
				for (int k = index + 1; k < bound; k++)
				{
					int itm;
					itm = this.Seqbase.get(sid).getItemsets().get(isidx).get(k).itemId;

					//The following two function is added for top-k issue
					estimateuti = pivotuti + this.Seqbase.get(sid).getItemsets().get(isidx).get(k).utility;
					//highestuti = estimateuti < highestuti ? highestuti : estimateuti;

					if (this.getUtiTable()[itm] == 0)
					{
						this.getConcItems()[this.getNumerOfItems()] = itm;
						this.setNumerOfItems(this.getNumerOfItems() + 1);
					}
					if (this.getCountFlag()[itm] == 0)
					{
						this.getUtiTable()[itm] += seqbound;
						this.getCountFlag()[itm] = 1;
						utiList[itm] += estimateuti;
					}
				}
			}
		}

		//Added in 11.Dec.2012, the heritance method
		//this.iConcList = new Dictionary<int, double>();

		int numberofcans = this.getNumerOfItems();
		this.setNumerOfItems(0);
		for (int i = 0; i < numberofcans; i++)
		{
			int itm = this.getConcItems()[i];
			if (this.getUtiTable()[itm] >= USpanPlus.threshold)
			{
				this.getReadyForConc()[this.getNumerOfItems()] = itm;
			this.setNumerOfItems(this.getNumerOfItems() + 1);
				//this.iConcList.Add(itm, this.utiTable[itm]);
			}
		}
	}

	public final void Original_sScan()
	{
		int sid, projpos, ptst;

		this.Clear();
		for (int i = 0; i < this.numberOfSequences; i++)
		{
			sid = this.SeqIDs[i];
			double seqbound = 0;

			//Added in 7.Dec.2012
			//This variable is the pivot utility. 
			double pivotuti = 0;

			//seqbound += this.Seqbase[sid].SequenceUtility;

			if (this.ItemPointers[i] == null)
			{
				projpos = 0;
				ptst = 0;

				for (int j = 0; j < this.Seqbase.get(sid).getTotalItems(); j++)
				{
					int itm;
					itm = this.Seqbase.get(sid).getItemScanningList()[j];
					if (this.blackList[itm] == 0)
					{
						//seqbound -= this.Seqbase[sid].ItemCumulativeUtilities[projpos][j - ptst];
						seqbound += this.Seqbase.get(sid).getItemCumuUtis()[j];
					}
				}
			}
			else
			{
				projpos = this.ItemPointers[i][0].getItemsetIndex();
				ptst = this.Seqbase.get(sid).getItemsetsILSpointers()[projpos];

				//This variable is for the top-k use only.
				//It records of the pivot utility in the current sequence.
				pivotuti = this.CanUtilities[i][0];

				for (int j = ptst; j < this.Seqbase.get(sid).getTotalItems(); j++)
				{
					int itm;
					itm = this.Seqbase.get(sid).getItemScanningList()[j];
					if (this.blackList[itm] == 0)
					{
						//seqbound -= this.Seqbase[sid].ItemCumulativeUtilities[projpos][j - ptst];
						seqbound += this.Seqbase.get(sid).getItemCumulativeUtilities()[projpos][j - ptst];
					}
				}

				seqbound += this.ItemPointers[i][0].getRestItemsetUtility();
				seqbound += pivotuti;
			}


			this.countFlag = new int[this.countFlag.length];//Array.Clear(this.countFlag, 0, this.countFlag.length);
			for (int j = ptst; j < Seqbase.get(sid).getTotalItems(); j++)
			{
				int itm;
				itm = this.Seqbase.get(sid).getItemScanningList()[j];
				if (this.blackList[itm] == 0)
				{
					if (this.getUtiTable()[itm] == 0)
					{
						this.getConcItems()[this.getNumerOfItems()] = itm;
						this.setNumerOfItems(this.getNumerOfItems() + 1);
					}
					if (this.getCountFlag()[itm] == 0)
					{
						//The utility table of the itm is the left utility
						this.getUtiTable()[itm] += seqbound;
						this.getCountFlag()[itm] = 1;
					}
				}
			}
		}

		boolean isinbl = true;
		//List<int> blist = new List<int>();
		for (int i = 0; i < this.numerOfItems; i++)
		{
			int itm = this.getConcItems()[i];
			if (this.getUtiTable()[itm] < USpanPlus.threshold)
			{
				isinbl = false;
				this.blackList[itm] = 1;
				//blist.Add(itm);
			}
		}

		if (isinbl)
		{
			int numberofcans = this.getNumerOfItems();
			this.setNumerOfItems(0);
			for (int i = 0; i < numberofcans; i++)
			{
				int itm = this.getConcItems()[i];
				if (this.getUtiTable()[itm] >= USpanPlus.threshold)
				{
					this.getReadyForConc()[this.getNumerOfItems()] = itm;
				this.setNumerOfItems(this.getNumerOfItems() + 1);
				}
			}
		}
		else
		{
			this.Original_sScan();
		}
	}

	private int binary_search(ArrayList<Item> seq, int key, int imin, int imax)
	{
		// continue searching while [imin,imax] is not empty
		while (imax >= imin)
		{
			/* calculate the midpoint for roughly equal partition */
			int imid = (imin + imax) / 2;

			// determine which subarray to search
			if (seq.get(imid).getItemId() < key)
			{
				// change min index to search upper subarray
				imin = imid + 1;
			}
			else if (seq.get(imid).getItemId() > key)
			{
				// change max index to search lower subarray
				imax = imid - 1;
			}
			else
			{
				// key found at index imid
				return imid;
			}
		}
		// key not found
		return -1;
	}

	public final double getRestUtilityBound(Item pivot, int sid)
	{
		double ret = 0;
		Sequence seqref = this.Seqbase.get(sid);
		int start = pivot.getItemIndex() + 1, end = seqref.getItemsets().get(pivot.getItemsetIndex()).size();
		for (int i = start;i < end;i++)
		{
			Item item = seqref.getItemsets().get(pivot.getItemsetIndex()).get(i);
			if (this.blackList[item.getItemId()] == 0)
			{
				ret += item.getUtility();
			}
		}

		if (pivot.getItemsetIndex() < seqref.getItemsets().size() - 1)
		{
			start = seqref.getItemsetsILSpointers()[pivot.getItemsetIndex()];
			end = seqref.getTotalItems();
			for (int i = start;i < end;i++)
			{
				int item = seqref.getItemScanningList()[i];
				double utility = seqref.getItemCumulativeUtilities()[pivot.getItemsetIndex()][i - start];

				if (this.blackList[item] == 0)
				{
					ret += utility;
				}
			}

		}

		return ret;
	}

	public final double getLeftSideUtility(Item pivot, int sid)
	{
		double ret = 0;

		int itemsetId = pivot.getItemsetIndex();
		Sequence seqref = this.Seqbase.get(sid);

		//Console.WriteLine(this.candidate.cleanpattern());
		//if (this.candidate.cleanpattern().Equals("(5) (3)"))
		//{
		//    Console.WriteLine();
		//}

		for (Map.Entry<Integer, Integer> it : this.candidate.getItemsCount().entrySet())
		{
			int item = it.getKey(), count = it.getValue();

			Item lastref = null;
			for (Item itm = seqref.getItemMap().get(item); itm != null; itm = itm.getRight())
			{
				lastref = itm;
				if (itm.getItemsetIndex() >= itemsetId)
				{
					break;
				}
			}

			if (lastref != null)
			{
				ret += lastref.getUtilities()[count - 1];
			}
			else
			{
				System.out.println("Error in the getLeftSideUtility");
			}
		}

		return ret;
	}

	public final boolean iConcatenatingTheFields(ProjectedSequenceBase baseref, int itm)
	{
		int sid, nscnt = 0, npcnt = 0, idx = 0, imin, imax, itemsetidx = 0, itemidx = 0;
		ArrayList<Item> itemset;
		boolean found = false, univfound = false;

		this.numberOfSequences = baseref.numberOfSequences;
		this.SeqIDs = new int[baseref.numberOfSequences];
		this.MaxUtilities = new double[baseref.numberOfSequences];
		this.NumberOfPts = new int[baseref.numberOfSequences];
		this.ItemPointers = new Item[baseref.numberOfSequences][];
		this.CanUtilities = new double[baseref.numberOfSequences][];

		this.candidate = new Pattern(baseref.candidate);
		this.candidate.insertItem(itm, true);

		//For each sequence
		for (int i = 0; i < baseref.numberOfSequences; i++)
		{
			//Whether this item has been found
			found = false;

			//Sid is the index of the sequence in the original sequence database
			sid = baseref.SeqIDs[i];

			//NumberOfPts means the number of porjected points in each sequence
			//nscnt means the number of sequences where the projected items(i.e. itm) are found. 
			this.NumberOfPts[nscnt] = 0;

			npcnt = 0;

			//Added in 5. Dec 
			double highestutility = 0;

			//For each projected itemset
			for (int j = 0;j < baseref.NumberOfPts[i];j++)
			{
				//The item to be i-concatenated to the current candidate must be
				//alphabetical larger than the projected item. Therefore "itm" must
				//be located between the porjected item and the end of the itemset.


				//The itemset to be concatenate in the sequence here is the most
				itemset = this.Seqbase.get(sid).getItemsets().get(baseref.ItemPointers[i][j].getItemsetIndex());

				//The next item of the projected points
				imin = baseref.ItemPointers[i][j].getItemIndex() + 1;

				//The last item in the current itemset
				imax = this.Seqbase.get(sid).getItemsets().get(baseref.ItemPointers[i][j].getItemsetIndex()).size() - 1;

				//Use the binary search function to get the current item.
				idx = this.binary_search(itemset, itm, imin, imax);

				//-1 means KEY_NOT_FOUND. The current itemset doesnot contain "itm".
				if (idx == -1)
				{
					continue;
				}
				else
				{
					//If the current item is the first time found
					if (!found)
					{
						//new the number of the items.
						this.ItemPointers[nscnt] = new Item[baseref.NumberOfPts[i]];

						//Added 5.Dec, it records the utility of the projection point.
						this.CanUtilities[nscnt] = new double[baseref.NumberOfPts[i]];

						//itemsetidx means the index of the current itemset.
						itemsetidx = baseref.ItemPointers[i][j].getItemsetIndex();

						//itemidx is the index of the item in the itemset. 
						itemidx = idx;
					}
					this.NumberOfPts[nscnt]++;
					this.ItemPointers[nscnt][npcnt] = itemset.get(idx);
					this.CanUtilities[nscnt][npcnt] = baseref.CanUtilities[i][j] + itemset.get(idx).getUtility();

					highestutility = highestutility > this.CanUtilities[nscnt][npcnt] ? highestutility :this.CanUtilities[nscnt][npcnt];

					npcnt++;
					found = true;


					//The following if is added in 10.Dec.2012
					//Used a new scanning function
					//if (npcnt == 1 && this.ItemPointers[nscnt][0].Right == null)
					//if (npcnt == 1)
					//{
					//    int startpos = baseref.NumberOfPts[i] > 0 ? this.Seqbase[sid].ItemsetsILSpointers[baseref.ItemPointers[i][0].ItemsetIndex] : 0;
					//    int endpos = this.Seqbase[sid].ItemsetsILSpointers[this.ItemPointers[nscnt][0].ItemsetIndex];
					//    this.reduceSconcUti(startpos, endpos, sid);
					//}
				}
			}

			//The following if is added in 10.Dec.2012
			//Used a new scanning function
			//if (!found)
			//{
			//    int startpos = baseref.NumberOfPts[i] > 0 ? this.Seqbase[sid].ItemsetsILSpointers[baseref.ItemPointers[i][0].ItemsetIndex] : 0;
			//    int endpos = this.Seqbase[sid].TotalItems;
			//    this.reduceSconcUti(startpos, endpos, sid);
			//}

			//If it is found in THIS SEQUENCE
			if (found)
			{
				//SeqIDs contains the ids of the sequences which are projected in the sequence
				this.SeqIDs[nscnt] = sid;

				//The left most utility here means the pivot candidate's utility
				//!!!This equation has some problem, tagged in 5. Dec 
				//this.LeftMostUtility[nscnt] = baseref.LeftMostUtility[i]
				//    + this.Seqbase[sid].Itemsets[itemsetidx][itemidx].Utility;

				//This equation added 5. Dec.
				this.MaxUtilities[nscnt] = highestutility;

				//Added in 15.Dec.2012, commented in 20.Dec.2012
				//this.LeftUti += (this.CanUtilities[nscnt][0] + this.Seqbase[sid].Itemsets[itemsetidx][itemidx].RestSequenceUtility);
				//this.LeftUti += this.CanUtilities[nscnt][0] + this.getRestUtilityBound(this.ItemPointers[nscnt][0], sid);


				this.LeftUti += (this.getLeftSideUtility(this.ItemPointers[nscnt][0], sid) + this.Seqbase.get(sid).getItemsets().get(itemsetidx).get(itemidx).restSequenceUtility);

				//LeftUti is actually the RestU in the paper, means the sum of the pivot and the rest of the sequence.
				//this.MaxUtility += (this.MaxUtilities[nscnt] + this.Seqbase[sid].Itemsets[itemsetidx][itemidx].RestUtility);

				//The real utility of the candidate
				this.candidateUtility += this.MaxUtilities[nscnt];

				//The number of projection pointers in this sequence of the candidate.
				this.NumberOfPts[nscnt] = npcnt;
				nscnt++;
				univfound = true;
			}
		}
		if (univfound)
		{
			this.ProjItem = itm;
			this.numberOfSequences = nscnt;
			return true;
		}
		else
		{
			return false;
		}
	}

	public final boolean sConcatenatingTheFields(ProjectedSequenceBase baseref, int itm)
	{
		int sid, nscnt = 0, npcnt = 0, idx = 0, j;
		Item stpos;
		boolean found = false, univfound = false;

		this.numberOfSequences = baseref.numberOfSequences;
		this.SeqIDs = new int[baseref.numberOfSequences];
		this.MaxUtilities = new double[baseref.numberOfSequences];
		this.NumberOfPts = new int[baseref.numberOfSequences];
		this.ItemPointers = new Item[baseref.numberOfSequences][];
		this.CanUtilities = new double[baseref.numberOfSequences][];

		this.candidate = new Pattern(baseref.candidate);
		this.candidate.insertItem(itm, false);

		//For each sequences
		for (int i = 0;i < baseref.numberOfSequences;i++)
		{
			//Whether this item has been found
			found = false;

			//Sid is the index of the sequence in the original sequence database
			sid = baseref.SeqIDs[i];

			//NumberOfPts means the number of porjected points in each sequence
			//nscnt means the number of sequences where the projected items(i.e. itm) are found. 
			this.NumberOfPts[nscnt] = 0;

			//means how many projected points found in this sequence.
			npcnt = 0;

			//inij means the first projected point's (named pivot in the paper) index.
			//In order to get the first index of inij, assgin a upper bound to it first, updated it later.
			int inij = this.Seqbase.get(sid).getItemsets().size();


			//idx = binary_searchint(this.Seqbase[sid].ItemOrder, itm, 0, this.Seqbase[sid].TotalItems - 1);

			//If the current sequence does not contain the item, continue to search in the next sequence.
			if (this.Seqbase.get(sid).getItemMap().containsKey(itm))
			{
				//If it does, get the projection points
				stpos = this.Seqbase.get(sid).getItemMap().get(itm);
			}
			else
			{
				//Added 12.Dec.2012
				//For the new scanning function
				//int startpos = baseref.NumberOfPts[i] > 0 ? this.Seqbase[sid].ItemsetsILSpointers[baseref.ItemPointers[i][0].ItemsetIndex] : 0;
				//int endpos = this.Seqbase[sid].TotalItems;
				//this.reduceSconcUti(startpos, endpos, sid);


				//Pass this sequence, go check next one
				continue;
			}

			//j means the projection points. j = 0 if and only if the projected point equals to 0
			//Otherwise j is set to the next points of the 
			j = baseref.ItemPointers[i] == null?0: baseref.ItemPointers[i][0].getItemsetIndex() + 1;

			Item pter = stpos;

			//pter is used to interate the t-link. The following loop is used to target the 
			//valid concatenation point compared with the projection points. 
			for (;pter != null;pter = pter.getRight())
			{
				if (pter.getItemsetIndex() >= j)
				{
					found = true;
					j = pter.getItemsetIndex();
					idx = pter.getItemIndex();
					inij = inij < j? inij: j;
					break;
				}
			}

			//Added 12.Dec.2012
			//For the new scanning function
			//if (!found)
			//{
			//    int startpos = baseref.NumberOfPts[i] > 0 ? this.Seqbase[sid].ItemsetsILSpointers[baseref.ItemPointers[i][0].ItemsetIndex] : 0;
			//    int endpos = this.Seqbase[sid].TotalItems;
			//    this.reduceSconcUti(startpos, endpos, sid);
			//}


			//If the avaivable concatenation point is found
			if (found)
			{
				this.ItemPointers[nscnt] = new Item[this.Seqbase.get(sid).getItemsets().size()];
				this.CanUtilities[nscnt] = new double[this.Seqbase.get(sid).getItemsets().size()];

				int prepointer = 0;
				double prehighestutility = 0, currentitemutility, utility, highestutility = 0;
				for (; pter != null; pter = pter.getRight())
				{
					while (prepointer < baseref.NumberOfPts[i] && baseref.ItemPointers[i][prepointer].getItemsetIndex() < pter.getItemsetIndex())
					{
						prehighestutility = prehighestutility < baseref.CanUtilities[i][prepointer] ? baseref.CanUtilities[i][prepointer] : prehighestutility;
						prepointer++;
					}

					currentitemutility = pter.getUtility();
					utility = prehighestutility + currentitemutility;

					this.ItemPointers[nscnt][npcnt] = pter;
					this.CanUtilities[nscnt][npcnt] = utility;
					npcnt++;

					////The following if is added in 10.Dec.2012
					////Used a new scanning function
					//if (npcnt == 1)
					//{
					//    int startpos = baseref.NumberOfPts[i] > 0? this.Seqbase[sid].ItemsetsILSpointers[baseref.ItemPointers[i][0].ItemsetIndex] : 0;
					//    int endpos = this.Seqbase[sid].ItemsetsILSpointers[this.ItemPointers[nscnt][0].ItemsetIndex];
					//    this.reduceSconcUti(startpos, endpos, sid);
					//}

					if (utility > highestutility)
					{
						highestutility = utility;
					}

					this.MaxUtilities[nscnt] = highestutility;
				}

				//SeqIDs contains the ids of the sequences which are projected in the sequence
				this.SeqIDs[nscnt] = sid;

				//The left most utility here means the pivot candidate's utility
				//this.LeftMostUtility[nscnt] = baseref.LeftMostUtility[i] + this.Seqbase[sid].Itemsets[inij][idx].Utility;

				//The number of projection pointers in this sequence of the candidate.
				this.NumberOfPts[nscnt] = npcnt;

				//The real utility of the candidate
				this.candidateUtility += this.MaxUtilities[nscnt];

				//Added in 15.Dec.2012
				//The purpose is to calculate the leftmost utility of the sequence.
				//this.LeftMostUtilities[nscnt] = this.CanUtilities[nscnt][0] + this.Seqbase[sid].Itemsets[inij][idx].RestUtility;
				//this.LeftUti += (this.CanUtilities[nscnt][0] + this.Seqbase[sid].Itemsets[inij][idx].RestSequenceUtility);
				//this.LeftUti += this.CanUtilities[nscnt][0] + this.getRestUtilityBound(this.ItemPointers[nscnt][0], sid);


				this.LeftUti += (this.getLeftSideUtility(this.ItemPointers[nscnt][0], sid) + this.Seqbase.get(sid).getItemsets().get(inij).get(idx).restSequenceUtility);

				//LeftUti is actually the RestU in the paper, means the sum of the pivot and the rest of the sequence.
				//this.MaxUtility += (this.MaxUtilities[nscnt] + this.Seqbase[sid].Itemsets[inij][idx].RestUtility);
				univfound = true;
				nscnt++;
			}
		}

		//if there is at least one valid concatenation is found.
		if (univfound)
		{
			this.ProjItem = itm;
			this.numberOfSequences = nscnt;
			return true;
		}
		else
		{
			return false;
		}
	}

	public final boolean isTheLastElementSigle()
	{
		boolean ret = true;
		if (!this.candidate.getItemsets().isEmpty())
		{
			int numberofitems = this.candidate.getItemsets().get(this.candidate.getItemsets().size() - 1).size();
			ret = numberofitems > 1 ? false : true;
		}
		return ret;
	}

	public final String cleanPointersAndUtitlies()
	{
		String ss = "";


		for (int i = 0;i < this.numberOfSequences;i++)
		{
			ss += (this.SeqIDs[i] + 1) + ":{";
			for (int j = 0; j < this.NumberOfPts[i]; j++)
			{
				ss += (this.ItemPointers[i][j].getItemsetIndex() + 1) + ":" + this.CanUtilities[i][j] + ",";
			}
			ss += "}";
		}
		ss += ("");

		return ss;
	}
}