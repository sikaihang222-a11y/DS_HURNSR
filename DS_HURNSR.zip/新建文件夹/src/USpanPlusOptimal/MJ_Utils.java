package USpanPlusOptimal;

import java.util.ArrayList;

public class MJ_Utils {

	public static ArrayList<Integer> arrayToList(int[]arr){    //MJ_Utils的一个静态方法，通过类名可以直接调用，功能是将数组转化成集合
		
		ArrayList<Integer>list = new ArrayList<Integer>();
		
		for (int i : arr) {
			
			list.add(Integer.valueOf(i));
			
		}
		return list;
	}
}
