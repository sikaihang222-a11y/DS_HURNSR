package USpanPlusOptimal;

import java.util.*;

public class Pattern // 定义公共Pattern类
{
	private int id; // 定义id
	// 定义 泛型的项集 List<T>表示泛型
	private ArrayList<ArrayList<Integer>> itemsets;//[[1, 2, 3], [4, 5], [6, 7, 8, 9]]
	private double utility; // 定义 效用
	private double fullUtility; // 定义 完全效用
	private int support; // 定义 支持度
	private int fullSupport; // 定义 完全支持度
	private ArrayList<ArrayList<String>> SeqIndex;
	private ArrayList<ArrayList<Double>> Sequtility;
	private ArrayList<ArrayList<ArrayList<String>>> SeqIndexnew;

	private ArrayList<String> Sid;//私有变量，其他类不能直接访问这个变量

	public ArrayList<String> getSid() {
		return Sid;
	}//允许其他类获取当前类中Sid变量的值

	public void setSid(ArrayList<String> sid) {
		Sid = sid;
	}//允许其他类来修改sid变量的值

	public ArrayList<ArrayList<ArrayList<String>>> getSeqIndexnew() {
		return SeqIndexnew;
	}

	public void setSeqIndexnew(ArrayList<ArrayList<ArrayList<String>>> seqIndexnew) {
		SeqIndexnew = seqIndexnew;
	}

	public ArrayList<ArrayList<Double>> getSequtility() {
		return Sequtility;
	}

	public void setSequtility(ArrayList<ArrayList<Double>> sequtility) {
		Sequtility = sequtility;
	}

	public ArrayList<ArrayList<String>> getSeqIndex() {
		return SeqIndex;
	}

	public void setSeqIndex(ArrayList<ArrayList<String>> seqIndex) {
		SeqIndex = seqIndex;
	}

	public final int getId() {
		return id;
	}

	public final void setId(int value) {
		id = value;
	}

	public final ArrayList<ArrayList<Integer>> getItemsets() {
		return itemsets;
	}

	public final void setItemsets(ArrayList<ArrayList<Integer>> value) {
		itemsets = value;
	}

	public final double getUtility() {
		return utility;
	}

	public final void setUtility(double value) {
		utility = value;
	}

	public final double getFullUtility() {
		return fullUtility;
	}

	public final void setFullUtility(double value) {
		fullUtility = value;
	}

	public final int getSupport() {
		return support;
	}

	public final void setSupport(int value) {
		support = value;
	}

	public final int getFullSupport() {
		return fullSupport;
	}

	public final void setFullSupport(int value) {
		fullSupport = value;
	}

	// Dictionary<k, v>表示泛型 项集计数
	private HashMap<Integer, Integer> itemsCount;

	public final HashMap<Integer, Integer> getItemsCount() {
		return itemsCount;
	}

	public final void setItemsCount(HashMap<Integer, Integer> value) {
		itemsCount = value;
	}

	// 空参构造方法，初始化为零
	public Pattern() {
		this.utility = 0;
		this.fullUtility = 0;
		this.support = 0;
		this.fullSupport = 0;
		this.itemsets = new ArrayList<ArrayList<Integer>>();
		this.SeqIndex = new ArrayList<ArrayList<String>>();
		this.Sequtility = new ArrayList<ArrayList<Double>>();
		this.id = -1;
		this.itemsCount = new HashMap<Integer, Integer>();
	}

	// Added in 17.Dec.2012
	// This constructor is for prescanning 这个构造函数用于预扫描
	public Pattern(int item, double utility) // 有参构造
	{
		this.utility = 0;
		this.fullUtility = 0;
		this.support = 0;
		this.fullSupport = 0;
		this.itemsets = new ArrayList<ArrayList<Integer>>();
		this.itemsets.add(new ArrayList<Integer>());
		this.itemsets.get(0).add(item);
		this.utility = utility;
		this.id = -1;
		this.itemsCount = new HashMap<Integer, Integer>();
	}

	public Pattern(Pattern ptn) // 有参构造
	{
		this.utility = ptn.utility;
		this.fullUtility = 0;
		this.support = ptn.support;
		this.fullSupport = 0;
		this.itemsets = new ArrayList<ArrayList<Integer>>();

		this.id = -1;
		this.itemsets = new ArrayList<ArrayList<Integer>>();
		// 外层循环：一个序列中从第一个项集读取到最后一个项集
		for (int i = 0; i < ptn.getItemsets().size(); i++) {
			// 新建一个临时List集合，存放模式
			ArrayList<Integer> temp = new ArrayList<Integer>();
			// 内层循环：一个项集中从第一个项读到最后一个项
			for (int j = 0; j < ptn.getItemsets().get(i).size(); j++) {
				// 将项挨个添加到temp中
				temp.add(ptn.getItemsets().get(i).get(j));
			}
			// 将一个完整的项集添加到itemsets中
			this.itemsets.add(temp);
		}
		if (ptn.SeqIndex != null) {
			this.SeqIndex = new ArrayList<ArrayList<String>>();
			for (int i = 0; i < ptn.getSeqIndex().size(); i++) {
				this.SeqIndex.add(ptn.getSeqIndex().get(i));
			}
			if (ptn.Sequtility != null) {
				this.Sequtility = new ArrayList<ArrayList<Double>>();
				for (int j = 0; j < ptn.getSequtility().size(); j++) {
					this.Sequtility.add(ptn.getSequtility().get(j));
				}
			}
		}
		if (ptn.Sid != null) {
			this.Sid = new ArrayList<String>();
			for (int i = 0; i < ptn.Sid.size(); i++) {
				this.Sid.add(ptn.getSid().get(i));
			}
		}

		this.itemsCount = new HashMap<Integer, Integer>(ptn.itemsCount);
	}

	public final int getLastItem() // 获取最后一个项
	{
		int ret = -1;
		if (this.itemsets != null && !this.itemsets.isEmpty()) {
			ArrayList<Integer> refer = this.itemsets.get(this.itemsets.size() - 1);
			ret = refer.get(refer.size() - 1);
		}
		return ret;
	}

	// 定义insertItem()方法插入项
	public final void insertItem(int item, boolean isIconc) {
		int lastelement; // 定义最后一个元素的序号
		if (this.itemsets.isEmpty()) // 如果模式为空，就新建一个集合
		{
			lastelement = 0;
			this.itemsets = new ArrayList<ArrayList<Integer>>();
		} else {
			// 如果模式不为空，最后一个元素的序号就为this.itemsets.Count - 1
			lastelement = this.itemsets.size() - 1;
		}
		if (lastelement >= 0) {
			if (isIconc) // ？？
			{
				// 若isIconc=true，在最后一个项集的末尾插入新的项
				this.itemsets.get(lastelement).add(item);
			} else {
				// 若isIconc=false，则创建一个新的元素
				ArrayList<Integer> newelement = new ArrayList<Integer>();
				newelement.add(item);
				this.itemsets.add(newelement);

			}
		} else {
			System.out.println("Error in insertItem");
		}

		{
			// if(!isIconc && this.itemsets.Count > 1)
			if (!this.itemsCount.containsKey(item)) {
				this.itemsCount.put(item, 0);
			}
			int count = this.itemsCount.get(item);
			count++;
			this.itemsCount.put(item, count);
		}
	}

	public final void insertSeqIndex(ArrayList<String> str) {
		if (this.SeqIndex == null) // 如果模式为空，就新建一个集合
		{
			this.SeqIndex = new ArrayList<ArrayList<String>>();
			this.SeqIndex.add(str);
		} else {
			this.SeqIndex.add(str);
		}
	}

	public final void insertSequtility(ArrayList<Double> dou) {
		if (this.Sequtility == null) {
			this.Sequtility = new ArrayList<ArrayList<Double>>();
			this.Sequtility.add(dou);
		} else {
			this.Sequtility.add(dou);
		}
	}

	public final void fillinPattern(ICDMProjectedSequenceBase nextpsb) {
		this.utility = nextpsb.getCandidateUtility();
		this.support = nextpsb.getNumberOfSequences();
	}
//生成当前模式的字符串表示
	public final String cleanpattern() // 模式的规范输出
	{
		String ss = "";
		String comma = "";
		for (int i = 0; i < this.getItemsets().size(); i++) {
			ss += comma; // 逗号
			ss += "(";
			String space = "";
			for (int it : this.getItemsets().get(i)) {
				int itm = USpanPlus.itemIdsMapping[it];
				ss += (space + itm);
				space = ",";
			}
			ss += ")";
			comma = " ";
		}
		return ss;
	}

	// 求负项集。
	public ArrayList<Integer> setNeg(ArrayList<Integer> a) {
		for (int i = 0; i < a.size(); i++) {
			int j = -a.get(i);
			a.set(i, j);
		}
		return a;
	}

	// 求负序列对应的正序列
	public Pattern getPosFromSeq(Pattern pat) {
		for (int i = 0; i < pat.getItemsets().size(); i++) {
			List<Integer> item = new ArrayList<Integer>();
			item = pat.getItemsets().get(i);
			if (item.get(0) < 0) {
				pat.getItemsets().remove(i);
			}
		}
		return pat;
	}

	// 求负序列对应的正序列
	public List<List<Integer>> getPosFromSeqList(List<List<Integer>> Itemsets) {
		for (int i = 0; i < Itemsets.size(); i++) {
			for (int j = 0; j < Itemsets.get(i).size(); j++) {
				if (Itemsets.get(i).get(j) < 0) {
					Itemsets.get(i).remove(j);
				}
			}
			if (Itemsets.get(i).isEmpty()) {
				Itemsets.remove(i);
			}
		}
		return Itemsets;
	}

	public final String cleanparameters() {
		String ss = "";
		ss += ("" + this.utility);
		return ss;
	}
}