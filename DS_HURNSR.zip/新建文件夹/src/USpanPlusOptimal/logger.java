package USpanPlusOptimal;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import java.util.logging.Level;

// 日志文件
public class logger {
    public class ApplicationLogger {
        private static Logger logger = Logger.getLogger("USpanPlusOptimalLogger");
        private static boolean isConfigured = false;

        public static Logger getLogger() {
            if (!isConfigured) {
                configureLogger();
            }
            return logger;
        }

        private static void configureLogger() {
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                String date = dateFormat.format(new Date());
                String logFilePath = "E:\\Desktop\\USpan+Optimal2\\src\\loggerFile"+date+".log";  // 指定日志文件路径
                FileHandler fileHandler = new FileHandler(logFilePath, true);  // 文件路径和追加模式
                fileHandler.setFormatter(new SimpleFormatter());  // 设置简单文本格式化
                logger.addHandler(fileHandler);
                logger.setLevel(Level.INFO);  // 设置默认日志级别
                isConfigured = true;
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Failed to setup logger", e);
            }
        }
    }
}

