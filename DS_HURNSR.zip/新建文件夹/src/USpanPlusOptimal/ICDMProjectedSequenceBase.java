package USpanPlusOptimal;

import java.util.*;
/**
 * 
 *USpan算法的支持方法，包括投影数据库，扫描投影数据库等等
 */
public class ICDMProjectedSequenceBase 
{
	private double seqbaseUtility;
	private int numerOfItems;
	private double[] utiTable;
	private int[] concItems; // 连接项
	private int[] readyForConc;
	private int[] countFlag;
	private Pattern candidate;
	public final double getSeqbaseUtility() {
		return seqbaseUtility;
	}
	public final void setSeqbaseUtility(double value) {
		seqbaseUtility = value;
	}
	public final int getNumerOfItems() {
		return numerOfItems;
	}

	public final void setNumerOfItems(int value) {
		numerOfItems = value;
	}

	public final double[] getUtiTable() {
		return utiTable;
	}

	public final void setUtiTable(double[] value) {
		utiTable = value;
	}

	public final int[] getConcItems() {
		return concItems;
	}

	public final void setConcItems(int[] value) {
		concItems = value;
	}

	public final int[] getReadyForConc() {
		return readyForConc;
	}

	public final void setReadyForConc(int[] value) {
		readyForConc = value;
	}

	public final int[] getCountFlag() {
		return countFlag;
	}

	public final void setCountFlag(int[] value) {
		countFlag = value;
	}

	public final Pattern getCandidate() {
		return candidate;
	}

	public final void setCandidate(Pattern value) {
		candidate = value;
	}

	public final int getNumberOfSequences() {
		return numberOfSequences;
	}

	public final void setNumberOfSequences(int value) {
		numberOfSequences = value;
	}

	public ArrayList<Sequence> Seqbase;
	private int[] SeqIDs;
	private int numberOfSequences;
	private Item[][] ItemPointers;
	public Item[][] getItemPointers() { // 生成getset方法
		return ItemPointers;
	}
	public void setItemPointers(Item[][] itemPointers) {
		ItemPointers = itemPointers;
	}

	public double[][] getCanUtilities() {
		return CanUtilities;
	}

	public void setCanUtilities(double[][] canUtilities) {
		CanUtilities = canUtilities;
	}

	public double[] getMaxUtilities() {
		return MaxUtilities;
	}

	public void setMaxUtilities(double[] maxUtilities) {
		MaxUtilities = maxUtilities;
	} // 生成getset方法
	private double[][] CanUtilities;
	private int[] NumberOfPts;
	private int ProjItem;
	public double LeftUti;
	private double[] MaxUtilities;
	private double candidateUtility;
	public final double getCandidateUtility() {
		return candidateUtility;
	}
	public final void setCandidateUtility(double value) {
		candidateUtility = value;
	}
	public int[] getSeqIDs() {
		return SeqIDs;
	}
	private int[] blackList;
	private double[] candiBounds;

	public final double[] getCandiBounds() {
		return candiBounds;
	}

	public final void setCandiBounds(double[] value) {
		candiBounds = value;
	}

	private double pivotSumUtility;

	public final double getPivotSumUtility() {
		return pivotSumUtility;
	}

	public final void setPivotSumUtility(double value) {
		pivotSumUtility = value;
	}

	private double maxUtiofOffSprings;

	public final double getMaxUtiofOffSprings() {
		return maxUtiofOffSprings;
	}

	public final void setMaxUtiofOffSprings(double value) {
		maxUtiofOffSprings = value;
	}

	private TreeMap<Double, ArrayList<ConcItem>> itemsToBeConcatenatedSorted;

	public final TreeMap<Double, ArrayList<ConcItem>> getItemsToBeConcatenatedSorted() {
		return itemsToBeConcatenatedSorted;
	}

	public final void setItemsToBeConcatenatedSorted(TreeMap<Double, ArrayList<ConcItem>> value) {
		itemsToBeConcatenatedSorted = value;
	}

	private int concatenationItemsCount;

	public final int getConcatenationItemsCount() {
		return concatenationItemsCount;
	}

	public final void setConcatenationItemsCount(int value) {
		concatenationItemsCount = value;
	}

	private ArrayList<ConcItem> itemsToBeConcatenated;

	public final ArrayList<ConcItem> getItemsToBeConcatenated() {
		return itemsToBeConcatenated;
	}

	public final void setItemsToBeConcatenated(ArrayList<ConcItem> value) {
		itemsToBeConcatenated = value;
	}

	public ICDMProjectedSequenceBase(ArrayList<Sequence> Seqbase, double SeqbaseUtility) // 有参构造方法
	{
		this.candidate = new Pattern();
		this.Seqbase = Seqbase;
		this.seqbaseUtility = SeqbaseUtility;
		this.SeqIDs = null;
		this.MaxUtilities = null;
		this.numberOfSequences = 0;
		this.ItemPointers = null;
		this.CanUtilities = null;
		this.NumberOfPts = null;
		this.ProjItem = -1; 
		this.LeftUti = 0;
		this.candidateUtility = 0;
		// 效用表double类型存的是不同项的效用
		this.utiTable = new double[ICDMAlgos.NumberOfDistinctItems]; 
		this.concItems = new int[ICDMAlgos.NumberOfDistinctItems]; // 连接的项
		this.readyForConc = new int[ICDMAlgos.NumberOfDistinctItems];
		this.countFlag = new int[ICDMAlgos.NumberOfDistinctItems];
		this.blackList = new int[ICDMAlgos.NumberOfDistinctItems];
		this.setCandiBounds(new double[ICDMAlgos.NumberOfDistinctItems]);
		this.pivotSumUtility = 0;
		this.maxUtiofOffSprings = 0;
		this.itemsToBeConcatenated = new ArrayList<ConcItem>();
	}

	public ICDMProjectedSequenceBase(ICDMProjectedSequenceBase projbase) {
		this.candidate = new Pattern();// 创建新的Pattern属性
		this.Seqbase = projbase.Seqbase;// 序列数据库
		this.seqbaseUtility = getSeqbaseUtility();// 序列总效用
		this.SeqIDs = null;// 序列Id
		this.MaxUtilities = null;// 每条序列的最大效用
		this.numberOfSequences = 0;// 包含项集的序列的数量
		this.ItemPointers = null;// ItemPointers[i][j] 项的二维数组，i:序列,j:项集号
		this.CanUtilities = null;// CanUtilities[i][j] 已经连接好序列的效用 i:序列,j:项集号
		this.NumberOfPts = null;// 序列中已连接项的个数
		this.ProjItem = -1; // -1 means NOT_INITIALIATED
		this.LeftUti = 0;// 深度剪枝总的效用
		this.candidateUtility = 0;// 连接过的序列的总的效用
		this.utiTable = new double[ICDMAlgos.NumberOfDistinctItems];// 效用表
		this.concItems = new int[ICDMAlgos.NumberOfDistinctItems];//
		this.readyForConc = new int[ICDMAlgos.NumberOfDistinctItems];// 做好准备可以连接的
		this.countFlag = new int[ICDMAlgos.NumberOfDistinctItems];//
		this.blackList = (int[]) projbase.blackList.clone();// 不能被连接的项
		this.setCandiBounds((double[]) projbase.getCandiBounds().clone());//
		this.pivotSumUtility = 0;// 当前序列中项目的效用值总和
		this.maxUtiofOffSprings = 0;// 当前序列扩展出的子序列中最大效用值
		this.itemsToBeConcatenated = new ArrayList<ConcItem>();// 即将连接的项目列表

	}
	//投影数据库初始化
	public final void ProjectedSequenceBaseInit() // 投影数据库初始化
	{
		this.numberOfSequences = this.Seqbase.size();
		this.SeqIDs = new int[this.numberOfSequences];
		this.MaxUtilities = new double[this.numberOfSequences];
		this.ItemPointers = new Item[this.numberOfSequences][]; 
		this.CanUtilities = new double[this.numberOfSequences][];
		this.NumberOfPts = new int[this.numberOfSequences];
		this.LeftUti = this.seqbaseUtility; 

		this.candidateUtility = 0;
		for (int i = 0; i < this.Seqbase.size(); i++) {
			this.SeqIDs[i] = i; // 每条序列有一个SeqID 0 1 2
			this.MaxUtilities[i] = 0; // 每条序列有一个最大效用
			this.ItemPointers[i] = null;
			this.CanUtilities[i] = null;
			this.NumberOfPts[i] = 0;
		}

	}

	public final void Clear() {
		this.countFlag = new int[this.countFlag.length];
		this.utiTable = new double[this.utiTable.length];
		this.readyForConc = new int[this.readyForConc.length];
		this.concItems = new int[this.concItems.length];

		this.numerOfItems = 0;
	}

	//I扫描
	public final void Original_iScan() {
		int index, bound, sid, isidx;
		this.numerOfItems = 0;
		double[] utiList = new double[ICDMAlgos.NumberOfDistinctItems];
		this.Clear();
		for (int i = 0; i < this.numberOfSequences; i++) {
			double pivotuti = 0, estimateuti = 0;
			sid = this.SeqIDs[i];
			double seqbound = 0;
			seqbound += this.Seqbase.get(sid).getSequenceUtility(); // 总的效用值
			this.countFlag = new int[this.countFlag.length];       // 标记项目是否已经被处理过
			for (int j = 0; j < this.NumberOfPts[i]; j++) {          //  表示第 i 个序列中已处理或已连接的项目数量
				index = this.ItemPointers[i][j].getItemIndex();// 项索引
				isidx = this.ItemPointers[i][j].getItemsetIndex();// 项集索引
				bound = this.Seqbase.get(sid).getItemsets().get(isidx).size();  // 项长度
				pivotuti = this.CanUtilities[i][j];     // // 当前序列中项目的效用值总和
				for (int k = index + 1; k < bound; k++) {
					int itm;
					itm = this.Seqbase.get(sid).getItemsets().get(isidx).get(k).itemId;
					estimateuti = pivotuti + this.Seqbase.get(sid).getItemsets().get(isidx).get(k).utility;
					if (this.getUtiTable()[itm] == 0) {              // 作用是检查项目 itm 是否已经被处理过,如果效用表中该项目的效用值为0，说明该项目尚未被处理或尚未被添加到候选项目列表中。
						this.getConcItems()[this.getNumerOfItems()] = itm;              // this.getConcItems() 返回候选项目数组。
						this.setNumerOfItems(this.getNumerOfItems() + 1);
					}
					if (this.getCountFlag()[itm]  == 0) {            // 作用是检查项目 itm 是否已经被处理过,如果效用表中该项目的效用值为0，说明该项目尚未被处理或尚未被添加到候选项目列表中。
						this.getUtiTable()[itm] += seqbound;
						this.getCountFlag()[itm] = 1;
						utiList[itm] += estimateuti;
					}
				}
			}
		}
		int numberofcans = this.getNumerOfItems();
		this.setNumerOfItems(0);
		for (int i = 0; i < numberofcans; i++) {
			int itm = this.getConcItems()[i];
			if (this.getUtiTable()[itm]  >= ICDMAlgos.Threshold) {
				this.getReadyForConc()[this.getNumerOfItems()] = itm;
				this.setNumerOfItems(this.getNumerOfItems() + 1);
			}
		}

	}
	// 进行S扫描
	public final void Original_sScan() {
		int sid, projpos, ptst;
		this.Clear();
		for (int i = 0; i < this.numberOfSequences; i++) {
			sid = this.SeqIDs[i];
			double seqbound = 0;
			double pivotuti = 0;
			if (this.ItemPointers[i] == null) {
				projpos = 0;
				ptst = 0;
				for (int j = 0; j < this.Seqbase.get(sid).getTotalItems(); j++) {
					int itm;
					itm = this.Seqbase.get(sid).getItemScanningList()[j];
					if (this.blackList[itm] == 0) {
						seqbound += this.Seqbase.get(sid).getItemCumuUtis()[j];
					}
				}
			} else {
				projpos = this.ItemPointers[i][0].getItemsetIndex();
				ptst = this.Seqbase.get(sid).getItemsetsILSpointers()[projpos];
				pivotuti = this.CanUtilities[i][0];
				for (int j = ptst; j < this.Seqbase.get(sid).getTotalItems(); j++) {
					int itm;
					itm = this.Seqbase.get(sid).getItemScanningList()[j];
					if (this.blackList[itm] == 0) {
						seqbound += this.Seqbase.get(sid).getItemCumulativeUtilities()[projpos][j - ptst];
					}
				}
				seqbound += this.ItemPointers[i][0].getRestItemsetUtility();
				seqbound += pivotuti;
			}
			this.countFlag = new int[this.countFlag.length];
			for (int j = ptst; j < Seqbase.get(sid).getTotalItems(); j++) {
				int itm;
				itm = this.Seqbase.get(sid).getItemScanningList()[j];
				if (this.blackList[itm] == 0) {
					if (this.getUtiTable()[itm] == 0) {
						this.getConcItems()[this.getNumerOfItems()] = itm;
						this.setNumerOfItems(this.getNumerOfItems() + 1);
					}
					if (this.getCountFlag()[itm] == 0) {
						this.getUtiTable()[itm] += seqbound;
						this.getCountFlag()[itm] = 1;
					}
				}
			}
		}
		boolean isinbl = true;
		for (int i = 0; i < this.numerOfItems; i++) {
			int itm = this.getConcItems()[i];
			if (this.getUtiTable()[itm] < ICDMAlgos.Threshold) {
				isinbl = false;
				this.blackList[itm] = 1;
			}
		}
		if (isinbl) {
			int numberofcans = this.getNumerOfItems();
			this.setNumerOfItems(0);
			for (int i = 0; i < numberofcans; i++) {
				int itm = this.getConcItems()[i];
				if (this.getUtiTable()[itm]  >= ICDMAlgos.Threshold) {
					this.getReadyForConc()[this.getNumerOfItems()] = itm;
					this.setNumerOfItems(this.getNumerOfItems() + 1);
				}
			}
		} else {
			this.Original_sScan();
		}
	}

	/**
	 * 进行I连接
	 * 
	 * @param baseref
	 * @param itm
	 * @return
	 */
	public final boolean Original_iConcatenatingTheFields(ICDMProjectedSequenceBase baseref,          // baseref 投影数据库pjb
			int itm) {
		int sid, nscnt = 0, npcnt = 0, idx = 0, imin, imax, itemsetidx = 0, itemidx = 0;
		ArrayList<Item> itemset;
		boolean found = false, univfound = false;
		this.numberOfSequences = baseref.numberOfSequences;
		this.SeqIDs = new int[baseref.numberOfSequences];
		this.MaxUtilities = new double[baseref.numberOfSequences];
		this.NumberOfPts = new int[baseref.numberOfSequences];
		this.ItemPointers = new Item[baseref.numberOfSequences][];
		this.CanUtilities = new double[baseref.numberOfSequences][];
		this.candidate = new Pattern(baseref.candidate);
		this.candidate.insertItem(itm, true);
		//当前添加项全部的的项集号
		ArrayList<ArrayList<String>> SeqIndex = new ArrayList<ArrayList<String>>();
		//当前添加项全部的的效用
		ArrayList<ArrayList<Double>> SeqUtility = new ArrayList<ArrayList<Double>>();
		//当前添加项所有序列
		ArrayList<String> Sid = new ArrayList<String>();
		for (int i = 0; i < baseref.numberOfSequences; i++) {
			//添加项在第i条序列中的项集号
			ArrayList<String> seqMid = new ArrayList<String>();
			//添加项在第i条序列中的效用
			ArrayList<Double> seqUtility = new ArrayList<Double>();
			found = false;
			//序列id
			sid = baseref.SeqIDs[i];
			// nscnt，序列的数量
			this.NumberOfPts[nscnt] = 0;
			npcnt = 0;// 序列中有几个已连接项
			double highestutility = 0;
			// 遍历投影项的项集
			for (int j = 0; j < baseref.NumberOfPts[i]; j++) {
				// 取项集
				itemset = this.Seqbase.get(sid).getItemsets().get(baseref.ItemPointers[i][j].getItemsetIndex());
				// 当前投影点的下一个项
				imin = baseref.ItemPointers[i][j].getItemIndex() + 1;
				// 当前项集最后一项
				imax = this.Seqbase.get(sid).getItemsets().get(baseref.ItemPointers[i][j].getItemsetIndex()).size() - 1;
				// 二分查找
				idx = this.binary_search(itemset, itm, imin, imax);
				if (idx == -1) {
					continue;
				} else {
					if (!found) {
						Sid.add(""+sid);
						this.ItemPointers[nscnt] = new Item[baseref.NumberOfPts[i]];
						this.CanUtilities[nscnt] = new double[baseref.NumberOfPts[i]];
						itemsetidx = baseref.ItemPointers[i][j].getItemsetIndex();
						itemidx = idx;
					}
					this.NumberOfPts[nscnt]++;
					this.ItemPointers[nscnt][npcnt] = itemset.get(idx);
					this.CanUtilities[nscnt][npcnt] = baseref.CanUtilities[i][j] + itemset.get(idx).getUtility();
					highestutility = highestutility > this.CanUtilities[nscnt][npcnt] ? highestutility
							: this.CanUtilities[nscnt][npcnt];
					npcnt++;
					found = true;
					//添加当前项之前所有项的项集号
					ArrayList<String> preList = new ArrayList<String>();
					//添加当前项之前所有项的效用
					ArrayList<Double> preutility = new ArrayList<Double>();
					preList = this.candidate.getSeqIndex().get(i);
					preutility = this.candidate.getSequtility().get(i);
					//添加项的项集号
					ArrayList<String> currtList = new ArrayList<String>();
					//添加项的效用
					ArrayList<Double> currtutilityList = new ArrayList<Double>();
					//当前添加项
					String preitemindex = itemset.get(idx).getItemsetIndex()+"*";
					for (int k = 0; k < preList.size(); k++) {
						boolean flag;
						//比较当前添加项和当前添加项的前一个项的项集号是否相同
						if(preList.get(k).length()>=preitemindex.length()){
						flag = preitemindex.equals("" + preList.get(k).substring(preList.get(k).length()-preitemindex.length()));
						if (flag) {
							String current = preList.get(k) + itemset.get(idx).getItemsetIndex()+"*";
							Double curutility = preutility.get(k) + itemset.get(idx).getUtility();
							currtList.add(current);
							currtutilityList.add(curutility);
						}
						}
					}
					seqMid.addAll(currtList);
					seqUtility.addAll(currtutilityList);
				}
			}
			if (found) {
				this.SeqIDs[nscnt] = sid;
				this.MaxUtilities[nscnt] = highestutility;
				// 更新 LeftUti，用于后续的剪枝操作，以决定是否继续扩展该序列。
				this.LeftUti += (this.CanUtilities[nscnt][0]
						+ this.Seqbase.get(sid).getItemsets().get(itemsetidx).get(itemidx).restSequenceUtility);
				this.pivotSumUtility += this.CanUtilities[nscnt][0];
				this.candidateUtility += this.MaxUtilities[nscnt];
				this.NumberOfPts[nscnt] = npcnt;
				nscnt++;
				univfound = true;
			}
			if (seqMid!=null&&!seqMid.isEmpty()) {
			SeqIndex.add(seqMid);
			SeqUtility.add(seqUtility);
			 }
		}
		//将添加项所有的项集号添加到总的存储对象中
		this.candidate.setSeqIndex(SeqIndex);
		this.candidate.setSequtility(SeqUtility);
		this.candidate.setSid(Sid);
		if (univfound) {
			this.ProjItem = itm;
			this.numberOfSequences = nscnt;
		}
		return univfound;
	}

	/**
	 * 进行S连接
	 * 
	 * @param baseref
	 * @param itm
	 * @return
	 */
	public final boolean Original_sConcatenatingTheFields(ICDMProjectedSequenceBase baseref, int itm) {
		int sid, nscnt = 0, npcnt = 0, idx = 0, j;
		Item stpos;
		boolean found = false, univfound = false;
		this.numberOfSequences = baseref.numberOfSequences;
		this.SeqIDs = new int[baseref.numberOfSequences];
		this.MaxUtilities = new double[baseref.numberOfSequences];
		this.NumberOfPts = new int[baseref.numberOfSequences];
		this.ItemPointers = new Item[baseref.numberOfSequences][];
		this.CanUtilities = new double[baseref.numberOfSequences][];
		this.candidate = new Pattern(baseref.candidate);
		this.candidate.insertItem(itm, false);
		//当前添加项全部的的项集号
		ArrayList<ArrayList<String>> SeqIndex = new ArrayList<ArrayList<String>>();
		//当前添加项全部的的效用
		ArrayList<ArrayList<Double>> SeqUtility = new ArrayList<ArrayList<Double>>();
		//当前添加项来自的序列
		ArrayList<String> Sid = new ArrayList<String>();
		for (int i = 0; i < baseref.numberOfSequences; i++) {
			//添加项在第i条序列中的项集号
			ArrayList<String> seqMid = new ArrayList<String>();
			//当前添加项全部的的效用
			ArrayList<Double> seqUtility = new ArrayList<Double>();
			found = false;
			sid = baseref.SeqIDs[i];
			this.NumberOfPts[nscnt] = 0;
			npcnt = 0;
			int inij = this.Seqbase.get(sid).getItemsets().size();
			if (this.Seqbase.get(sid).getItemMap().containsKey(itm)) {
				stpos = this.Seqbase.get(sid).getItemMap().get(itm);
			} else {
				continue;
			}
			j = baseref.ItemPointers[i] == null ? 0 : baseref.ItemPointers[i][0].getItemsetIndex() + 1;
			Item pter = stpos;
			for (; pter != null; pter = pter.getRight()) {
				if (pter.getItemsetIndex() >= j) {
					found = true;
					j = pter.getItemsetIndex();
					idx = pter.getItemIndex();
					inij = inij < j ? inij : j;
					break;
				}
			}
			// If the avaivable concatenation point is found
			if (found) {
				Sid.add(""+sid);
				this.ItemPointers[nscnt] = new Item[this.Seqbase.get(sid).getItemsets().size()];
				this.CanUtilities[nscnt] = new double[this.Seqbase.get(sid).getItemsets().size()];
				int prepointer = 0;
				double prehighestutility = 0, currentitemutility, utility, highestutility = 0;
				for (; pter != null; pter = pter.getRight()) {
					while (prepointer < baseref.NumberOfPts[i]
							&& baseref.ItemPointers[i][prepointer].getItemsetIndex() < pter.getItemsetIndex()) {
						prehighestutility = prehighestutility < baseref.CanUtilities[i][prepointer]
								? baseref.CanUtilities[i][prepointer] : prehighestutility;
						//添加当前项之前所有项的项集号
						ArrayList<String> preList = new ArrayList<String>();
						//添加当前项之前所有项的效用
						ArrayList<Double> preutility = new ArrayList<Double>();
						preList = this.candidate.getSeqIndex().get(i);
						preutility = this.candidate.getSequtility().get(i);
						ArrayList<String> currtList = new ArrayList<String>();
						ArrayList<Double> currtutilityList = new ArrayList<Double>();
						//当前添加项前一个项的项集号
						String prestr = baseref.ItemPointers[i][prepointer].getItemsetIndex() + "*";
						for (int k = 0; k < preList.size(); k++) {
							//判断当前添加项和当前添加项之前的项的项集号是否相同
							if(preList.get(k).length()>=prestr.length()){
							boolean flag = prestr.equals("" + preList.get(k).substring(preList.get(k).length()-prestr.length()));
							if (flag) {
								String current = preList.get(k) + pter.getItemsetIndex()+"*";
								Double curutility = preutility.get(k) + pter.getUtility();
								currtList.add(current);
								currtutilityList.add(curutility);
							}
							}
						}
						seqMid.addAll(currtList);
						seqUtility.addAll(currtutilityList);
						prepointer++;
					}
					currentitemutility = pter.getUtility();
					utility = prehighestutility + currentitemutility;
					this.ItemPointers[nscnt][npcnt] = pter;
					this.CanUtilities[nscnt][npcnt] = utility;
					npcnt++;
					if (utility > highestutility) {
						highestutility = utility;
					}
					this.MaxUtilities[nscnt] = highestutility;
					if (prepointer == 0) {
						String newstr = pter.getItemsetIndex()+"*";
						seqMid.add(newstr);
						seqUtility.add(pter.getUtility());
					}
					prepointer = 0;
				}
				this.SeqIDs[nscnt] = sid;
				this.NumberOfPts[nscnt] = npcnt;
				this.candidateUtility += this.MaxUtilities[nscnt];
				this.LeftUti += (this.CanUtilities[nscnt][0]
						+ this.Seqbase.get(sid).getItemsets().get(inij).get(idx).restSequenceUtility);
				this.pivotSumUtility += this.CanUtilities[nscnt][0];
				univfound = true;
				nscnt++;
			}
			if (seqMid!=null&&!seqMid.isEmpty()) {
			SeqIndex.add(seqMid);
			SeqUtility.add(seqUtility);
			 }
		}
		this.candidate.setSeqIndex(SeqIndex);
		this.candidate.setSequtility(SeqUtility);
		this.candidate.setSid(Sid);
		if (univfound) {
			this.ProjItem = itm;
			this.numberOfSequences = nscnt;
			// return true;
		}
		return univfound;
	}

	/**
	 * 二分法查找
	 * 
	 * @param seq
	 * @param key
	 * @param imin
	 * @param imax
	 * @return
	 */
	private int binary_search(ArrayList<Item> seq, int key, int imin, int imax) {
		// continue searching while [imin,imax] is not empty
		while (imax >= imin) {
			/* calculate the midpoint for roughly equal partition */
			int imid = (imin + imax) / 2;

			// determine which subarray to search
			if (seq.get(imid).getItemId() < key) {
				// change min index to search upper subarray
				imin = imid + 1;
			} else if (seq.get(imid).getItemId() > key) {
				// change max index to search lower subarray
				imax = imid - 1;
			} else {
				// key found at index imid
				return imid;
			}
		}
		// key not found
		return -1;
	}

}