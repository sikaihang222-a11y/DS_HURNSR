package USpanPlusOptimal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.sql.SQLOutput;
import java.text.SimpleDateFormat;
import java.util.*;

import NegHightUtilitySeq.NegHightUtilitySeq;
import Rule.GeneRule;
import Rule.Rule;


public class ICDMProgram {
	public static java.io.OutputStreamWriter ofsu;
	public static StopWatch overallStopWatch;
	public static int leftcnt = 0;
	public static int itemutiboundcnt = 0;
	public static boolean debugSwitch = false;
	public static UTimer debugTimer = new UTimer();
	public static long startStamp = 0;
	public static long endStamp = 0;

	/**
	 * Feb 29,2024
	 * Merge()方法将两个字符串进行合并
	 * @param val1
	 * @param val2
	 * @return
	 */
	public static String Merge(String val1, String val2)
	{
		String ret = "";
		System.out.println("merge 方法被调用");
		String[] temp1 = val1.split("\t");
		String[] temp2 = val2.split("\t");
		if (temp1.length == temp2.length)
		{
			for (int i = 0; i < temp1.length; i++)
			{
				ret += String.valueOf((Double.parseDouble(temp1[i]) + Double.parseDouble(temp2[i]))) + "\t";
			}
		}
		return ret; // 返回合并后的字符串
	}

	public static void main(String[] args) throws IOException {
//		double[] thresholds =  {0.01,0.011,0.012};
		double[] thresholds =  {0.01};
//		for(double threshold:thresholds){
			int batchSize =10; // 每个批次包含多少个序列
			int windowSize =8;
			List<List<Pattern>> SeqList = new ArrayList<List<Pattern>>();    // 存储Uspan算法返回的高效序列（List（0）），所有序列（list（1））
			List<Pattern> allSeqList = new ArrayList<Pattern>();// 所有序列
			List<Pattern> HightUtilitySeqList = new ArrayList<Pattern>();    // 所有高效序列
			List<Pattern> NegHightUtilitySeqList = new ArrayList<Pattern>();    // 所有负高效序列
//			List<Pattern> testNegHightUtilitySeqList = new ArrayList<Pattern>();    // 所有负高效序列
            List<Pattern> RNNegHightUtilitySeqList = new ArrayList<Pattern>(); //所有高效重复负序列
			/******************************** 运行程序需要初始化的参数/数据库文件 *******************************************/

//			String datasetFile = "kosarak_Seq.txt";
			String datasetFile = "100BIKE.txt";
			/**********************************************************************************************************/
			ICDMAlgos tpk = new ICDMAlgos(); // 创建一个ICDMAlgos类的实例tpk
			tpk.ReadCosmosDataTestFunction(datasetFile); // 读取数据集
			List<Sequence> allSequences = tpk.getInsertedSeqbase(); // 获取所有读取的序列
			// 输出所有的序列
//			System.out.println("All sequences read from the file:");
//			for (Sequence sequence : allSequences) {
//				System.out.println(sequence); // 调用 toString 方法输出
//			}
		    // 将序列划分为批次
			List<List<Sequence>> batches = createBatches(allSequences, batchSize);
			// 输出每个批次的信息
//			for (int i = 0; i < batches.size(); i++) {
//				System.out.println("批次 " + (i + 1) + ": " + batches.get(i));
//			}

		// 逻辑树数据结构
			Map<String, double[]> prefixTree = new HashMap<>();
			List<Double> windowUtilities = new ArrayList<>();
			// Process each threshold
			for (double threshold : thresholds) {
				System.out.println("Processing threshold: " + threshold);
				int currentWindowSize = 0;

				for (List<Sequence> batch : batches) {
					currentWindowSize++;
//					System.out.println("Processing batch " + currentWindowSize + " of " + batches.size());

					// Process the batch and store high utility patterns in prefixTree
					processBatch(batch, tpk, threshold, prefixTree,currentWindowSize,windowUtilities,windowSize);
//					printPrefixTree(prefixTree);
					// If window is full, process the window and then slide
					if (currentWindowSize >= windowSize) {
						double minUtilityThreshold = calculateWindowUtilityThreshold(windowUtilities, threshold);
//						processSlidingWindow(prefixTree, threshold);
						// Extract high utility patterns from the current window
						extractHighUtilityPatterns(prefixTree, minUtilityThreshold);
//						currentWindowSize--;  // Keep the window size constant by reducing one
						slideUtilityArrays(prefixTree);
						windowUtilities.remove(0); // 移除最早批次的效用值
						currentWindowSize--; // 维持窗口大小

					}
				}
			}


//			System.out.println(ICDMAlgos.items + "\t" + ICDMAlgos.itemsets); // 数据集中项的数目和项集的数目
/*			logger.info("threshold："+threshold);*/
			USpanPlus.NumberOfDistinctItems = ICDMAlgos.NumberOfDistinctItems;
			USpanPlus.itemIdsMapping = ICDMAlgos.itemIdsMapping;
			StopWatch timer = new StopWatch();
			ICDMProgram.overallStopWatch = new StopWatch();
			timer.start();
			java.io.OutputStreamWriter ofs = null;
			// ------------------------------ Running from here
			// ------------------------------
			long startTime=System.currentTimeMillis();
//			SeqList = tpk.Original_RunUSpanPlus(threshold);    // 返回高效用序列和效用。  for
/*			System.out.println("求高效用序列所需时间："+(endTime-startTime)+" ms");*/
//			HightUtilitySeqList = SeqList.get(0);    // 高效用序列
//			allSeqList = SeqList.get(1);    // 全部序列



//			 ------------------------------ 求负高效用序列
//            所有高效重复序列
//            List<Pattern> RNHightUtilitySeqList = new ArrayList<Pattern>(allSeqList);//RNHightUtilitySeqList创建了allSeqList的一个副本
//			for (int i=0;i<RNHightUtilitySeqList.size();i++)
//			{
//				for (int j =0;j<RNHightUtilitySeqList.get(i).getSeqIndex().size();j++){
//					int listId = RNHightUtilitySeqList.get(i).getSeqIndex().get(j).size();
//					if (listId>=3) {
//						for (int k = 0; k < listId; k++) {
//							String ref0 = RNHightUtilitySeqList.get(i).getSeqIndex().get(j).get(k);//在特定序列中的第一次出现
//							String[] splref0 = ref0.split("\\*"); // 根据 "*" 分割字符串
//							for (int t = k + 1; t < listId; t++) {
//								String ref1 = RNHightUtilitySeqList.get(i).getSeqIndex().get(j).get(t);//在特定序列中的第二次出现
//								String[] splref1 = ref1.split("\\*"); // 根据 "*" 分割字符串
//								boolean isDuplicate = false;//用于标记两个位置是否重复
//								for (int z = 0; z < splref0.length; z++) {
//									if (Objects.equals(splref0[z], splref1[z])) {//逐项比较：“只要发现 splref0 和 splref1 在某一个位置上有相同的项”，就立即将 isDuplicate 设为 true，然后跳出该比较循环。
//										isDuplicate = true;
//									}// 这样判断两个数组是否相同是没错的，接下来就是要找一个方法把重叠的序列值删掉
//									if (isDuplicate) break;//若出现位置重叠，则跳出循环结构
//								}
//								if (isDuplicate) {
//									RNHightUtilitySeqList.get(i).getSeqIndex().get(j).remove(t);
//									RNHightUtilitySeqList.get(i).getSequtility().get(j).remove(t);
//									t--; // 调整 t 以重新检查新的 t 位置的元素
//									listId--; // 减少 listId 以反映删除的元素
//								}
//							}
//						}
//					}
//				}
//
//			}
//			// 累加至Utility
//			for (int i=0;i<RNHightUtilitySeqList.size();i++){
//				Double totalUtility = 0.0;
//				for (int j =0;j<RNHightUtilitySeqList.get(i).getSequtility().size();j++) {
//					int listId = RNHightUtilitySeqList.get(i).getSequtility().get(j).size();
//					double utilityResult = 0.0;
//					if (listId <= 2) {
//						double maxUtility = Double.NEGATIVE_INFINITY;
//						for (int k = 0; k < listId; k++) {
//							double utility = RNHightUtilitySeqList.get(i).getSequtility().get(j).get(k);
//							if (utility > maxUtility) {
//								maxUtility = utility;
//							}
//						}
//						utilityResult = maxUtility;
//						RNHightUtilitySeqList.get(i).getSequtility().get(j).set(0,utilityResult);
//					}
//
//
//				}
//
//			}
//
//			for (int i = 0; i < RNHightUtilitySeqList.size(); i++) {
//				Double totalUtility = 0.0;
//				for (int j = 0; j < RNHightUtilitySeqList.get(i).getSequtility().size(); j++) {
//					for (int k = 0; k < RNHightUtilitySeqList.get(i).getSequtility().get(j).size(); k++) {
//
//							totalUtility += RNHightUtilitySeqList.get(i).getSequtility().get(j).get(k);
//
//					}
//				}
//				RNHightUtilitySeqList.get(i).setUtility(totalUtility);
//			}
//
//
//
//			// 高效用判断
//			for (int i=0;i<RNHightUtilitySeqList.size();i++) {
//				if (RNHightUtilitySeqList.get(i).getUtility() >= ICDMAlgos.Threshold) {
//					testNegHightUtilitySeqList.add(RNHightUtilitySeqList.get(i));
//				}
//
//			}

//
//
///*			long NstartTime=System.currentTimeMillis();*/
//			NegHightUtilitySeq NHS = new NegHightUtilitySeq();
//			NegHightUtilitySeq RNNHS = new NegHightUtilitySeq();
//			long startTime2=System.currentTimeMillis();
//			NegHightUtilitySeqList = NHS.NegHightUtilitySe

//(HightUtilitySeqList, testNegHightUtilitySeqList);// 负高效序列
//			long endTime2=System.currentTimeMillis();
//			long endTime=System.currentTimeMillis();
//			RNNegHightUtilitySeqList = RNNHS.NegHightUtilitySeq(testNegHightUtilitySeqList, testNegHightUtilitySeqList);// 重复负高效序列
///*			long endTime=System.currentTimeMillis();*/
//			System.out.println("H序列数量="+HightUtilitySeqList.size());
//			System.out.println("全部重复正序列数量="+testNegHightUtilitySeqList.size());
//			System.out.println("全部候选数量="+allSeqList.size());
//			System.out.println("全部负序列数量="+NegHightUtilitySeqList.size());			// 该序列的总效用
//			System.out.println("全部重复负序列数量="+RNNegHightUtilitySeqList.size());			// 该序列的总效用
//			System.out.println("求高效用序列所需时间："+(endTime-startTime)+" ms");
/*			logger.info("求高效用序列所需时间："+(endTime-startTime)+" ms");
			logger.info("全部负序列数量="+NegHightUtilitySeqList.size());
			logger.info("全部候选数量="+allSeqList.size());
			logger.info("全部重复正序列数量="+testNegHightUtilitySeqList.size());
			logger.info("全部重复负序列数量="+RNNegHightUtilitySeqList.size());
			logger.info("===========================================");*/
/*			long NendTime=System.currentTimeMillis();*/
/*			System.out.println("求负高效用序列所需时间："+(NendTime-NstartTime)+" ms");*/


//		} // main()end
	}// 异常 end
	private static List<List<Sequence>> createBatches(List<Sequence> allSequences, int batchSize) {
		List<List<Sequence>> batches = new ArrayList<>();
		for (int i = 0; i < allSequences.size(); i += batchSize) {
			int end = Math.min(i + batchSize, allSequences.size());
			batches.add(new ArrayList<>(allSequences.subList(i, end)));
		}
		return batches;
	}
//	没加重复
	private static void processBatch(List<Sequence> batch, ICDMAlgos tpk, double threshold,
									 Map<String, double[]> prefixTree, int currentWindowSize,List<Double> windowUtilities,int windowSize) {
		// Initialize the ICDMAlgos for the batch
		List<List<Pattern>> batchResults = tpk.Original_RunUSpanPlus(threshold, batch);
//		System.out.println("Starting processBatch for a new batch with threshold: " + threshold);
		double batchUtility = 0.0;
		for (Sequence sequence : batch) {
			batchUtility += sequence.getSequenceUtility();
		}
		windowUtilities.add(batchUtility);
		// Output the utility of the batch
//		System.out.println("Batch total utility: " + batchUtility);
		// Extract high utility sequences
		List<Pattern> highUtilityPatterns = batchResults.get(0);

//		for (Pattern highpattern : highUtilityPatterns) {
//			double utility = highpattern.getUtility();
//			String patternStr = highpattern.cleanpattern();
//			System.out.println("highPattern: " + patternStr + ", Utility: " + utility);
//		}
//		System.out.println("Batch processing complete. Number of patterns found: " + batchResults.get(0));


		// Compute batch utility and store patterns
		for (Pattern pattern : highUtilityPatterns) {
			// Generate a string key for the pattern
			String patternKey = pattern.cleanpattern();
			// Update the prefixTree with the pattern and its utility
			prefixTree.putIfAbsent(patternKey, new double[windowSize]);//如果键值对在map中不存在，则以patternKey为键插入一个新的效用数组new double[windowSize]
			double[] utilityArray = prefixTree.get(patternKey);//获取该模式的效用值
			// Slide left and insert utility at the end
			utilityArray[currentWindowSize - 1] = pattern.getUtility();//插入到效用数组utilityArray与批次对应的位置处
		}

	}


//	private static void processBatch(List<Sequence> batch, ICDMAlgos tpk, double threshold,
//								 Map<String, double[]> prefixTree, int currentWindowSize, List<Double> windowUtilities, int windowSize) {
//	// 使用原始的高效用序列挖掘算法对批次进行挖掘
//	List<List<Pattern>> batchResults = tpk.Original_RunUSpanPlus(threshold, batch);
//	System.out.println("Starting processBatch for a new batch with threshold: " + threshold);
//
//	double batchUtility = 0.0;
//	for (Sequence sequence : batch) {
//		batchUtility += sequence.getSequenceUtility();
//	}
//	windowUtilities.add(batchUtility);
////	System.out.println("Batch total utility: " + batchUtility);
//
//	List<Pattern> candidatePatterns = batchResults.get(1); // 候选模式的列表
//	List<Pattern> RNHightUtilitySeqList = new ArrayList<Pattern>(candidatePatterns); // 创建候选模式的副本
//	List<Pattern> testNegHightUtilitySeqList = new ArrayList<Pattern>();
//	// 2. 计算模式在批次内的效用累加值
//		for (int i = 0; i < RNHightUtilitySeqList.size(); i++) {
//			Double totalUtility = 0.0;
//			for (int j = 0; j < RNHightUtilitySeqList.get(i).getSeqIndex().size(); j++) {
//				int listId = RNHightUtilitySeqList.get(i).getSeqIndex().get(j).size();
//				if (listId >= 3) {
//					for (int k = 0; k < listId; k++) {
//						String ref0 = RNHightUtilitySeqList.get(i).getSeqIndex().get(j).get(k);
//						String[] splref0 = ref0.split("\\*"); // 根据 "*" 分割字符串
//						for (int t = k + 1; t < listId; t++) {
//							String ref1 = RNHightUtilitySeqList.get(i).getSeqIndex().get(j).get(t);
//							String[] splref1 = ref1.split("\\*"); // 根据 "*" 分割字符串
//							boolean isDuplicate = false;
//							for (int z = 0; z < splref0.length; z++) {
//								if (Objects.equals(splref0[z], splref1[z])) {
//									isDuplicate = true;
//								}// 这样判断两个数组是否相同是没错的，接下来就是要找一个方法把重叠的序列值删掉
//								if (isDuplicate) break;
//							}
//							if (isDuplicate) {
//								RNHightUtilitySeqList.get(i).getSeqIndex().get(j).remove(t);
//								RNHightUtilitySeqList.get(i).getSequtility().get(j).remove(t);
//								t--; // 调整 t 以重新检查新的 t 位置的元素
//								listId--; // 减少 listId 以反映删除的元素
//							}
//						}
//					}
//				}
//				else if (listId <= 2) {
//					double maxUtility = Double.NEGATIVE_INFINITY;
//					for (int k = 0; k < listId; k++) {
//						double utility = RNHightUtilitySeqList.get(i).getSequtility().get(j).get(k);
//						if (utility > maxUtility) {
//							maxUtility = utility;
//						}
//					}
//					double utilityResult = maxUtility;
//					RNHightUtilitySeqList.get(i).getSequtility().get(j).set(0, utilityResult);
//				}
//			}
//		}
//		for (int i = 0; i < RNHightUtilitySeqList.size(); i++){
//			double totalUtility = 0.0;
//			for (int j = 0 ; j<RNHightUtilitySeqList.get(i).getSequtility().size();j++){
//				// 模式每个项集的效用
//				if (RNHightUtilitySeqList.get(i).getSequtility().get(j).size()>=2){
//					// 说明是重复项集，累加
//					for (int k = 0; k<RNHightUtilitySeqList.get(i).getSequtility().get(j).size();k++){
//						totalUtility +=RNHightUtilitySeqList.get(i).getSequtility().get(j).get(k);
//					}
//				}
//				else {
//					totalUtility += RNHightUtilitySeqList.get(i).getSequtility().get(j).get(0);
//				}
//
//			}
//			RNHightUtilitySeqList.get(i).setUtility(totalUtility);
//		}
//
//
//	// 高效用判断
//	for (int i = 0; i < RNHightUtilitySeqList.size(); i++) {
//		if (RNHightUtilitySeqList.get(i).getUtility() >= ICDMAlgos.Threshold) {
//			testNegHightUtilitySeqList.add(RNHightUtilitySeqList.get(i));
//		}
//
//	}
//	// 3. 判断是否满足最小效用阈值并将符合条件的模式加入prefixTree
//	for (Pattern pattern : testNegHightUtilitySeqList) {
//		// Generate a string key for the pattern
//			String patternKey = pattern.cleanpattern();
//			prefixTree.putIfAbsent(patternKey, new double[windowSize]);//如果键值对在map中不存在，则以patternKey为键插入一个新的效用数组new double[windowSize]
//			double[] utilityArray = prefixTree.get(patternKey);////获取该模式的效用值
//			utilityArray[currentWindowSize - 1] = pattern.getUtility();//插入到效用数组utilityArray与批次对应的位置处
//	}
//}
	private static double calculateWindowUtilityThreshold(List<Double> windowUtilities, double threshold) {
		double totalUtility = 0.0;
		for (double utility : windowUtilities) {
			totalUtility += utility;
		}
//		System.out.println("当前窗口的总效用值："+totalUtility);
		return totalUtility * threshold;
	}
	private static void extractHighUtilityPatterns(Map<String, double[]> prefixTree, double minUtilityThreshold) {
//		System.out.println("Extracting high utility patterns with min threshold: " + minUtilityThreshold);
		int highUtilityPatternCount = 0; // 用于统计高效用模式的数量
		for (Map.Entry<String, double[]> entry : prefixTree.entrySet()) {
			double sumUtility = 0.0;
			for (double utility : entry.getValue()) {
				sumUtility += utility;
			}
			if (sumUtility >= minUtilityThreshold) {
//				System.out.println("High utility pattern of full window: " + entry.getKey() + " with utility: " + sumUtility);
				highUtilityPatternCount++; // 每发现一个高效用模式，计数加 1

			}
		}
		// 输出高效用模式的数量
		System.out.println("Total number of high utility patterns: " + highUtilityPatternCount);
	}
	private static void slideUtilityArrays(Map<String, double[]> prefixTree) {
		for (double[] utilityArray : prefixTree.values()) {
			System.arraycopy(utilityArray, 1, utilityArray, 0, utilityArray.length - 1);
			utilityArray[utilityArray.length - 1] = 0.0;
		}
	}
	// 输出每个模式在不同批次下的效用数组
//	private static void printPrefixTree(Map<String, double[]> prefixTree) {
//		for (Map.Entry<String, double[]> entry : prefixTree.entrySet()) {
//			String patternKey = entry.getKey();
//			double[] utilityArray = entry.getValue();
//
//			System.out.print("Pattern: " + patternKey + ", Utility Array: [");
//			for (int i = 0; i < utilityArray.length; i++) {
//				System.out.print(utilityArray[i]);
//				if (i < utilityArray.length - 1) {
//					System.out.print(", ");
//				}
//			}
//			System.out.println("]");
//		}
//	}



}// class ICDMProgram end