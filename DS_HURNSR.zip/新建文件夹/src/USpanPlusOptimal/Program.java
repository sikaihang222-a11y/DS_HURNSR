package USpanPlusOptimal;

import java.awt.Panel;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Program
{
	public static StopWatch TightRunningTime = new StopWatch();

	public static String Merge(String val1, String val2)
	{
		//System.out.println("!=1=");

		String ret = "";
		String[] temp1 = val1.split("\t");
		String[] temp2 = val2.split("\t");
		if (temp1.length == temp2.length)
		{
			for (int i = 0;i < temp1.length ;i++)
			{
				ret += String.valueOf((Double.parseDouble(temp1[i]) + Double.parseDouble(temp2[i]))) + "\t";
			}
		}
		return ret;
	}

	private static void write_complete_sequencebase(String filepath, ArrayList<Sequence> seqbase, int count) throws IOException
	{
		
		//System.out.println("!111111111111111111=");

		//BufferedReader bfr = new BufferedReader(arg0)
			      
		//java.io.OutputStreamWriter bw = new java.io.OutputStreamWriter(new outputs);
		BufferedWriter bw = null;
		bw = new BufferedWriter(new FileWriter(filepath));
		for (int i = 0;i < seqbase.size() && i < count;i++)
		{
			for (int j = 0;j < seqbase.get(i).getItemsets().size();j++)
			{
				for (int k = 0; k < seqbase.get(i).getItemsets().get(j).size(); k++)
				{
					int item = seqbase.get(i).getItemsets().get(j).get(k).itemId;
					double utility = seqbase.get(i).getItemsets().get(j).get(k).utility;
					//of<<i<<"\t"<<j<<"\t"<<item<<"\t"<<quantity<<endl;
					bw.write((i + 1) + "\t" + (j + 1) + "\t" + item + "\t" + utility + System.lineSeparator());
				}
			}
		}
		bw.close();
	}
	
}