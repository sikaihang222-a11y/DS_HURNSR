package USpanPlusOptimal;

import java.util.*;

public class ConcItem
{
	public int Item;
	public int Indicator;
	public double ItemUtility;
	public double Boundry;

	public ConcItem()
	{
		this.Item = 0;
		this.Indicator = 0;
		this.Boundry = 0;
		this.ItemUtility = 0;
	}

}