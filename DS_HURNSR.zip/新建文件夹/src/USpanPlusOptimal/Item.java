package USpanPlusOptimal;

import java.util.Arrays;

public class Item //定义一个公共类Item
{
	/**
	 * 代表abc
	 */
	public int itemId; //项ID (a:1, b:2, c:3)
	/**
	 * 代表一个项醋不能再于项集中
	 */
	public int itemIndex; //项索引
	/**
	 * 一条序列中项集的下标
	 */
	public int itemsetIndex; //项集索引
	/**
	 * 每一个项的效用
	 */
	public double utility; //效用
	/**
	 * 剩余的序列效应
	 */
	public double restSequenceUtility; //剩余序列效用
	public final double getRestSequenceUtility()
	{
		return restSequenceUtility;
	}
	public final void setRestSequenceUtility(double value)
	{
		restSequenceUtility = value;
	}

	/**
	 * 一个项集的剩余项集效用
	 */
	private double restItemsetUtility; //剩余项集效用
	public final double getRestItemsetUtility()
	{
		return restItemsetUtility;
	}
	public final void setRestItemsetUtility(double value)
	{
		restItemsetUtility = value;
	}
/**
 * 
 */
	private double[] utilities; //效用数组
	public final double[] getUtilities()
	{
		return utilities;
	}
	public final void setUtilities(double[] value)
	{
		utilities = value;
	}



	private Item right; //在Item类内定义一个私有的Item实例right，right拥有所有类Item的字段和方法
	public final Item getRight()
	{
		return right;
	}
	public final void setRight(Item value)
	{
		right = value;
	}


	public final void print() //打印 项ID、项索引、项集索引、效用、剩余效用、类Item的一个实例right
	{
		System.out.println("itemId" + this.itemId + "\titemIndex" + this.itemIndex + "\titemsetIndex" + this.itemsetIndex + "\tutility" + this.utility + "\trestutility" + this.restSequenceUtility + "\tright" + this.right);
	}

	public Item() //空参构造方法，给字段赋值
	{
		this.itemId = -1;
		this.itemIndex = -1;
		this.itemsetIndex = -1;
		this.utility = 0;
		this.restSequenceUtility = 0;
		this.restItemsetUtility = 0;
		this.right = null;
	}

	public Item(Item item) //有参构造方法，给字段赋值
	{
		this.itemId = item.itemId;
		this.itemIndex = item.itemIndex;
		this.itemsetIndex = item.itemsetIndex;
		this.utility = item.utility;
		this.restSequenceUtility = item.restSequenceUtility;
		this.restItemsetUtility = item.restItemsetUtility;
		this.right = null;
	}

	public final int getItemId()
	{
		return itemId;
	}
	public final void setItemId(int value)
	{
		itemId = value;
	}

	public final int getItemIndex()
	{
		return itemIndex;
	}
	public final void setItemIndex(int value)
	{
		itemIndex = value;
	}

	public final int getItemsetIndex()
	{
		return itemsetIndex;
	}
	public final void setItemsetIndex(int value)
	{
		itemsetIndex = value;
	}

	public final double getUtility()
	{
		return utility;
	}
	public final void setUtility(double value)
	{
		utility = value;
	}
	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemIndex=" + itemIndex
				+ ", itemsetIndex=" + itemsetIndex + ", utility=" + utility
				+ ", restSequenceUtility=" + restSequenceUtility
				+ ", restItemsetUtility=" + restItemsetUtility + ", utilities="
				+ Arrays.toString(utilities) + ", right=" + right + "]";
	}
	
	
}