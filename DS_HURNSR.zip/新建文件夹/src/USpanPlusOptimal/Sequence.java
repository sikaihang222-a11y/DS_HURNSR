package USpanPlusOptimal;

import java.util.*;

public class Sequence
{
	private int sequenceId; //序列id
	private double sequenceUtility; //序列效用
	private ArrayList<ArrayList<Item>> itemsets; //嵌套表

	private int totalItems;
	private int[] itemScanningList; //项扫描表数组，int类型
	private int[] itemsetsILSpointers; //项集指针数组，int类型

	private HashMap<Integer, Item> itemMap; //Dictionary形式的项集合map

	public final int[] getItemsetsILSpointers()
	{
		return itemsetsILSpointers;
	}
	public final void setItemsetsILSpointers(int[] value)
	{
		itemsetsILSpointers = value;
	}
	public final int[] getItemScanningList()
	{
		return itemScanningList;
	}
	public final void setItemScanningList(int[] value)
	{
		itemScanningList = value;
	}
	public final HashMap<Integer, Item> getItemMap()
	{
		return itemMap;
	}
	public final void setItemMap(HashMap<Integer, Item> value)
	{
		itemMap = value;
	}
	public final int getTotalItems()
	{
		return totalItems;
	}
	public final void setTotalItems(int value)
	{
		totalItems = value;
	}

	private double[][] itemCumulativeUtilities; //项累积效用
	public final double[][] getItemCumulativeUtilities()
	{
		return itemCumulativeUtilities;
	}
	public final void setItemCumulativeUtilities(double[][] value)
	{
		itemCumulativeUtilities = value;
	}

	private double[] itemCumuUtis;
	public final double[] getItemCumuUtis()
	{
		return itemCumuUtis;
	}
	public final void setItemCumuUtis(double[] value)
	{
		itemCumuUtis = value;
	}


	@Override
	public String toString() {
		return "Sequence [sequenceId=" + sequenceId + ", sequenceUtility="
				+ sequenceUtility + ", itemsets=" + itemsets + ", totalItems="
				+ totalItems + ", itemScanningList="
				+ Arrays.toString(itemScanningList) + ", itemsetsILSpointers="
				+ Arrays.toString(itemsetsILSpointers) + ", itemMap=" + itemMap
				+ ", itemCumulativeUtilities="
				+ Arrays.toString(itemCumulativeUtilities) + ", itemCumuUtis="
				+ Arrays.toString(itemCumuUtis) + "]";
	}
	
	public Sequence() //空参构造方法，给变量赋初值
	{
		this.sequenceId = -1;
		this.sequenceUtility = 0;
		this.itemsets = new ArrayList<ArrayList<Item>>();
		this.itemScanningList = null;
		this.itemsetsILSpointers = null;
		this.itemMap = new HashMap<Integer, Item>();

		this.itemCumulativeUtilities = null;

		this.itemCumuUtis = null;		
	}

	public final void buildLink() //buildLink()是建立联系方法   not understand
	{
		int itemcnt = 0;
		HashMap<Integer, Double> utitemp = new HashMap<Integer, Double>(); //存放 项id和效用的临时字典  0=0.0 1=0.0 2=0.0 3=0.0 4=0.0 5=0.0
		HashMap<Integer, Item> itemtemp = new HashMap<Integer, Item>(); //存放 项id和项index的临时字典  itemid,itemindex
		HashMap<Integer, Integer> stpos = new HashMap<Integer, Integer>(); //itemid,itemindex-1

		for (int i = 0; i < this.itemsets.size(); i++)
		{
			for (int j = 0; j < this.itemsets.get(i).size(); j++)
			{
				if (!utitemp.containsKey(this.itemsets.get(i).get(j).getItemId())) //若utitemp字典中不含键ItemId
				{
					utitemp.put(this.itemsets.get(i).get(j).getItemId(),  0.0);  
				}
			}
		}
		this.totalItems = utitemp.size(); //统计一条序列中所有项的数目
		utitemp.clear(); //从 Dictionary<TKey, TValue> 中移除所有的键和值，清空utitemp

		//The statement below is wrong.
		//this.itemsetsILSpointers = new int[this.totalItems];

		this.itemsetsILSpointers = new int[this.itemsets.size()]; //存放所有项集指针
		this.itemScanningList = new int[this.totalItems]; //存放所有项

		for (int i = this.itemsets.size() - 1; i >= 0; i--)
		{
			this.itemsetsILSpointers[i] = this.totalItems - itemcnt; //预定义局部变量itemcnt=0
			for (int j = this.itemsets.get(i).size() - 1; j >= 0; j--)
			{
				int itm = this.itemsets.get(i).get(j).getItemId(); //该序列中最后一个项的ID赋给itm
				this.itemsets.get(i).get(j).setItemsetIndex(i);
				//this.itemsets[i][j].ItemId = j;


				if (!utitemp.containsKey(itm))
				{
					utitemp.put(itm, this.itemsets.get(i).get(j).getUtility());
					itemtemp.put(itm, this.itemsets.get(i).get(j));
					stpos.put(itm, this.totalItems - itemcnt - 1);

					this.itemMap.put(itm, this.itemsets.get(i).get(j)); //字段，存放项的字段

					//this.itemsets[i][j].UpperUtiBound = this.itemsets[i][j].Utility;
					//this.itemsets[i][j].LowerUtiBound = this.itemsets[i][j].Utility;

					//Added in 12.Dec.12
					//Below is for the lastposition induction
					//this.lastPositionInduction[this.itemsets[i][j].ItemId] = this.itemsets[i][j].ItemsetIndex;


					this.itemsets.get(i).get(j).setRight(null);
					this.itemScanningList[this.totalItems - itemcnt - 1] = itm;
					itemcnt++;
				}
				else //接下来不明白
				{
					//this.itemsets[i][j].UpperUtiBound = this.itemsets[i][j].Utility;
					//this.itemsets[i][j].LowerUtiBound = this.itemsets[i][j].Utility;

					utitemp.put(itm, utitemp.get(itm) > this.itemsets.get(i).get(j).getUtility() ? utitemp.get(itm) :this.itemsets.get(i).get(j).getUtility());

					this.itemsets.get(i).get(j).setRight(itemtemp.get(itm));
					itemtemp.put(itm, this.itemsets.get(i).get(j));
					this.itemMap.put(itm, this.itemsets.get(i).get(j));
				}
			}
		}
	}

	public final void SetItemSumUtility() //不明白
	{
		for (Map.Entry<Integer, Item> it : this.itemMap.entrySet()) //Dictionary类型的 itemMap<itemId,itemIndex>
		{
			//This variable contains the sorted utilities.
			ArrayList<Double> maxItemRef = new ArrayList<Double>();

			//For each item
			for (Item itm = it.getValue(); itm != null; itm = itm.getRight())
			{
				int item = itm.getItemId();

				maxItemRef.add(itm.getUtility());
				Collections.sort(maxItemRef);
				Collections.reverse(maxItemRef);


				itm.setUtilities(new double[maxItemRef.size()]);

				//For the number of items
				for (int j = 0; j < maxItemRef.size(); j++)
				{
					//This variable presents the number of items.
					int count = j + 1;

					double sumUti = 0;
					for (int k = 0; k <= j; k++)
					{
						sumUti += maxItemRef.get(k);
					}
					itm.getUtilities()[j] = sumUti;
				}
			}
		}
	}

	public final void SetItemCumulativeUtilities() //设置项的累积效用
	{
		HashMap<Integer, Double> items = new HashMap<Integer, Double>();
		for (int i = 0; i < this.itemsets.size(); i++)
		{
			for (int j = 0; j < this.itemsets.get(i).size(); j++)
			{
				if (!items.containsKey(this.itemsets.get(i).get(j).getItemId()))
				{
					items.put(this.itemsets.get(i).get(j).getItemId(), (double) 0);
				}
				items.put(this.itemsets.get(i).get(j).getItemId(), items.get(this.itemsets.get(i).get(j).getItemId()) + this.itemsets.get(i).get(j).getUtility());
			}
		}

		this.itemCumuUtis = new double[this.totalItems];
		for (int i = 0; i < this.totalItems; i++)
		{
			int curritem = this.itemScanningList[i];
			this.itemCumuUtis[i] = items.get(curritem);
		}

		this.itemCumulativeUtilities = new double[this.itemsets.size()][];
		for (int i = 0; i < this.itemsets.size(); i++)
		{
			int size = this.totalItems - this.itemsetsILSpointers[i];
			this.itemCumulativeUtilities[i] = new double[size];

			int curritem;

			for (int j = 0; j < this.itemsets.get(i).size(); j++)
			{
				int itemtemp = this.itemsets.get(i).get(j).getItemId();
				double uti = this.itemsets.get(i).get(j).getUtility();
				items.put(itemtemp, items.get(itemtemp) - uti);
			}

			for (int j = 0; j < this.itemCumulativeUtilities[i].length; j++)
			{
				curritem = this.itemScanningList[this.itemsetsILSpointers[i] + j];
				this.itemCumulativeUtilities[i][j] = items.get(curritem);
			}
		}
	}

	public final void SetPreItemUtilities_Max(HashMap<Integer, Double> itemUtiRef)
	{
		HashMap<Integer, Double> temp = new HashMap<Integer, Double>();
		for (int i = 0; i < this.itemsets.size(); i++)
		{
			for (int j = 0; j < this.itemsets.get(i).size(); j++)
			{
				if (!temp.containsKey(this.itemsets.get(i).get(j).getItemId()))
				{
					temp.put(this.itemsets.get(i).get(j).getItemId(),  0.0);
				}
				temp.put(this.itemsets.get(i).get(j).getItemId(), temp.get(this.itemsets.get(i).get(j).getItemId()).compareTo(this.itemsets.get(i).get(j).getUtility()) < 0 ? this.itemsets.get(i).get(j).getUtility() : temp.get(this.itemsets.get(i).get(j).getItemId()));
			}
		}

		for (Map.Entry<Integer, Double> it : temp.entrySet())
		{
			if (!itemUtiRef.containsKey(it.getKey()))
			{
				itemUtiRef.put(it.getKey(),  0.0);
			}
			itemUtiRef.put(it.getKey(), itemUtiRef.get(it.getKey()) + it.getValue());
		}
	}

	public final void print()
	{
		System.out.println("Sequence ID:" + this.sequenceId + "\nSequence Utility:" + this.getSequenceUtility());

		for (int i = 0; i < this.itemsets.size(); i++)
		{
			ArrayList<Item> itemset = this.itemsets.get(i);
			for (int j = 0; j < itemset.size(); j++)
			{
				Item item = itemset.get(j);
				item.print();
			}
			System.out.println();
		}
		System.out.println("-----End of sequence " + this.sequenceId + "-----");
	}

	public final int getSequenceId()
	{
		return sequenceId;
	}
	public final void setSequenceId(int value)
	{
		sequenceId = value;
	}

	public final double getSequenceUtility()
	{
		return sequenceUtility;
	}
	public final void setSequenceUtility(double value)
	{
		sequenceUtility = value;
	}

	public final ArrayList<ArrayList<Item>> getItemsets()
	{
		return itemsets;
	}
	public final void setItemsets(ArrayList<ArrayList<Item>> value)
	{
		itemsets = value;
	}

	public final void insertItem(int item, boolean isIconc)
	{
		int lastelement;

		if (this.itemsets.isEmpty())
		{
			lastelement = 0;
			this.itemsets = new ArrayList<ArrayList<Item>>();
		}
		else
		{
			lastelement = this.itemsets.size() - 1;
		}

		Item it = new Item();
		if (lastelement >= 0)
		{
			it.setItemId(item);
			it.setItemsetIndex(this.itemsets.size() - 1);
			it.setRestSequenceUtility(0);
			it.setUtility(0);
			if (isIconc)
			{
				this.itemsets.get(lastelement).add(it);
			}
			else
			{
				ArrayList<Item> newelement = new ArrayList<Item>();
				newelement.add(it);
				this.itemsets.add(newelement);
			}
		}
		else
		{
			System.out.println("Error in insertItem");
		}
	}

	public final void setItemsetRestUtility() //设置剩余项集效用
	{
		Item tp;
		for (int i = 0; i < this.itemsets.size(); i++)
		{
			double utility = 0;
			for (int j = 0; j < this.itemsets.get(i).size(); j++) //计算每个项集的总效用
			{
				utility += this.itemsets.get(i).get(j).getUtility();
			}

			for (int j = 0; j < this.itemsets.get(i).size(); j++) //计算项集中每个项的剩余项集效用
			{
				tp = this.itemsets.get(i).get(j);
				tp.setRestItemsetUtility(utility - this.itemsets.get(i).get(j).getUtility());
				utility -= this.itemsets.get(i).get(j).getUtility();
			}
		}
	}

	public final String printpattern()
	{
		String os = "";

		os += "<";
		for (int i = 0; i < this.getItemsets().size(); i++)
		{
			if (this.getItemsets().get(i).size() > 1)
			{
				os += "(";
			}
			String space = "";
			for (Item it : this.getItemsets().get(i))
			{
				os += (space + it.getItemId());
				space = " ";
			}
			if (this.getItemsets().get(i).size() > 1)
			{
				os += ")";
			}
			if (i != this.getItemsets().get(i).size() - 1)
			{
				os += ",";
			}
		}
		os += ">";

		os += this.getSequenceUtility();

		return os;
	}

	public final String outpattern()
	{
		String ss = "";
		ss += "<";
		String comma = "";
		for (int i = 0; i < this.getItemsets().size(); i++)
		{
			ss += comma;

			if (this.getItemsets().get(i).size() > 1)
			{
				ss += "(";
			}
			String space = "";
			for (Item it : this.getItemsets().get(i))
			{
				ss += (space + USpanPlus.conceptmapping.get(it.getItemId()));
				space = " ";
			}
			if (this.getItemsets().get(i).size() > 1)
			{
				ss += ")";
			}

			comma = ",";
		}
		ss += (">:" + this.sequenceUtility);
		return ss;
	}

	public final String cleansequence(boolean isTerm)
	{
		String ss = "";
		String comma = "";
		for (int i = 0; i < this.getItemsets().size(); i++)
		{
			ss += comma;

			ss += "(";
			//if (this.Itemsets[i].Count > 1) ss += "(";
			String space = "";
			for (Item it : this.getItemsets().get(i))
			{
				if (isTerm)
				{
					ss += (space + USpanPlus.conceptmapping.get(it.getItemId()));
				}
				else
				{
					ss += (space + it.getItemId());
				}
				//ss += (space + it);
				space = ",";
			}
			//if (this.Itemsets[i].Count > 1) ss += ")";
			ss += ")";

			comma = " ";
		}

		return ss;
	}

	public final String debugprint(int level) //level？
	{
		String offset = "";
		String os = "";

		for (int i = 0; i < level; i++)
		{
			offset += "\t";
		}

		os += (offset + "Print the sequence:\n");

		os += (offset + "SequenceID: " + this.sequenceId + "\n");

		os += (offset + "SequenceUtility: " + this.sequenceUtility + "\n");

		os += (offset + "sequenceMatrix: " + "\n");

		os += (offset + "Sequence: " + this.itemsets.size() + " itemsets" + "\n");

		for (int i = 0; i < this.itemsets.size(); i++)
		{
			for (int j = 0; j < this.itemsets.get(i).size(); j++)
			{
				os += ("item:" + USpanPlus.itemIdsMapping[this.itemsets.get(i).get(j).getItemId()] + " itemsetIndex:" + this.itemsets.get(i).get(j).getItemsetIndex() + " restutility:" + this.itemsets.get(i).get(j).getRestSequenceUtility() + " utility:" + this.itemsets.get(i).get(j).getUtility());

				os += "\n";

				for (int k = 0;k < this.itemsets.get(i).get(j).getUtilities().length;k++)
				{
					os += ("\t" + this.itemsets.get(i).get(j).getUtilities()[k]);
				}

				os += "\n";

				if (this.itemsets.get(i).get(j).getRight() == null)
				{
					os += " Right:null";
				}
				else
				{
					os += " Right:" + this.itemsets.get(i).get(j).getRight().getItemsetIndex();
				}
				os += "\n";
			}
			os += (offset + "\n");
		}

		os += "Scanning List\n";
		for (int i = 0; i < this.itemScanningList.length; i++)
		{
			os += USpanPlus.itemIdsMapping[this.itemScanningList[i]] + "\t-\t";
		}

		os += "\n\n";

		os += "Itemset pointers:\n";
		for (int i = 0; i < this.itemsetsILSpointers.length; i++)
		{
			os += this.itemsetsILSpointers[i] + "\t-\t";
		}

		os += "\n\n";

		os += "Item sum utilities:\n";
		for (int i = 0; i < this.itemCumuUtis.length; i++)
		{
			os += this.itemCumuUtis[i] + "\t-\t";
		}

		os += "\n\n";

		os += "Item cumulative utilities:\n";
		for (int i = 0; i < this.itemCumulativeUtilities.length; i++)
		{
			//for (int j = 0; j < this.totalItems; j++)

			for (int k = 0; k < this.itemsetsILSpointers[i]; k++)
			{
				os += "\t-\t";
			}

			for (int j = 0; j < this.itemCumulativeUtilities[i].length; j++)
			{
				os += this.itemCumulativeUtilities[i][j] + "\t-\t";
			}
			os += "\n";
		}

		os += "\n\n";

		os += "ItemMap:\n";
		for (Map.Entry<Integer, Item> it : this.itemMap.entrySet())
		{
			os += it.getValue().itemId + " "
				+ "(" + it.getValue().itemIndex + ","
				+ it.getValue().itemsetIndex + ")\t";
		}
		os += "\n\n";

		os += "<";
		for (int i = 0; i < this.itemsets.size(); i++)
		{
			if (this.itemsets.get(i).size() > 1)
			{
				os += "(";
			}
			String space = "";
			for (Item it : this.getItemsets().get(i))
			{
				os += (space + it.getItemId());
				space = " ";
			}
			if (this.getItemsets().get(i).size() > 1)
			{
				os += ")";
			}
			if (i != this.getItemsets().size() - 1)
			{
				os += ",";
			}
		}
		os += ">\n";

		os += "\n";
		return os;
	}
	
	
}