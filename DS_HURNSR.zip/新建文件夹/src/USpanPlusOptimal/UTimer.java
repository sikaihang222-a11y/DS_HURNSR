package USpanPlusOptimal;

public class UTimer
{
	public StopWatch sscan; //Stopwatch类的实例
	public StopWatch iscan;
	public StopWatch sconc;
	public StopWatch iconc;

	public long sscanTime; //测量的时间间隔
	public long iscanTime;
	public long sconcTime;
	public long iconcTime;

	public UTimer() //UTime类的构造方法
	{
		this.sscan = new StopWatch(); //类实例化
		this.iscan = new StopWatch();
		this.sconc = new StopWatch();
		this.iconc = new StopWatch();

		this.sscanTime = 0; //初始时间间隔设置为零
		this.iscanTime = 0;
		this.sconcTime = 0;
		this.iconcTime = 0;
	}

	public final void sScanBegin()
	{
		//this.sscan.Reset();
		this.sscan.start(); //sscan开始计时
	}

	public final void sScanEnd() //结束计时，得到当前实例的总运行时间，以毫秒为单位
	{
		this.sscan.stop();
		this.sscanTime += this.sscan.getNanoTime();
	}

	public final void iScanBegin()
	{
		//this.iscan.reset();
		this.iscan.start();
	}

	public final void iScanEnd()
	{
		this.iscan.stop();
		this.iscanTime += this.iscan.getNanoTime();
	}

	public final void sConcBegin()
	{
		//this.sconc.Reset();
		this.sconc.start();
	}

	public final void sConcEnd()
	{
		this.sconc.stop();
		this.sconcTime += this.sconc.getNanoTime();
	}

	public final void iConcBegin()
	{
		//this.iconc.Reset();
		this.iconc.start();
	}

	public final void iConcEnd()
	{
		this.iconc.stop();
		this.iconcTime += this.iconc.getNanoTime();
	}

	public final String outTimer() //outTime()分别输出四个实例运行的时间
	{
		String ret = "";

		ret += ("sScan time: " + this.sscan.getNanoTime() + "\niScan time: " + this.iscan.getNanoTime() + "\nsConc time: " + this.sconc.getNanoTime() + "\niConc time: " + this.iconc.getNanoTime());


		return ret;
	}
}