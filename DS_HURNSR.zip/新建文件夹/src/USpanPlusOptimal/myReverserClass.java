package USpanPlusOptimal;

import java.util.*;

public class myReverserClass implements Comparator
{

	// Calls CaseInsensitiveComparer.Compare with the parameters reversed. 
	//int IComparer.Compare(Object x, Object y)
	//{
	//    return ((new CaseInsensitiveComparer()).Compare(y, x));
	//}

	public final int compare(Object x, Object y)
	{
		return (int)((Double)y - (Double)x);
	}
}