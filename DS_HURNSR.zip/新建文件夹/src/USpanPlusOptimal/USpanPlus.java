package USpanPlusOptimal;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class USpanPlus
{
	private ArrayList<Sequence> sequences;
	private HashMap<String,Pattern> patterns;

	private double seqBaseUtility;

	private int insertFunctionPreviousSeqId = -1;
	private int insertFunctionPreviousItemsetId = -1;
	private Sequence insertFunctionSequence = null;
	private ArrayList<Item> insertFunctionItemset = null;

	private ArrayList<Sequence> insertedSeqbase = null;

	public final ArrayList<Sequence> getInsertedSeqbase()
	{
		return insertedSeqbase;
	}
	public final void setInsertedSeqbase(ArrayList<Sequence> value)
	{
		insertedSeqbase = value;
	}

	private HashSet<Integer> distinctItems;
	//The variable indicates the number of distinct items in the whole database
	//Updated in the function 

	public static int NumberOfDistinctItems = 0;

	//public static string[] conceptmapping;
	public static HashMap<Integer, String> conceptmapping;

	public final HashMap<String, Pattern> getPatterns()
	{
		return patterns;
	}
	public final void setPatterns(HashMap<String, Pattern> value)
	{
		patterns = value;
	}
	public final ArrayList<Sequence> getSequences()
	{
		return sequences;
	}
	public final void setSequences(ArrayList<Sequence> value)
	{
		sequences = value;
	}
	public final double getSeqBaseUtility()
	{
		return seqBaseUtility;
	}
	public final void setSeqBaseUtility(double value)
	{
		seqBaseUtility = value;
	}

	public static int[] itemIdsMapping;

	//public static int debug_numberofS = 0;

	public static int NumberOfCandidatesInAll = 0;
	public static double threshold;
	public static ArrayList<String> ptnlist;

	//The membership functions.        

	public USpanPlus()
	{
		this.sequences = new ArrayList<Sequence>();
		this.insertedSeqbase = new ArrayList<Sequence>();
		USpanPlus.conceptmapping = new HashMap<Integer, String>();

		this.distinctItems = new HashSet<Integer>();
	}

	public final void EncodingTheItemIds()
	{
		USpanPlus.itemIdsMapping = new int[USpanPlus.NumberOfDistinctItems];
		int index = 0;

		TreeSet<Integer> tempo = new TreeSet<Integer>();
		for (int it : this.distinctItems)
		{
			tempo.add(it);
		}

		HashMap<Integer, Integer> ItemIdtoIndex = new HashMap<Integer, Integer>();
//C# TO JAVA CONVERTER TODO TASK: There is no equivalent to implicit typing in Java:
		for (Integer it : tempo)
		{
			USpanPlus.itemIdsMapping[index] = it;
			ItemIdtoIndex.put(it, index++);
		}


		for (int i = 0; i < this.sequences.size(); i++)
		{
			Sequence seqref = this.sequences.get(i);
			for (int j = 0; j < seqref.getItemsets().size(); j++)
			{
				for (int k = 0; k < seqref.getItemsets().get(j).size(); k++)
				{
					//if (!ItemIdtoIndex.ContainsKey(seqref.Itemsets[j][k].ItemId))
					//{
					//    ItemIdtoIndex.Add(seqref.Itemsets[j][k].ItemId, index);
					//    this.itemIdsMapping[index] = seqref.Itemsets[j][k].ItemId;
					//    seqref.Itemsets[j][k].ItemId = ItemIdtoIndex[seqref.Itemsets[j][k].ItemId];
					//    index++;
					//    //this.itemIdsMapping[seqref.Itemsets[j][k].ItemId] = index;
					//}
					//else
					//{
					  seqref.getItemsets().get(j).get(k).itemId = ItemIdtoIndex.get(seqref.getItemsets().get(j).get(k).itemId);
					//}
				}
			}
		}
	}

	public final void DecodingTheItemIds(ArrayList<Sequence> seqBase, HashSet<Integer> distinctItems)
	{
		for (int i = 0;i < this.sequences.size();i++)
		{
			Sequence seqref = this.sequences.get(i);
			for (int j = 0;j < seqref.getItemsets().size();j++)
			{
				for (int k = 0;k < seqref.getItemsets().get(j).size();k++)
				{
					if (USpanPlus.itemIdsMapping.length > seqref.getItemsets().get(j).get(k).itemId)
					{
						seqref.getItemsets().get(j).get(k).itemId = USpanPlus.itemIdsMapping[seqref.getItemsets().get(j).get(k).itemId];
					}
					else
					{
						System.out.println("Error!");
					}
				}
			}
		}
	}
	/**
	 * 解码Pattern
	 */
	public final void DecodingThePatternItemIds(ArrayList<Pattern> pattern)
	{
		for (int i = 0;i < pattern.size();i++)
		{
			Pattern p = pattern.get(i);
			//Pattern p = new Pattern(pattern.get(i));
			for (int j = 0;j < p.getItemsets().size();j++)
			{
				for (int k = 0;k < p.getItemsets().get(j).size();k++)
				{
					int a=p.getItemsets().get(j).get(k);
					if (USpanPlus.itemIdsMapping.length > a)
					{
						a = USpanPlus.itemIdsMapping[p.getItemsets().get(j).get(k)];
						p.getItemsets().get(j).set(k, a);
					}
					else
					{
						System.out.println("Error!");
					}
				}
			}
		}
	}
	
	public final void DecodingThePatternItemIds1(ArrayList<Pattern> pattern)
	{
		for (int i = 0;i < pattern.size();i++)
		{
			Pattern p = new Pattern(pattern.get(i));
			for (int j = 0;j < p.getItemsets().size();j++)
			{
				for (int k = 0;k < p.getItemsets().get(j).size();k++)
				{
					int a=p.getItemsets().get(j).get(k);
					
						p.getItemsets().get(j).set(k, a+1);
				}
			}
		}
	}
	public final void InsertSequence(String line)
	{
		int seqId, itemsetId, itemId;
		double quantity;

		//int seqcnt = 0;
		System.out.println("split---");

		String[] parseValues = line.split("['\t', ' ']");

		if (parseValues.length == 4)
		{
			seqId = Integer.parseInt(parseValues[0]);
			itemsetId = Integer.parseInt(parseValues[1]);
			itemId = Integer.parseInt(parseValues[2]);
			quantity = Double.parseDouble(parseValues[3]);


			//if (seqId == 1000000) break;

			Item item = new Item();
			item.setItemId(itemId);
			item.setUtility(quantity);

			if (seqId != this.insertFunctionPreviousSeqId)
			{
				this.insertFunctionSequence = new Sequence();
				this.insertFunctionSequence.setSequenceId(seqId);
				this.insertFunctionPreviousItemsetId = -1;

				this.insertedSeqbase.add(this.insertFunctionSequence);

				//seqcnt++;
			}

			if (itemsetId != this.insertFunctionPreviousItemsetId)
			{
				this.insertFunctionItemset = new ArrayList<Item>();

				this.insertFunctionSequence.getItemsets().add(this.insertFunctionItemset);
			}

			this.insertFunctionItemset.add(item);

			this.insertFunctionPreviousSeqId = seqId;
			this.insertFunctionPreviousItemsetId = itemsetId;
			//if (seqId % 10000 == 0) Console.WriteLine(seqId);
		}
	}

	public final void ReadCosmosDataTestFunction(String inputfile) throws IOException
	{
//C# TO JAVA CONVERTER TODO TASK: C# to Java Converter cannot determine whether this System.IO.FileStream is input or output:
		
		BufferedReader br = null;
		br = new BufferedReader(new FileReader(inputfile));
	     
	      String contentLine = br.readLine();
	      while (contentLine != null) {
	    	  this.InsertSequence(contentLine);
	        contentLine = br.readLine();
	      }
	      
	      br.close();
	      
	      /*
		java.io.InputStreamReader sr = new java.io.InputStreamReader(new BufferedStream(new FileStream(inputfile, FileMode.Open)));
		String line;

		//first line is itemNumber.
		//line = sr.ReadLine();

		//rest lines are seqId, itemsetId, itemId and quantity.
		while ((line = sr.ReadLine()) != null)
		{
			//Console.WriteLine(line);
			this.InsertSequence(line);
			//if (this.insertFunctionPreviousSeqId > 600000)
			//    break;
		}
		sr.close();
		*/

		System.out.println("ReadCosmosDataTestFunction Finished!");
	}

	public final void setutilities(ArrayList<Sequence> seqbase, double seqbaseutility)
	{
		Sequence sequence = null;
		ArrayList<Item> itemset = null;
		seqbaseutility = 0;
		//Get the utility of each sequence. Two other functions are implemented:
		//1. Assign ItemIndex and ItemsetIndex.  2. Get the number of distinct items

		this.distinctItems = new HashSet<Integer>();
		for (int i = 0; i < seqbase.size(); i++)
		{
			sequence = seqbase.get(i);
			sequence.setSequenceUtility(0);
			for (int j = 0; j < sequence.getItemsets().size(); j++)
			{
				itemset = sequence.getItemsets().get(j);
				for (int k = 0; k < itemset.size(); k++)
				{
					sequence.setSequenceUtility(sequence.getSequenceUtility() + itemset.get(k).getUtility());

					this.distinctItems.add(itemset.get(k).getItemId());

					sequence.getItemsets().get(j).get(k).itemIndex = k;
					sequence.getItemsets().get(j).get(k).itemsetIndex = j;
				}
			}
			seqbaseutility += sequence.getSequenceUtility();
		}
		
		USpanPlus.NumberOfDistinctItems = this.distinctItems.size();

		//Get the rest utility of each item.
		for (int i = 0; i < seqbase.size(); i++)
		{
			sequence = seqbase.get(i);
			double utilitySum = 0;
			for (int j = 0; j < sequence.getItemsets().size(); j++)
			{
				itemset = sequence.getItemsets().get(j);
				for (int k = 0; k < itemset.size(); k++)
				{
					utilitySum += itemset.get(k).getUtility();
					itemset.get(k).setRestSequenceUtility(sequence.getSequenceUtility() - utilitySum);
				}
			}
		}

		this.EncodingTheItemIds();

		HashMap<Integer, Double> itemUti = new HashMap<Integer, Double>();


		for (int i = 0; i < seqbase.size(); i++)
		{
			sequence = seqbase.get(i);
			sequence.buildLink();
			//sequence.SortUtiBound();
			//sequence.FillinBound();

			//The following function is used for a tighter bound
			sequence.SetItemCumulativeUtilities();

			sequence.setItemsetRestUtility();

			//Added in 17.Dec.2012
			//The following function is for pre-scanning for top-k patterns.
			sequence.SetPreItemUtilities_Max(itemUti);

			//Added in 11.Mar.2013
			sequence.SetItemSumUtility();
		}
	}

	public final void readrawdata(String filepath, ArrayList<Integer> ret) throws IOException
	{
		ret = new ArrayList<Integer>();
		BufferedReader br = null;
		br = new BufferedReader(new FileReader(filepath));
	     
	      String contentLine = br.readLine();
	      while (contentLine != null) {
	    	  this.InsertSequence(contentLine);
	        contentLine = br.readLine();
	      }
	      /*
	      br.close();
//C# TO JAVA CONVERTER TODO TASK: C# to Java Converter cannot determine whether this System.IO.FileStream is input or output:
		java.io.InputStreamReader sr = new java.io.InputStreamReader(new BufferedStream(new FileStream(filepath, FileMode.Open)));
		String line = "";
		while ((line = sr.ReadLine()) != null)
		{
			String[] parseValues = line.split(new char[] {'\t'}, StringSplitOptions.RemoveEmptyEntries);
			if (parseValues.length == 4)
			{
				ret.argValue.add(Integer.parseInt(parseValues[3]));
			}
		}
		sr.close();
		*/
	}

	//----------------------------------------------------------------------


	public final void RunUSpan(double threshold)
	{
		this.patterns = new HashMap<String, Pattern>();

		double SeqBaseUtility = 0;

		//Console.WriteLine(this.debugprint(this.insertedSeqbase0));

		this.sequences = this.insertedSeqbase;

		//tangible.RefObject<ArrayList<Sequence>> tempRef_insertedSeqbase = new tangible.RefObject<ArrayList<Sequence>>(this.insertedSeqbase);
		//tangible.RefObject<Double> tempRef_SeqBaseUtility = new tangible.RefObject<Double>(SeqBaseUtility);
		this.setutilities(insertedSeqbase, seqBaseUtility);
	    SeqBaseUtility = this.seqBaseUtility;
	    //this.insertedSeqbase = tempRef_insertedSeqbase.argValue;

		this.seqBaseUtility = SeqBaseUtility;


		//Console.WriteLine(this.debugprint() + "/*/*/*/*/*/*/*");

		//Console.WriteLine(this.debugprint());

		USpanPlus.threshold = threshold * this.seqBaseUtility;


		USpanPlus.ptnlist = new ArrayList<String>();

		Program.TightRunningTime.start();
		this.runUSpan();
		Program.TightRunningTime.stop();

		//USpanPlus.klist.TrimMaxIndex();

		//Scanner scn = new Scanner(USpanPlus.klist, this.sequences);
		//scn.build_from_memory();
		//scn.insert_db();
		//scn.outputpatterns();
		//USpanPlus.klist.fillinResultsReady();
		//Console.WriteLine(USpan.klist.GetFinalResults());
		//Console.WriteLine(USpanPlus.debug_numberofS);
	}

	public final void runUSpan()
	{
		ProjectedSequenceBase pjb = new ProjectedSequenceBase(this.sequences, this.seqBaseUtility);
		pjb.ProjectedSequenceBaseInit();
		GetUSpanPatterns(pjb, 0);
	}

	public final void GetUSpanPatterns(ProjectedSequenceBase projectedsb, int level)
	{
		ArrayList<Integer> itemp, stemp;

		if (projectedsb.LeftUti < USpanPlus.threshold)
		{
			return;
		}
		projectedsb.scan();
		itemp = projectedsb.getIConcItems_USpan();
		USpanPlus.NumberOfCandidatesInAll += itemp.size();
		for (int i = 0; i < itemp.size(); i++)
		{
			ProjectedSequenceBase nextpsb = new ProjectedSequenceBase(projectedsb);

			if (!nextpsb.iConcatenatingTheFields(projectedsb, itemp.get(i)))
			{
				continue;
			}
			if (nextpsb.getCandidateUtility() >= USpanPlus.threshold)
			{
				nextpsb.getCandidate().setUtility(nextpsb.getCandidateUtility());
				USpanPlus.ptnlist.add(nextpsb.getCandidate().cleanpattern() + " : " + nextpsb.getCandidate().cleanparameters());
			}
			this.GetUSpanPatterns(nextpsb, level + 1);
		}

		stemp = projectedsb.getSConcItems_USpan();
		USpanPlus.NumberOfCandidatesInAll += stemp.size();
		for (int i = 0; i < stemp.size(); i++)
		{
			ProjectedSequenceBase nextpsb = new ProjectedSequenceBase(projectedsb);
			if (!nextpsb.sConcatenatingTheFields(projectedsb, stemp.get(i)))
			{
				continue;
			}
			if (nextpsb.getCandidateUtility() >= USpanPlus.threshold)
			{
				nextpsb.getCandidate().setUtility(nextpsb.getCandidateUtility());
				USpanPlus.ptnlist.add(nextpsb.getCandidate().cleanpattern() + " : " + nextpsb.getCandidate().cleanparameters());
			}

			this.GetUSpanPatterns(nextpsb, level + 1);
		}
	}

	//----------------------------------------------------------------------

	public final void T_RunUSpanPlus(double threshold)
	{
		this.patterns = new HashMap<String, Pattern>();


		double SeqBaseUtility = 0;

		this.sequences = this.insertedSeqbase;
		this.setutilities(insertedSeqbase, seqBaseUtility);
	    SeqBaseUtility = this.seqBaseUtility;

		this.seqBaseUtility = SeqBaseUtility;

		USpanPlus.threshold = threshold * this.seqBaseUtility;


		USpanPlus.ptnlist = new ArrayList<String>();

		Program.TightRunningTime.start();
		this.T_run();
		Program.TightRunningTime.stop();

	}

	public final void T_run()
	{
		ProjectedSequenceBase pjb = new ProjectedSequenceBase(this.sequences, this.seqBaseUtility);
		pjb.ProjectedSequenceBaseInit();
		T_GetUSpanPlus(pjb, 0);
	}

	public final void T_GetUSpanPlus(ProjectedSequenceBase projectedsb, int level)
	{
		ArrayList<Integer> itemp, stemp;
		int inumberofitems = 0, snumberofitems = 0;
		projectedsb.Original_iScan();
		itemp = MJ_Utils.arrayToList(projectedsb.getReadyForConc());
		inumberofitems = projectedsb.getNumerOfItems();
		USpanPlus.NumberOfCandidatesInAll += inumberofitems;
		for (int i = 0; i < inumberofitems; i++)
		{
			ProjectedSequenceBase nextpsb = new ProjectedSequenceBase(projectedsb);

			if (!nextpsb.iConcatenatingTheFields(projectedsb, itemp.get(i)))
			{
				continue;
			}
			if (nextpsb.getCandidateUtility() >= USpanPlus.threshold)
			{
				nextpsb.getCandidate().setUtility(nextpsb.getCandidateUtility());
				USpanPlus.ptnlist.add(nextpsb.getCandidate().cleanpattern() + " : " + nextpsb.getCandidate().cleanparameters());
			}
			this.T_GetUSpanPlus(nextpsb, level + 1);
		}

		projectedsb.Original_sScan();
		stemp = MJ_Utils.arrayToList(projectedsb.getReadyForConc());
		snumberofitems = projectedsb.getNumerOfItems();
		USpanPlus.NumberOfCandidatesInAll += snumberofitems;
		for (int i = 0; i < snumberofitems; i++)
		{
			ProjectedSequenceBase nextpsb = new ProjectedSequenceBase(projectedsb);
			if (!nextpsb.sConcatenatingTheFields(projectedsb, stemp.get(i)))
			{
				continue;
			}
			if (nextpsb.getCandidateUtility() >= USpanPlus.threshold)
			{
				nextpsb.getCandidate().setUtility(nextpsb.getCandidateUtility());
				USpanPlus.ptnlist.add(nextpsb.getCandidate().cleanpattern() + " : " + nextpsb.getCandidate().cleanparameters());
			}

			this.T_GetUSpanPlus(nextpsb, level + 1);
		}


	}

	//----------------------------------------------------------------------


	public static String Merge(String val1, String val2)
	{

		//string str = "2016.69018266569	25499	0	0	1320	98.3994545972253	0	0	24179	1918.29072806847	0	0	0.0545928284875305	0.0512953814338163";
		//string temp = "1690.17689099108	4631	2	0.729703932930639	237	86.4699160522807	94	34.29608484774	4394	1603.7069749388	0.0212765957446809	0.0212765957446808	0.0539371870732817	0.0539187753146615";
		////(garment)	2047.76660158004	59755	0	0	3018	101.477933251319	0	0	56737	1946.28866832872	0	0	0.0531928018753195	0.0521391995455934

		//val1 = str;
		//val2 = temp;


		String ret = "";

		System.out.println("split---");
		String[] temp1 = val1.split("['\t',' ']");
		String[] temp2 = val1.split("['\t',' ']");



		if (temp1.length == temp2.length)
		{
			for (int i = 0; i < temp1.length; i++)
			{
				ret += (String.valueOf((Double.parseDouble(temp1[i]) + Double.parseDouble(temp2[i]))) + "\t");
			}
		}
		return ret;
	}

	public final String debugprint()
	{
		String os = "";

		os += "\ninsertedSeqbase\n----------\n\n";
		for (int i = 0;i < this.insertedSeqbase.size(); i++)
		{
			os += this.insertedSeqbase.get(i).debugprint(0) + "\n";
		}
		return os;
	}

	public final String debugprintTopk(int topk)
	{
		String os = "";

		os += "\ninsertedSeqbase\n----------\n\n";
		for (int i = 0; i < topk && i < this.insertedSeqbase.size(); i++)
		{
			os += this.insertedSeqbase.get(i).cleansequence(false) + "\n";
		}
		return os;
	}
}