package USpanPlusOptimal;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import util.Conobject;


public class ICDMAlgos    // USpan算法
{
	private ArrayList<Sequence> sequences; // the insertedSeqbase
	public static double Threshold;
	private double seqBaseUtility; // the overall 334
	private int insertFunctionPreviousSeqId = -1; // 在插入函数中，已经插入的序列的序列号
	private int insertFunctionPreviousItemsetId = -1; // 在插入函数中，已经插入的项集的项集号
	private Sequence insertFunctionSequence = null; // 在插入函数中，当前正在插入的序列
	private ArrayList<Item> insertFunctionItemset = null; // 在插入函数中，当前正在插入的序列的项集
	private ArrayList<Sequence> insertedSeqbase = null; // 在插入函数中，已经插入的序列组成的序列数据集

	public final ArrayList<Sequence> getInsertedSeqbase() {
		return insertedSeqbase;
	}

	public final void setInsertedSeqbase(ArrayList<Sequence> value) {
		insertedSeqbase = value;
	}

	private HashSet<Integer> distinctItems; // 哈希表存储不重复的项Integer，整型，List可以重复
	public static int NumberOfDistinctItems = 0;    // 不同项的个数

	public final ArrayList<Sequence> getSequences() {
		return sequences;
	}

	public final void setSequences(ArrayList<Sequence> value) {
		sequences = value;
	}

	public final double getSeqBaseUtility() {
		return seqBaseUtility;
	}

	public final void setSeqBaseUtility(double value) {
		seqBaseUtility = value;
	}

	public static int[] itemIdsMapping; // 存储项id的整型数组，数组名 itemIdsMapping
	public static int NumberOfCandidatesInAll = 0;
	public static int NumberOfCandidatesGenerated = 0;
	public static int NumberOfCandidatesInsideList = 0;
	public static int MAXLEVEL = 200; // ??
	public static ArrayList<String> ptnlist; // 模式list

	/**
	 * Feb 28,2024
	 * public ICDMAlgos()
	 * 空参构造函数，构造一个名为ICDMAlgos的类
	 */
	public ICDMAlgos()
	{
		this.sequences = new ArrayList<Sequence>();    //创建了一个新的参数只能为Sequence的Arraylist赋予该类的sequences
		new ArrayList<Integer>();    //创建了一个参数只能为整形的Arraylist
		this.insertedSeqbase = new ArrayList<Sequence>();    //插入数据库是一个参数只能为Sequence的Arraylist
		this.distinctItems = new HashSet<Integer>(); // distinctItems 是哈希表的名字
	}

	/**
	 * Feb 28,2024
	 * 空参构造函数，构造一个名为ICDMAlgos的类
	 * public final void EncodingTheItemIds()
	 */
	public final void EncodingTheItemIds() // 编码项id
	{
		ICDMAlgos.itemIdsMapping = new int[ICDMAlgos.NumberOfDistinctItems];    /* new了一个大小为
		                                                                           ICDMAlgos.NumberOfDistinctItems数组
		                                                                           ICDMAlgos.NumberOfDistinctItems全局变量
		                                                                        */
		int index = 0;    // 索引为0,为下文HashMap做准备
		TreeSet<Integer> tempo = new TreeSet<Integer>();	// TreeSet是SortedSet接口的唯一实现类，TreeSet可以确保集合元素处于排序状态
		for (int it : this.distinctItems)
		{
			tempo.add(it);
		}	// 迭代，this就是指当前对象，将当前对象的distinctItems赋予it并通过add函数添加到tempo中
		HashMap<Integer, Integer> ItemIdtoIndex = new HashMap<Integer, Integer>();    //定义了一个哈希表，存放Item
		for (Integer it : tempo)
		{
			ICDMAlgos.itemIdsMapping[index] = it;    // index从0开始
			ItemIdtoIndex.put(it, index++);
		}

		/*
		 * 把itemIdsMapping这个数组中的数据传到itemIdsMapping，存放的是键值对（it,index），存放后index++
		 */

		for (int i = 0; i < this.sequences.size(); i++)
		{
			Sequence seqref = this.sequences.get(i);
			for (int j = 0; j < seqref.getItemsets().size(); j++)
			{
				for (int k = 0; k < seqref.getItemsets().get(j).size(); k++)
				{
					seqref.getItemsets().get(j).get(k).itemId = ItemIdtoIndex.get(seqref.getItemsets().get(j).get(k).itemId);
				}    // itemId换成itemIndex        ?为什么要换成itemIndex
			}
		}
	}

	// ICDMAlgos算法的 静态变量，记录已经插入的项的数目下面的InsertSequence方法用到
	public static int items = 0;
	// ICDMAlgos算法的 静态变量，记录已经插入的项集的数目
	public static int itemsets = 0;

	/**
	 * Feb 28,2024
	 * 用于将文本行解析为序列和项，并将它们插入到数据结构中。
	 * public final void InsertSequence(String line)
	 * 对参数进行说明：line就是DB里面的一行        见Bible_Seq数据库
	 * InsertSequence--->ReadCosmosDataTestFunction
	 */
	public final void InsertSequence(String line) {
		int seqId, itemsetId, itemId, x = 0;
		double quantity;
		String[] parseValues = line.split("[\\t,' ']");    // split将一行数据（4个）根据制表符，逗号，空格拆分成四部分存在数组里面
		if (parseValues.length == 4) {
			seqId = Integer.parseInt(parseValues[0]); // 序列ID
			itemsetId = Integer.parseInt(parseValues[1]); // 项集ID
			itemId = Integer.parseInt(parseValues[2]); // 项id
			quantity = Double.parseDouble(parseValues[3]); // 一个项的效用
			Item item = new Item(); // 新建一个Item类的实例 item
			item.setItemId(itemId);
			item.setUtility(quantity);
			// 上述两行代码已经把DB中一行的后两项存下来了

			/* 预定义的字段初始化为insertFunctionPreviousSeqId=-1
			 * 此后指代已经插入的序列的序列号，每当插入新序列时执行
			 */
			if (seqId != this.insertFunctionPreviousSeqId) {
				// 作为临时变量，存储当前正在插入的序列
				this.insertFunctionSequence = new Sequence(); // 预定义字段Sequence类型的
				this.insertFunctionSequence.setSequenceId(seqId);
				// 预定义字段int类型的insertFunctionPreviousItemsetId = -1，每次添加新序列都置为-1
				this.insertFunctionPreviousItemsetId = -1;
				// 预定义字段List<Sequence>型的insertedSeqbase =
				// null，每次添加新序列都把它添加到插入序列数据库中
				this.insertedSeqbase.add(this.insertFunctionSequence);
			}
			// insertFunctionPreviousItemsetId=-1，每当插入新项集时执行
			if (itemsetId != this.insertFunctionPreviousItemsetId) {
				// 预定义字段List<Item>型的
				// insertFunctionItemset=null;作为临时变量，存储当前正在插入的项集
				this.insertFunctionItemset = new ArrayList<Item>();
				ICDMAlgos.itemsets++;
				this.insertFunctionSequence.getItemsets().add(this.insertFunctionItemset);
			}
			ICDMAlgos.items++; // 每次都执行
			this.insertFunctionItemset.add(item);
			// 把当前已经插入的序列insertFunctionPreviousSeqId置为正在插入的这条序列的序列号
			this.insertFunctionPreviousSeqId = seqId;
			// 把当前已经插入的项集insertFunctionPreviousItemsetId置为正在插入的这个项集的项集号
			this.insertFunctionPreviousItemsetId = itemsetId;
		}

	}

	/**
	 * Feb 28,2024
	 * public final void ReadCosmosDataTestFunction(String inputfile) throws IOException
	 * 读取数据集中的数据
	 */
	public final void ReadCosmosDataTestFunction(String inputfile) throws IOException
	{
		BufferedReader br = null;    // 字符输入流缓冲流
		br = new BufferedReader(new FileReader(inputfile));
		String contentLine = br.readLine();    // 一行一行读取
		while (contentLine != null) {
			// 只要读取的一行不为空，就调用一次InsertSequence函数，依次插入到insertedSeqbase
			this.InsertSequence(contentLine);
			contentLine = br.readLine(); // 读取下一行
		}
		br.close();
		System.out.println("ReadCosmosDataTestFunction Finished!");
	}

	/**
	 *Feb 28,2024
	 * public final double setutilities(ArrayList<Sequence> seqbase, double seqbaseutility)
	 * 计算序列数据库的效用，并对序列中的项进行一些属性设置，最终返回序列数据库的总效用值。
	 */
	public final double setutilities(ArrayList<Sequence> seqbase, double seqbaseutility)
	{
		Sequence sequence = null;
		ArrayList<Item> itemset = null;
		seqbaseutility = 0;
		this.distinctItems = new HashSet<Integer>();
		// 下面计算总效用值
		for (int i = 0; i < seqbase.size(); i++)
		{
			sequence = seqbase.get(i);    // 从数据库中提取序列
			sequence.setSequenceUtility(0);
			for (int j = 0; j < sequence.getItemsets().size(); j++)
			{
				itemset = sequence.getItemsets().get(j);    // 从数据库中提取项集
				for (int k = 0; k < itemset.size(); k++)    // 从数据库中提取元素并设置效用
				{
					sequence.setSequenceUtility(sequence.getSequenceUtility() + itemset.get(k).getUtility());
					// 2.名为distinctItems的哈希表记录所有不同的项（重复的项不插入）
					this.distinctItems.add(itemset.get(k).getItemId());
					sequence.getItemsets().get(j).get(k).itemIndex = k;
					sequence.getItemsets().get(j).get(k).itemsetIndex = j;
				}
			}
			seqbaseutility += sequence.getSequenceUtility();
		}    // 计算整个数据库的seqbase的效用
		ICDMAlgos.NumberOfDistinctItems = this.distinctItems.size(); // 不同项的数目，项的种类数
		// Get the rest utility of each item.    获得每个项目的剩余效用
		for (int i = 0; i < seqbase.size(); i++) {
			sequence = seqbase.get(i);
			double utilitySum = 0;
			for (int j = 0; j < sequence.getItemsets().size(); j++) {
				itemset = sequence.getItemsets().get(j);
				for (int k = 0; k < itemset.size(); k++) {
					utilitySum += itemset.get(k).getUtility();
					// 当前项的剩余效用等于该条序列效用减去累计效用
					itemset.get(k).setRestSequenceUtility(sequence.getSequenceUtility() - utilitySum);
				}
			}
		}
		this.EncodingTheItemIds(); // itemid change from 1 2 3 to 0 1 2
		USpanPlus.itemIdsMapping = ICDMAlgos.itemIdsMapping; // 1 2 3
		HashMap<Integer, Double> itemUti = new HashMap<Integer, Double>();

		for (int i = 0; i < seqbase.size(); i++) {
			sequence = seqbase.get(i);
			sequence.buildLink(); // 看sequence的这个buildlink函数
			sequence.SetItemCumulativeUtilities(); // 调用sequence的函数，设置项的累计效用
			sequence.setItemsetRestUtility(); // 调用sequence的函数，设置项集的剩余效用
			sequence.SetPreItemUtilities_Max(itemUti); // 看sequence的函数
			sequence.SetItemSumUtility(); // 看sequence的函数
		}
		return seqbaseutility;
	}

	/**
	 * Feb 28,2024 20:09    --> Program.TightRunningTime.start();计时器
	 * @param threshold
	 * @return
	 */
	public final List<List<Pattern>> Original_RunUSpanPlus(double threshold,List<Sequence> batch) {
		System.out.println("Original_RunUSpanPlus method for ICDMAlgos");
		double SeqBaseUtility = 0;
		List<Pattern> HightUtilitySeqList = new ArrayList<Pattern>();    // 所有高效序列和效用的集合
		List<Pattern> SeqList = new ArrayList<Pattern>();    // 所有序列和效用集合
		// 存储高效用序列和全部序列
		List<List<Pattern>> SeqListCollect = new ArrayList<List<Pattern>>();
//		this.sequences = this.insertedSeqbase;
		this.sequences = new ArrayList<>(batch);  // 改动在这里
		this.seqBaseUtility = this.setutilities(this.sequences, SeqBaseUtility);
		System.out.println("数据库总效用" + this.seqBaseUtility);
		ICDMAlgos.Threshold = threshold * this.seqBaseUtility;    // 0.3*334=100.2
		System.out.println("最小效用阈值:" + ICDMAlgos.Threshold);    // 输出最小效用阈值
		ICDMAlgos.ptnlist = new ArrayList<String>();
		Program.TightRunningTime.start();
		ICDMProjectedSequenceBase pjb = new ICDMProjectedSequenceBase(this.sequences, this.seqBaseUtility);    // 有参构造
		pjb.ProjectedSequenceBaseInit();    // 初始化
		long milli = System.currentTimeMillis() + 8 * 3600 * 1000;
		long ticks = (milli * 10000) + 621355968000000000L;
		ICDMProgram.startStamp = ticks / (10000);
		Original_DFS_GetUSpanPlus(pjb, 0, HightUtilitySeqList, SeqList);    // DFS
		ICDMProgram.endStamp = ticks / (10000);
		Program.TightRunningTime.stop();    // 执行过程中测量紧密运行时间
		SeqListCollect.add(HightUtilitySeqList);
		SeqListCollect.add(SeqList);
		return SeqListCollect;
	}

	/**
	 * Original_DFS_GetUSpanPlus函数 深度优先遍历
	 * Feb 29,2024 20:09
	 * @param projectedsb
	 * @param level
	 */
	public final void Original_DFS_GetUSpanPlus(ICDMProjectedSequenceBase projectedsb, int level,
			List<Pattern> HightUtilitySeqList, List<Pattern> SeqList) // 深度优先遍历
	{
		ArrayList<Integer> itemp, stemp;
		int inumberofitems = 0, snumberofitems = 0;
		// 深度剪枝,树根为空，所以LeftUti为总效用
		if (projectedsb.LeftUti < ICDMAlgos.Threshold)
		{
			return;
		}
		ICDMProgram.debugTimer.iScanBegin();
		projectedsb.Original_iScan(); // I扫描
		ICDMProgram.debugTimer.iScanEnd();
		itemp = MJ_Utils.arrayToList(projectedsb.getReadyForConc());// 存储i连接的项     getReadyForConc()获取候选项
		inumberofitems = projectedsb.getNumerOfItems();
		ICDMAlgos.NumberOfCandidatesInAll += inumberofitems;
		for (int i = 0; i < inumberofitems; i++) // I-连接
		{
			if (level == 0)
			{
				Calendar c = Calendar.getInstance();
				String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(c.getTime());
			}
			ICDMProjectedSequenceBase nextpsb = new ICDMProjectedSequenceBase(projectedsb);
			ICDMProgram.debugTimer.iConcBegin();
			// I连接
			boolean flag = nextpsb.Original_iConcatenatingTheFields(projectedsb, itemp.get(i));
			if (!flag)
			{
				continue;
			}
			ICDMProgram.debugTimer.iConcEnd();
			// 存储所有的序列
			SeqList.add(nextpsb.getCandidate());
			if (nextpsb.getCandidateUtility() >= ICDMAlgos.Threshold)
			{
				nextpsb.getCandidate().fillinPattern(nextpsb);
				ICDMAlgos.ptnlist.add(nextpsb.getCandidate().cleanpattern() + " : " + nextpsb.getCandidate().cleanparameters());
				// 存储高效用序列
				HightUtilitySeqList.add(nextpsb.getCandidate());
			}
			this.Original_DFS_GetUSpanPlus(nextpsb, level + 1, HightUtilitySeqList, SeqList);
		} // I-连接end
		ICDMProgram.debugTimer.sScanBegin();
		projectedsb.Original_sScan();
		ICDMProgram.debugTimer.sScanEnd();
		stemp = MJ_Utils.arrayToList(projectedsb.getReadyForConc());
		snumberofitems = projectedsb.getNumerOfItems();
		ICDMAlgos.NumberOfCandidatesInAll += snumberofitems;
		for (int i = 0; i < snumberofitems; i++) // s-连接start
		{
			if (level == 0) {
				Calendar c = Calendar.getInstance();
			}
			ICDMProjectedSequenceBase nextpsb = new ICDMProjectedSequenceBase(projectedsb);
			ICDMProgram.debugTimer.sConcBegin();
			// S连接
			boolean flag = nextpsb.Original_sConcatenatingTheFields(projectedsb, stemp.get(i));
			if (!flag) {
				continue;
			}
			ICDMProgram.debugTimer.sConcEnd();
			SeqList.add(nextpsb.getCandidate());
			if (nextpsb.getCandidateUtility() >= ICDMAlgos.Threshold) {
				nextpsb.getCandidate().fillinPattern(nextpsb);
				ICDMAlgos.ptnlist
						.add(nextpsb.getCandidate().cleanpattern() + " : " + nextpsb.getCandidate().cleanparameters());
				HightUtilitySeqList.add(nextpsb.getCandidate());
			}
			this.Original_DFS_GetUSpanPlus(nextpsb, level + 1, HightUtilitySeqList, SeqList);
		} // s-连接end

	}

}